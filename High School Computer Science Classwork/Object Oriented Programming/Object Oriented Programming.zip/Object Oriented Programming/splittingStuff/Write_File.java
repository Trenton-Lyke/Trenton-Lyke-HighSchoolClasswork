import java.io.*;
/**
 * This program writes a text file
 * @author (Trenton Lyke)
 * @version (10/1/18)
 */
public class Write_File
{
    /*declares global instance variables*/
    //FileOutputStream object that is used tor write data to a file
    private FileOutputStream out;
    //PrintStream allows for representations of data to be printed in files
    private PrintStream ps;
    
    /**
     * Constructor for objects of class Write_File
     */
    public Write_File(String filename){
        //tries to set up a file to output data to given a file name and to establish that data will be printed in that file
        try
        {
            out =  new FileOutputStream(filename);
            ps = new PrintStream(out);
        }
        //if it cannot be done it prints "Error opening the output file."
        catch(Exception e)
        {
            System.out.println("Error opening the output file.");
        }
    }
    //prints a given string into the established file
    public void write(String s){
        //tries to print a given string in the file
        try
        {
            ps.println(s);
        }
        //if it cannot be done it prints "Error when writing to the file."
        catch(Exception e)
        {
            System.out.println("Error when writing to the file.");
        }
    }
    public void writef(String f,String s){
        //tries to print a given string in the file
        try
        {
            ps.printf(f, s);
        }
        //if it cannot be done it prints "Error when writing to the file."
        catch(Exception e)
        {
            System.out.println("Error when writing to the file.");
        }
    }
    //close the output stream
    public void close()
    {
        //tries to close the output stream
        try
        {
            ps.close();
        }
        //if it cannot be done it prints "Error when closing the output stream."
        catch(Exception e)
        {
            System.out.println("Error when closing the output stream.");
        }
    }
}
