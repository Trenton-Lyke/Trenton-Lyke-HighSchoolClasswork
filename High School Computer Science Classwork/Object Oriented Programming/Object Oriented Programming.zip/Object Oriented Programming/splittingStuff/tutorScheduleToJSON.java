import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.ArrayList;
/**
 * Write a description of class FindDates here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class tutorScheduleToJSON
{
    public static void main(String args[]) throws java.io.FileNotFoundException{
       File text = new File("tutorSchedule.txt");
       
      
       Scanner scan = new Scanner(text);
       Write_File writer = new Write_File("tutor_schedule_json.json");
       writer.write("[");
       while(scan.hasNextLine())
       {
           String line = scan.nextLine();
           String[] lineArray = line.split(",");
           writer.write("\t{");
           writer.write("\t\t\"letter\":\""+lineArray[0].trim()+"\",");
           writer.write("\t\t\"email\":\""+lineArray[1].trim()+"\",");
           writer.write("\t\t\"first_name\":\""+lineArray[2].trim()+"\",");
           writer.write("\t\t\"last_name\":\""+lineArray[3].trim()+"\",");
           writer.write("\t\t\"from\":\""+lineArray[4].trim()+"\",");
           writer.write("\t\t\"to\":\""+lineArray[5].trim()+"\"");
           if(scan.hasNextLine()){
               writer.write("\t},");
           }
           else{
               writer.write("\t}");
           }
       }
       writer.write("]");
    }
    public static boolean isInteger(String s) {
        try { 
            Integer.parseInt(s); 
        } catch(NumberFormatException e) { 
            return false; 
        } catch(NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }
}
