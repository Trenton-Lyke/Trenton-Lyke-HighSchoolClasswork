import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.ArrayList;
/**
 * Write a description of class FindDates here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CorrectDates
{
    public static void main(String args[]) throws java.io.FileNotFoundException{
       File text = new File("imsadays.txt");
       
      
       Scanner scan = new Scanner(text);
       Write_File writer = new Write_File("imsadayscorrected.txt");
       ArrayList<Integer> imsaDays = new ArrayList<Integer>();
       imsaDays.add(0);
       int year = 2018;
       int month = 8;
       while(scan.hasNextLine())
       {
           String line = scan.nextLine();
           String[] lineArray = line.split(" ");
           for(int i = 0; i < lineArray.length; i++){
               lineArray[i] = lineArray[i].trim();
               
           }
           if(imsaDays.get(imsaDays.size()-1)>Integer.parseInt(lineArray[0])){
               month++; 
           }
           if(imsaDays.get(imsaDays.size()-1)==Integer.parseInt(lineArray[0])){
               month++;
           }
           if(month > 12){
               year++;
               month %= 12;
           }
           String stringMonth = Integer.toString(month);
           if(month < 10){
               stringMonth = "0"+month;
           }
           if(Integer.parseInt(lineArray[0]) < 10){
               lineArray[0] = "0"+lineArray[0];
           }
           imsaDays.add(Integer.parseInt(lineArray[0]));
           System.out.println(year+"-"+stringMonth+"-"+lineArray[0]+" "+lineArray[1]);
           writer.write(year+"-"+stringMonth+"-"+lineArray[0]+" "+lineArray[1]);
       }   
       
    }
    public static boolean isInteger(String s) {
        try { 
            Integer.parseInt(s); 
        } catch(NumberFormatException e) { 
            return false; 
        } catch(NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }
}
