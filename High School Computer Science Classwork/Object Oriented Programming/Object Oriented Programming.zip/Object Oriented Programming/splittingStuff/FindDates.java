import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.ArrayList;
/**
 * Write a description of class FindDates here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FindDates
{
    public static void main(String args[]) throws java.io.FileNotFoundException{
       File text = new File("imsa calendar.txt");
       
      
       Scanner scan = new Scanner(text);
       Write_File writer = new Write_File("imsadays.txt");
       ArrayList<String> imsaDays = new ArrayList<String>();
       while(scan.hasNextLine())
       {
           String line = scan.nextLine();
           String[] lineArray = line.split(" |-");
           for(int i = 0; i < lineArray.length; i++){
               lineArray[i] = lineArray[i].trim();
               //System.out.print(lineArray[i]);
           }
           //System.out.println("");
           for(int i = 1; i < lineArray.length; i++){
               if(isInteger(lineArray[i-1])){
                   //System.out.println(lineArray[i-1] + " " + lineArray[i]);
                   if(Integer.parseInt(lineArray[i-1]) >= 1 && Integer.parseInt(lineArray[i-1])<=31 && (lineArray[i].equals("A") || lineArray[i].equals("B") || lineArray[i].equals("C") || lineArray[i].equals("D") || lineArray[i].equals("I"))){
                       imsaDays.add(lineArray[i-1] + " " + lineArray[i]);
                       System.out.println(lineArray[i-1] + " " + lineArray[i]);
                   }
                }
           }
       }   
       for(String date : imsaDays){
           writer.write(date);
       }
    }
    public static boolean isInteger(String s) {
        try { 
            Integer.parseInt(s); 
        } catch(NumberFormatException e) { 
            return false; 
        } catch(NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }
}
