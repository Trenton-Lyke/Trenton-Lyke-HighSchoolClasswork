import java.util.Scanner;
/**
 * Write a description of class Birthday here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Birthday
{
    public static void main(String[] args){
            System.out.println("The instructions for the Game:\n1.  Determine your birth month (January=1, February=2 and so on)\n2. Multiply that number by 5.\n3. Add 6 to that number.\n4. Multiply the number by 4\n5. Add 9 to the number.\n6. Multiply that number by 5.\n7. Add your birth day to the number (10 if the 10th and so on). ");
            System.out.println("Please enter calculated number: ");
            Scanner scan = new Scanner(System.in);
            int num = scan.nextInt();
            int birthmonth = (num-165)/100;
            int birthday = (num-165)%100;
            System.out.println("Birthmonth---> "+birthmonth+" Birthday---> "+ birthday);
        }
}
