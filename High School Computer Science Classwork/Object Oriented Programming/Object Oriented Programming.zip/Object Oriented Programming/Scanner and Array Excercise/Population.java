
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
 * Write a description of class Read_File here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Population
{
    private static String[] countyNames;
    private static int[] countyPopulation;
    private static Scanner scan;
    public static void main(String[] args) throws FileNotFoundException{
        populate();
        scan = new Scanner(System.in);
        boolean loop = true;
        String s = ""; //string to get user input
        while(loop)//do the loop until the user input is no
        {
            System.out.println("Would you like to look at Texa's population -> yes or no");
            s = scan.nextLine();
            if((s.toLowerCase()).equals("yes"))
            {
                System.out.println("1. Print the data from the file.");
                System.out.println("2. Print Texas total population.");
                System.out.println("3. Randomly choose a county and display its population .");
                System.out.println("4. Find counties population with a leading digit, entered by the user .");
                System.out.println("5. Find total number of counties/percentage of population with each leading digit formatted using printf.");
                //add other options
                s= scan.nextLine();
                if(s.equals("1"))
                {
                    printData();
                }
                else if(s.equals("2"))
                {
                    System.out.println("Texas population ->" + findTotal());
                }
                else if(s.equals("3")){
                    randomCounty();
                }
                else if(s.equals("4")){
                    showLeadingDigit();
                }
                else if(s.equals("5")){
                    analysis();
                }
                //add additional if else statements
                else{
                    System.out.println("Incorrect input");
                }
            }
            else if((s.toLowerCase()).equals("no"))
            {
                System.out.println("Good bye");
                loop = false;//user wants to stop the loop
            }
            else{
                System.out.println("Invalid Input please enter yes or no: ");
            }
        }
    }
    public static void populate() throws FileNotFoundException{
        File text = new File("TexasCountyPopulation.txt");
        Scanner scan1 = new Scanner(text);
        String line = "";
        countyNames = new String[254];
        countyPopulation = new int[254];
        int lineNumber = 0;
        while(scan1.hasNextLine()){
            line = scan1.nextLine();
            String[] countyInfo = line.split(" ");
            countyNames[lineNumber] = countyInfo[0];//save county name into counties array
            countyPopulation[lineNumber] = Integer.parseInt(countyInfo[2].trim());//save county population into population array
            lineNumber++;
        }
    }
    public static void printData() throws FileNotFoundException{
        for(int i = 0; i < countyPopulation.length; i++){
            System.out.printf("%-20s",countyNames[i]+" County");
            System.out.printf("%8s",countyPopulation[i] + "\n");
        }
    }
    //method finds and returns total
    public static int findTotal(){
        int total = 0;
        for(int i = 0; i < countyPopulation.length; i++){
            total += countyPopulation[i];
        }
        return total;
    }
    
    public static void randomCounty()
    {
        int value = (int)(Math.random()*countyNames.length);
        System.out.println("Randomly chosen county at index  " + value + " is:  " + countyNames[value] + " County and its population is:  " + countyPopulation[value]);
    }
    
    public static void showLeadingDigit()
    {
        System.out.println("Enter the leading digit 1 -9:  ");
        String leadingDigit = scan.nextLine();
        System.out.println("Showing data with a leading digit of:  " + leadingDigit);
        for(int i = 0; i < countyPopulation.length; i++){
            if((String.valueOf(countyPopulation[i]).substring(0,1)).equals(leadingDigit)){
                System.out.printf("%-20s",countyNames[i]+" County");
                System.out.printf("%8s",countyPopulation[i] + "\n");
            }
        }
    }
    public static void analysis()
    {
        System.out.printf("%-10s","digit");
        System.out.printf("%-10s","number");
        System.out.printf("percentage\n");
        float total = 0;
         for(int leadingDigit = 1; leadingDigit < 10; leadingDigit++){
            System.out.printf("%3s",leadingDigit);
            int populationTotal = 0;
            int number = 0;
            for(int i = 0; i < countyPopulation.length; i++){
                if((String.valueOf(countyPopulation[i]).substring(0,1)).equals(String.valueOf(leadingDigit))){
                    populationTotal += countyPopulation[i];
                    number++;
                }
            }
            System.out.printf("%10s",number);
            double percentage = (double)populationTotal/findTotal();
            total += percentage;
            System.out.printf("%12.2f",((percentage*100)));
            System.out.printf("\n");
        }
    }
}
