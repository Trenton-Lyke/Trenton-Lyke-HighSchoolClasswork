import java.util.Scanner;
/**
 * Write a description of class TimeConversion here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TimeConversion
{
    public static void main(String[] args){
        System.out.println("Please enter a timespan in minutes: ");
        Scanner scan = new Scanner(System.in);
        int mins = scan.nextInt();
        System.out.println("Hours---> "+ (mins/60) + " Minutes---> "+(mins%60));
    }
}
