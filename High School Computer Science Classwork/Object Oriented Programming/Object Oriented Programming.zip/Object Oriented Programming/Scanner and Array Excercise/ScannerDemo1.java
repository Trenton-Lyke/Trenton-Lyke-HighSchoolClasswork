import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
/**
 * This class is an example of how to use a scanner for getting input.
 *
 * @author (Trenton Lyke)
 * @version (9/21/18)
 */
public class ScannerDemo1
{
    

    /**
     * Constructor for objects of class ScannerDemo1
     */
    public ScannerDemo1()
    {
        Scanner scan = new Scanner(System.in);
        /*String name = scan.nextLine();//read a string using scanner
        System.out.println(name);//echo what was read for name
        int age = scan.nextInt();// read an integer using scanner
        System.out.println(age);//echo what was read for age*/
        double gpa = scan.nextDouble();// read a double using scanner
        System.out.println(gpa);//echo what was read for gpa
        
    }

    
}
