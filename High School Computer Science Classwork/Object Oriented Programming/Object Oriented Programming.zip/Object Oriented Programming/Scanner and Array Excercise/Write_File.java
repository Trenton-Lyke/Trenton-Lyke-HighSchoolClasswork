import java.io.*;
/**
 * This program writes a text file
 * @author (Trenton Lyke)
 * @version (10/1/18)
 */
public class Write_File
{
    private FileOutputStream out;
    private PrintStream ps;
    
    public Write_File(){
        try
        {
            out =  new FileOutputStream("MyFile.txt");
            ps = new PrintStream(out);
        }
        catch(Exception e)
        {
            System.out.println("Error opening the output file.");
        }
    }
    public void write(String s){
        try
        {
            ps.println(s);
        }
        catch(Exception e)
        {
            System.out.println("Error when writing to the file.");
        }
    }
    public void close()
    {
        try
        {
            ps.close();
        }
        catch(Exception e)
        {
            System.out.println("Error when writing to the file.");
        }
    }
}
