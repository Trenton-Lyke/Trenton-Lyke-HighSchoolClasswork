import java.util.Scanner;
/**
 * Write a description of class Digits here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Digits
{
    public static void main(String[] args){
        System.out.println("Please enter a two digit positive integer: ");
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();
        System.out.println("Tens place digit ->>>" + (num/10) + " Ones place digit ->>>" + (num%10));
    }
}
