import javax.swing.*;
/**
 * Write a description of class SimpleInputDialog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SimpleInputDialog
{
    
    public SimpleInputDialog()
    {
        // initialise instance variables
        JFrame frame = new JFrame("InputDialog");
        String choice = JOptionPane.showInputDialog(frame, "How many games would you like to play? ");
        System.out.println(choice);
    }

    
}
