import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
 * This class reads text from a text file and displays the number of occurences 
 * of strings in a file.
 *
 * @author (Trenton Lyke)
 * @version (11/19/2018)
 */
public class ReadFile
{
    //will contain all the strings within the file
    private static ArrayList<String> words;
    
    //will be used to read file
    private static Scanner scan;
    
    //will contain unique strings from file
    private static ArrayList<String> w;
    

    /**
     * Constructor for objects of class ReadFile
     */
    public static void main(String [] args)throws FileNotFoundException 
    {
        
        populate();
        
        frequency();
        
       
    }
    //This method will read file and will create the arraylist of words.
    public static void populate() throws FileNotFoundException
    {
        words = new ArrayList<String>();
        File text = new File("numbers.txt");
        scan = new Scanner(text);
        while(scan.hasNextLine()){
            words.add(scan.nextLine().trim());
        }
        
    }
    //This method will find the frequency of each word and display it.
    public static void frequency()
    { 
        /*int[] frequencies = new int[10];
        for(int i = 0; i < frequencies.length; i++){
            frequencies[i] = 0;
        }
        for(int i = 0; i < words.size(); i++){
            switch(words.get(i)){
                case "one":
                    frequencies[0]++;
                    break;
                case "two":
                    frequencies[1]++;
                    break;
                case "three":
                    frequencies[2]++;
                    break;
                case "four":
                    frequencies[3]++;
                    break;
                case "five":
                    frequencies[4]++;
                    break;
                case "six":
                    frequencies[5]++;
                    break;
                case "seven":
                    frequencies[6]++;
                    break;
                case "eight":
                    frequencies[7]++;
                    break;
                case "nine":
                    frequencies[8]++;
                    break;
                case "ten":
                    frequencies[9]++;
                    break;
            }
        }
        System.out.println("one appeared " + frequencies[0] + " times");
        System.out.println("two appeared " + frequencies[1] + " times");
        System.out.println("three appeared " + frequencies[2] + " times");
        System.out.println("four appeared " + frequencies[3] + " times");
        System.out.println("five appeared " + frequencies[4] + " times");
        System.out.println("six appeared " + frequencies[5] + " times");
        System.out.println("seven appeared " + frequencies[6] + " times");
        System.out.println("eight appeared " + frequencies[7] + " times");
        System.out.println("nine appeared " + frequencies[8] + " times");
        System.out.println("ten appeared " + frequencies[9] + " times");
        */
        //intitializes ArrayList w that contains all the unique strings
        w = new ArrayList<String>();
        
        //adds all the unique strings to ArrayList w
        for(int i = 0; i < words.size(); i++){
            if(!w.contains(words.get(i))){
                w.add(words.get(i));
            }
        }
        
        //creates an array that stores all the frequencies of the unique strings
        int[] frequencies = new int[w.size()];
        
        //initializes all frequencies at 0
        for(int i = 0; i < frequencies.length; i++){
            frequencies[i] = 0;
        }
        
        //sets the frequencies of the unique strings in the array corresponding to their frequencies in the file
        for(int i = 0; i < words.size(); i++){
            if(!(w.indexOf(words.get(i)) == -1)){
                frequencies[w.indexOf(words.get(i))]++;
            }
        }
        
        //displays the unique strings along with their corresponding frequencies
        for(int i = 0; i < w.size(); i++){
            System.out.println(w.get(i) +" appears "+ frequencies[i]+" times");
        }
    }
    
    
    

    
}
