
/**
 * This class uses the square and circle classes to simulate die.
@ *
 * @author (Trenton Lyke)
 * version (10/2/2018)
 */
public class Die
{
    /*declares fields for Die class*/
    
    //integer variable for the value of die (number of dots on die)
    private int value;
    
    //integer variable for the x value of center of die
    private int xPosition;
    
    //integer variable for the y value of center of die
    private int yPosition;
    
    //square object to represent the cube part of the die
    private Square cube;
    
    //Circle object to represent the dots of the die
    private Circle dot1;
    private Circle dot2;
    private Circle dot3;
    private Circle dot4;
    private Circle dot5;
    private Circle dot6;
    private Circle dot7;
    
    /**
     * Constructor for objects of class Die
     */
    public Die(int x, int y)
    {
        //initializes xPosition equal to the parameter x
        xPosition = x;
        //initializes yPosition equal to the parameter y
        yPosition = y;
        
        //initializes graphical parts of the die with x and y positions based on the parameters x and y
        cube = new Square(x-60,y-60);
        dot1 = new Circle(x-50,y-50);
        dot2 = new Circle(x-50,y-10);
        dot3 = new Circle(x-50,y+30);
        dot4 = new Circle(x-10,y-10);
        dot5 = new Circle(x+30,y-50);
        dot6 = new Circle(x+30,y-10);
        dot7 = new Circle(x+30,y+30);
    }
    
    //method rolls die
    public void rollDie(){
        //sets integer variable value to a random number between 1 and 6
        value = (int)(Math.random()*6+1);
        //calls different methods based off of the value of the integer variable value
        switch(value){
            //simulates die landing on 1 is value is 1
            case 1:
                landOn1();
                break;
            //simulates die landing on 2 is value is 2
            case 2:
                landOn2();
                break;
            //simulates die landing on 3 is value is 3
            case 3:
                landOn3();
                break;
            //simulates die landing on 4 is value is 4
            case 4:
                landOn4();
                break;
            //simulates die landing on 5 is value is 5
            case 5: 
                landOn5();
                break;
            //simulates die landing on 6 is value is 6
            case 6:
                landOn6();
                break;
        }
    }
    //makes die appear to have a value of 1 on the canvas
    public void landOn1(){
        cube.makeVisible();
        dot1.makeInvisible();
        dot2.makeInvisible();
        dot3.makeInvisible();
        dot4.makeVisible();
        dot5.makeInvisible();
        dot6.makeInvisible();
        dot7.makeInvisible();
    }
    //makes die appear to have a value of 2 on the canvas
    public void landOn2(){
        cube.makeVisible();
        dot1.makeVisible();
        dot2.makeInvisible();
        dot3.makeInvisible();
        dot4.makeInvisible();
        dot5.makeInvisible();
        dot6.makeInvisible();
        dot7.makeVisible();
    }
    //makes die appear to have a value of 3 on the canvas
    public void landOn3(){
        cube.makeVisible();
        dot1.makeVisible();
        dot2.makeInvisible();
        dot3.makeInvisible();
        dot4.makeVisible();
        dot5.makeInvisible();
        dot6.makeInvisible();
        dot7.makeVisible();
    }
    //makes die appear to have a value of 4 on the canvas
    public void landOn4(){
        cube.makeVisible();
        dot1.makeVisible();
        dot2.makeInvisible();
        dot3.makeVisible();
        dot4.makeInvisible();
        dot5.makeVisible();
        dot6.makeInvisible();
        dot7.makeVisible();
    }
    //makes die appear to have a value of 5 on the canvas
    public void landOn5(){
        cube.makeVisible();
        dot1.makeVisible();
        dot2.makeInvisible();
        dot3.makeVisible();
        dot4.makeVisible();
        dot5.makeVisible();
        dot6.makeInvisible();
        dot7.makeVisible();
    }
    //makes die appear to have a value of 6 on the canvas
    public void landOn6(){
        cube.makeVisible();
        dot1.makeVisible();
        dot2.makeVisible();
        dot3.makeVisible();
        dot4.makeInvisible();
        dot5.makeVisible();
        dot6.makeVisible();
        dot7.makeVisible();
    }
    //returns the value of the die
    public int getValue(){
        return value;
    }
    //makes the die invisble on the canvas
    public void hideDie(){
        cube.makeInvisible();
        dot1.makeInvisible();
        dot2.makeInvisible();
        dot3.makeInvisible();
        dot4.makeInvisible();
        dot5.makeInvisible();
        dot6.makeInvisible();
        dot7.makeInvisible();
    }
}
