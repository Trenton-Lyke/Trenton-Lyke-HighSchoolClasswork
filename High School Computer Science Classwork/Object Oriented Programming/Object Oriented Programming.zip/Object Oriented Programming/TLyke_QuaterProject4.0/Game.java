 import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;
import java.io.*;

/**
 * This class simulates a game of craps utilzing the Die class and Writes a file (results.txt) containing the results of the game using the Write_File
 *
 * @author (Trenton Lyke)
 * @version (10/2/18)
 */
public class Game
{
    /*declares global instance variables*/
    
    //canvas object which the game is played on
    private static Canvas canvas;
    
    //Write_File object that writes results in results.txt document
    private static Write_File writer;
    
    //JFrame object that is used to prompt input from user
    private static JFrame frame;
    
    //Die objects that are rolled simulating dice
    private static Die die1;
    private static Die die2;
    
    //integer variables used to track the number of wins and losses of games
    private static int wins;
    private static int losses;
    
    //string varaible used to track if a game was won or lost
    private static String status;
    
    //ArrayList object used to track the rolls for each game
    private static ArrayList rolls;
    
    //main method which allows the user to play the game of craps
    public static void main(String args[])
    {
        
        /*initializes the global variables above*/
        canvas = Canvas.getCanvas();
        //makes writer write in the file name results.txt
        writer = new Write_File("results.txt");
        frame = new JFrame("InputDialog");
        die1 = new Die(65,300);
        die2 = new Die(205,300);
        rolls = new ArrayList();
        
        //initializes the local variable that tracks the number of waves of games
        int wavesOfGames = 0;
        
        //draws a pair of dice with random faces showing
        rollDice();
        
        //changes the font size of the next things written on the canvas to 16pt
        changeFontSize(16);
        
        //writes the rules of the game of Craps on the canvas
        showRules();
        
        //initializes the string variable tracking the user's decision to play the game with the response to prompting the user for their choice
        String choice = promptChoice();
        
        //loop runs while user chose yes
        while("YES".equals(choice.toUpperCase())){
            //increments the number of waves of games by 1
            wavesOfGames++;
            
            //sets the number of wins and losses to 0
            wins = 0;
            losses = 0;
            
            //writes the new wave's header in the file named results.txt
            writer.write("\nWave "+wavesOfGames+":\n");
            writer.writef("%-15s","Game Number:");
            writer.writef("%-15s","Won or Lost: ");
            writer.write("Rolls:");
            //sets the integer variable tracking the number of games being played to the response to prompting the user for their choice
            int numberOfGames = promptNumberOfGames();
            
            //breaks out of while loop and ends simulation if user hits cancelled (check the promptNumberOfGames() method to see how)
            if(numberOfGames == -1)
            {
                break;
            }
            
            //loops for the number of games specified by the user
            for(int i = 0; i < numberOfGames; i++){
                //simulates the first roll of craps
                firstRoll();
                
                //simulates the following rolls of craps
                followingRolls();
                
                //writes the results of each game to the file named results.txt
                writer.writef("%-15s","Game "+(i+1));
                writer.writef("%-15s",status);
                writer.write(formatRolls(rolls));
            }
            //changes the font size of the next things written on the canvas to 35pt
            changeFontSize(35);
            //code runs if the user only played 1 game
            if(numberOfGames == 1){
                //sets the string variable contain the formatted rolls for the canvas to the return value of a method for formatting the rolls
                String formattedRolls = formatRolls(rolls);
                
                //code runs if the formattedRolls length is greater than 20 which originally mave have the string to go off the canvas
                if(formattedRolls.length()>20){
                    //changes the font size that formatted rolls with be written in so that they will fit in the canvas
                    changeFontSize((700/formattedRolls.length())+1);
                }
                
                //writes the formatted rolls on the canvas
                canvas.write("Rolls: "+formattedRolls,5,370);
            }
            
            //writes the wave's wins, losses, and win-loss ration in the results.txt
            writer.write("Overall:");
            writer.writef("%-15s","wins: " + wins);
            writer.writef("%-15s","losses: "+ losses);
            writer.write("win-loss ratio: "+(((double)wins)/losses));
            
            //changes the font size of the next things written on the canvas to 35pt
            changeFontSize(35);
            
            //writes the wave's wins and losses on the canvas
            canvas.write("wins: " + wins + " losses: "+ losses,5,400);
            
            //writes the rules of the game of Craps on the canvas
            showRules();
            
            //sets the string variable tracking the user's decision to play the game with the response to prompting the user for their choice
            choice = promptChoice();
        }
        
        //closes the output stream that the writer uses to write int the file name results.txt
        writer.close();
        
        //makes the dice invisible on the canvas
        hideDice();
        
        //changes the font size of the next things written on the canvas to 35pt
        changeFontSize(35);
        
        //writes goodbye message on the canvas
        canvas.write("Check the file named \nresults.txt in this folder for \ndetailed results\n\nThanks for playing \nGoodbye!!!",5,5);
    }
    
    //this method changes the font size of writing on the canvas following it being called
    public static void changeFontSize(int size){
        
        //creates a new font with a given size 
        Font b = new Font("Courier", Font.BOLD + Font.ITALIC, size);
        
        //sets the canvas's font to the new font
        canvas.font(b);
    }
    
    //this method shows the rules of the game of Craps on the canvas
    public static void showRules(){
        //changes the font size to 16pt
        changeFontSize(16);
        
        //writes the rules on the canvas
        canvas.write("Rules:\nFirst Roll: If the player rolls a 2, 3, or 12 they win. \nIf the player rolls a 7 or 11 they lose. \nIf the player rolls any other number \nthey establish that number as the point value to win. \nFollowing Rolls: The player continues to roll until they either \nroll the point value again and win or roll a 7 and lose. \n",5,50);
    }
    
    //this method creates a string containing the results for each roll formatted for the canvas and file named results.txt given the Array List named rolls
    public static String formatRolls(ArrayList rolls){
            //Initializes local variable formattedRolls to be empty
            String formattedRolls = "";
            
            //loops for each element in the ArrayList rolls
            for(int i = 0; i < rolls.size(); i++){
                //appends the first element to the string formattedRolls
                if(i == 0){
                    formattedRolls += rolls.get(i);
                }
                //appends " and " and the last element to the string formattedRolls
                else if(i == rolls.size()-1){
                    formattedRolls += " and " + rolls.get(i);
                }
                //appends commas before and after the second element and the second element to the string formattedRolls if there are more than 2 rolls
                else if(i == 1){
                    formattedRolls += ", " + rolls.get(i) + ", ";
                }
                //appends commas after the element and the element to the string formattedRolls
                else{
                    formattedRolls += rolls.get(i) + ", ";
                }
            }
            
            //returns the formatted rolls
            return formattedRolls;
    }
    
    //prompts the user for a yes or no answer for the user's decision to play the game of Craps verify if they entered yes, no, or clicked cancel
    public static String promptChoice(){
        //sets the string variable choice to the user's answer to the question "Would you like to play Craps? (yes or no) "
        String choice = JOptionPane.showInputDialog(frame, "Would you like to play Craps? (yes or no) ");
        
        //returns "CANCEL" if choice is null because that would mean that the user clicked cancel
        if(choice == null){
            return "CANCEL";
        }
        
        //loops while the choice is not equal to yes or no
        while(!"YES".equals(choice.toUpperCase()) && !"NO".equals(choice.toUpperCase())){
            //sets the string variable choice to the user's answer to the question "Would you like to play Craps? (yes or no)" and also alerting them that their previous input was in valid
            choice = JOptionPane.showInputDialog(frame, "Invalid input: Would you like to play Craps? Please enter yes or no: ");
            
            //returns "CANCEL" if choice is null because that would mean that the user clicked cancel
            if(choice == null){
                return "CANCEL";
            }
        }
        //returns user's choice
        return choice;
    }
    
    //prompts the user for the numbers of games they want to play and verifies that the response is a positive integer or that the user clicked cancel
    public static int promptNumberOfGames(){
        //sets the string variable input to the user's choice of how many games they would like to play
        String input = JOptionPane.showInputDialog(frame, "How many games would you like to play? ");
        
        //initializes the boolean variable isValidInteger to false
        boolean isValidInteger = false;
        
        //initializes the integer variable numberOfGames to -1 (I made it a negative number for the while loop below. It could have been any negative number -1 was just my preference)
        int numberOfGames = -1;
        
        //if the input is null meaning that the user clicked cancel then it returns -1 to activate and if statement in my main() method that breaks a while loop simulating the user canceling the game
        if(input == null){
            return -1;
        }
        //trys to convert the string variable input into an integer and change the boolean variable isValidInteger to true 
        try
        {
         Integer.parseInt(input);
         isValidInteger = true;
        }
        //if it cannot be done because the input cannot be converted into an int then it does neither of those things
        catch (NumberFormatException ex)
        {
        }
        //if the string variable integer can be made into an integer than the integer variable numberOfGames is set to the integer value of input
        if(isValidInteger ){
            numberOfGames = Integer.parseInt(input);
        }
        //loops while the number of games is a negative integer (which it is since it was initialized at -1)
        while(numberOfGames < 0){
            //sets the string variable input to the user's choice of how many games they would like to play and informs user that there past input was invalid
            input = JOptionPane.showInputDialog(frame, "Invalid input: How many games would you like to play? Please enter a positive integer: ");
            //if the input is null meaning that the user clicked cancel then it returns -1 to activate and if statement in my main() method that breaks a while loop simulating the user canceling the game
            if(input == null){
                return -1;
            }
            //trys to convert the string variable input into an integer and change the boolean variable isValidInteger to true 
            try
            {
                Integer.parseInt(input);
                isValidInteger = true;
            }
            //if it cannot be done because the input cannot be converted into an int then it does neither of those things
            catch (NumberFormatException ex)
            {
            }
            //if the string variable integer can be made into an integer than the integer variable numberOfGames is set to the integer value of input
            if(isValidInteger ){
                numberOfGames = Integer.parseInt(input);
            }
        }
        //returns numberOfGames
        return numberOfGames;
    }
    //rolls both dice
    public static void rollDice(){
        die1.rollDie();
        die2.rollDie();
    }
    //returns the sum of the dice's values
    public static int getDiceValue(){
        return (die1.getValue() + die2.getValue());
    }
    //hides both dice
    public static void hideDice(){
        die1.hideDie();
        die2.hideDie();
    }
    //Simulates the first roll of a game of Craps
    public static void firstRoll(){
        //initializes the string variable status to an empty string (import for following rolls)
        status = "";
        //clears the ArrayList of rolls for the game
        rolls.clear();
        //rolls dice
        rollDice();
        //adds the dice's value to the ArrayList rolls
        rolls.add(getDiceValue());
        //increments the integer variable wins by 1 and sets status to won if the value of the dice is 7 or 11 (complies with rules of the game of Craps)
        if((int)rolls.get(0) == 7 || (int)rolls.get(0) == 11){
            wins++;
            status = "won";
                    
        }
        //decrements the integer variable losses by 1 and sets status to won if the value of the dice is 2,3, or 12 (complies with rules of the game of Craps)
        else if((int)rolls.get(0) == 2 || (int)rolls.get(0) == 3 || (int)rolls.get(0) == 12){
            losses++;
            status = "lost";
                    
        }
    }
    //Simulates the rolls following the first roll of a game of Craps
    public static void followingRolls(){
        //if the status is an empty string (meaning the game was not one or loss) then the code is run
        if(status == ""){
                    //loops once initially and continues to loop until the following roll is equal to the initial roll of the game and not equal to 7
                    do{
                       //rolls dice
                       rollDice();
                       //gets value of dice
                       rolls.add(getDiceValue());
                       //decrements the integer variable losses by 1 and sets status to won if the value of the dice is 7 (complies with rules of the game of Craps)
                       if((int)rolls.get(rolls.size()-1) == 7){
                        losses++;
                        status = "lost";
                       }
                       //increments the integer variable wins by 1 and sets status to won if the value of the dice is the initial value of the dice (complies with rules of the game of Craps) 
                       else if((int)rolls.get(rolls.size()-1) == (int)rolls.get(0)){
                        wins++;
                        status = "won";
                        
                       }
                    }
                    while((int)rolls.get(rolls.size()-1) != (int)rolls.get(0) && (int)rolls.get(rolls.size()-1) != 7);
                }
    }
}