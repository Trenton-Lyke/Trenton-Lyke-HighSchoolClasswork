
/**
 * Write a description of class Sampler here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sampler
{
    public static void main(String[] args){
        int M = Integer.parseInt(args[0].trim());
        int N = Integer.parseInt(args[1].trim());
        int[] sampleNumbers = new int[N];
        for(int i = 0; i < N; i++){
            sampleNumbers[i] = randomNumberExclusiveUpperbound(0,M);
            System.out.println(sampleNumbers[i]);
        }
        int numberOfRows = 0;
        if(N%10 != 0){
            numberOfRows = N/10 + 1;
        }
        else
        {
            numberOfRows = N/10;
        }
        for(int row = 0; row < numberOfRows; row++){
            for(int column = 0; column < 10; column++){
                if(row*10+column < N){
                    System.out.printf("%8s",sampleNumbers[row*10 + column]);
                }
            }
            System.out.println("");
        }
    }
    public static int randomNumberInclusive(int lowerbound, int upperbound){
        int range = upperbound - lowerbound;
        return (int)(Math.random()*(range+1)+lowerbound);
    } 
    public static int randomNumberExclusiveUpperbound(int lowerbound, int upperbound){
        int range = upperbound - lowerbound;
        return (int)(Math.random()*(range)+lowerbound);
    } 
}
