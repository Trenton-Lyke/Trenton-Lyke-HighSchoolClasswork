import java.util.*;
/**
 * Write a description of class Sorts here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sorts
{
    // instance variables - replace the example below with your own
    

    public static double[] selectSort(double[] sortableArray){
        for(int i = 0; i < sortableArray.length; i++){
            double leastValue = sortableArray[i];
            int leastIndex = i;
            for(int j = i; j < sortableArray.length; j++){
                if(compareTo(leastValue, sortableArray[j]) > 0){
                    leastValue = sortableArray[j];
                    leastIndex = j;
                }
            }
            double temporyValueHolder = sortableArray[i];
            sortableArray[i] = leastValue;
            sortableArray[leastIndex] = temporyValueHolder;
        }
        return sortableArray;
    }
    public static double[] bubbleSort(double[] sortableArray){
        for(int i = 0; i < sortableArray.length; i++){
            for(int j = 1; j < sortableArray.length - i; j++){
                if(compareTo(sortableArray[j-1], sortableArray[j]) > 0){
                    double temporyValueHolder = sortableArray[j-1];
                    sortableArray[j-1] = sortableArray[j];
                    sortableArray[j] = temporyValueHolder;
                }
            }
        }
        return sortableArray;
    }
    public static double[] insertionSort(double[] sortableArray) 
    { 
       
        for (int i = 1; i < sortableArray.length; i++) { 
            double valueToBeSorted = sortableArray[i]; 
            int j = i - 1; 
  
            /* Move elements of arr[0..i-1], that are 
               greater than key, to one position ahead 
               of their current position */
            while (j >= 0 && compareTo(sortableArray[j],valueToBeSorted) > 0) { 
                sortableArray[j + 1] = sortableArray[j]; 
                j = j - 1; 
            } 
            sortableArray[j + 1] = valueToBeSorted; 
        } 
        return sortableArray;
    } 
    public static void merge(double arr[], int l, int m, int r) 
    { 
        // Find sizes of two subarrays to be merged 
        int n1 = m - l + 1; 
        int n2 = r - m; 
  
        /* Create temp arrays */
        double L[] = new double [n1]; 
        double R[] = new double [n2]; 
  
        /*Copy data to temp arrays*/
        for (int i=0; i<n1; ++i) 
            L[i] = arr[l + i]; 
        for (int j=0; j<n2; ++j) 
            R[j] = arr[m + 1+ j]; 
  
  
        /* Merge the temp arrays */
  
        // Initial indexes of first and second subarrays 
        int i = 0, j = 0; 
  
        // Initial index of merged subarry array 
        int k = l; 
        while (i < n1 && j < n2) 
        { 
            if (L[i] <= R[j]) 
            { 
                arr[k] = L[i]; 
                i++; 
            } 
            else
            { 
                arr[k] = R[j]; 
                j++; 
            } 
            k++; 
        } 
  
        /* Copy remaining elements of L[] if any */
        while (i < n1) 
        { 
            arr[k] = L[i]; 
            i++; 
            k++; 
        } 
  
        /* Copy remaining elements of R[] if any */
        while (j < n2) 
        { 
            arr[k] = R[j]; 
            j++; 
            k++; 
        } 
    } 
  
    // Main function that sorts arr[l..r] using 
    // merge() 
    public static double[] mergeSort(double arr[], int l, int r) 
    { 
        if (l < r) 
        { 
            // Find the middle point 
            int m = (l+r)/2; 
  
            // Sort first and second halves 
            mergeSort(arr, l, m); 
            mergeSort(arr , m+1, r); 
  
            // Merge the sorted halves 
            merge(arr, l, m, r); 
        } 
        return arr;
    } 
    public static int compareTo(double number1, double number2)
    {
        if(number1 == number2){
            return 0;
        }
        else if(number1 > number2){
            return 1;
        }
        else{
            return -1;
        }
    }
}
