import java.util.*;
/**
 * Write a description of class tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class tester
{
    public static void main(String[] args){
        /*double[] testArray = {2,7,3,0,2,5,8,94,3};
        for(double arrayElement : Sorts.mergeSort(testArray,0,testArray.length-1)){
            System.out.print(arrayElement + ", ");
        }*/
        /*double[] testArray = {1,4,8,9};
        double[] testArray2 = {6,7,8,24};
        for(double arrayElement : Sorts.merge(testArray, testArray2)){
            System.out.print(arrayElement + ", ");
        }*/
        int number = 210;
        ArrayList<Integer> digitList = new ArrayList<Integer>();
        do{
            digitList.add(number%10);
            number /= 10;
        }while(number != 0);
        System.out.println(digitList);
    }
}
