
import java.util.ArrayList;
/**
 * Write a description of class Sampler here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sampler2
{
    public static void main(int[] args){
        int M = args[0];
        int N = args[1];
        ArrayList<Integer> sampleNumbers = new ArrayList<Integer>();
        for(int i = 0; i < N; i++){
            sampleNumbers.add(randomNumberExclusiveUpperbound(0,M));
            //System.out.println(sampleNumbers.get(i));
        }
        int numberOfRows = 0;
        if(N%10 != 0){
            numberOfRows = N/10 + 1;
        }
        else
        {
            numberOfRows = N/10;
        }
        for(int row = 0; row < numberOfRows; row++){
            for(int column = 0; column < 10; column++){
                if(row*10+column < N){
                    System.out.printf("%8s",sampleNumbers.get(row*10 + column));
                }
            }
            System.out.println("");
        }
    }
    public static int randomNumberInclusive(int lowerbound, int upperbound){
        int range = upperbound - lowerbound;
        return (int)(Math.random()*(range+1)+lowerbound);
    } 
    public static int randomNumberExclusiveUpperbound(int lowerbound, int upperbound){
        int range = upperbound - lowerbound;
        return (int)(Math.random()*(range)+lowerbound);
    } 
}