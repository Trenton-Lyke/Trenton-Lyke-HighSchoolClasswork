
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.awt.*;
/**
 * Write a description of class Read_File here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Population
{
    private static Canvas canvas;
    private static ArrayList<String> countyNames;
    private static ArrayList<Integer> countyPopulation;
    private static Scanner scan;
    private static ArrayList<Double> percent;
    public static void main(String[] args) throws FileNotFoundException{
        populate();
        scan = new Scanner(System.in);
        percent = new ArrayList<Double>();//store precent with leading digits
        boolean loop = true;
        String s = ""; //string to get user input
        while(loop)//do the loop until the user input is no
        {
            System.out.println("Would you like to look at Texa's population -> yes or no");
            s = scan.nextLine();
            if((s.toLowerCase()).equals("yes"))
            {
                System.out.println("1. Print the data from the file.");
                System.out.println("2. Print Texas total population.");
                System.out.println("3. Randomly choose a county and display its population .");
                System.out.println("4. Find counties population with a leading digit, entered by the user .");
                System.out.println("5. Find total number of counties/percentage of population with each leading digit formatted using printf.");
                System.out.println("6. Find total number of counties/percentage of population with each leading digit formatted using printf and make a graph of the percentages.");
                //add other options
                s= scan.nextLine();
                if(s.equals("1"))
                {
                    printData();
                }
                else if(s.equals("2"))
                {
                    System.out.println("Texas population ->" + findTotal());
                }
                else if(s.equals("3")){
                    randomCounty();
                }
                else if(s.equals("4")){
                    showLeadingDigit();
                }
                else if(s.equals("5")){
                    analysis();
                }
                else if(s.equals("6")){
                    analysis();
                    drawGraph();
                }
                //add additional if else statements
                else{
                    System.out.println("Incorrect input");
                }
            }
            else if((s.toLowerCase()).equals("no"))
            {
                System.out.println("Good bye");
                loop = false;//user wants to stop the loop
            }
            else{
                System.out.println("Invalid Input please enter yes or no: ");
            }
        }
    }
    public static void populate() throws FileNotFoundException{
        File text = new File("TexasCountyPopulation.txt");
        Scanner scan1 = new Scanner(text);
        String line = "";
        countyNames = new ArrayList<String>();
        countyPopulation = new ArrayList<Integer>();
        int lineNumber = 0;
        while(scan1.hasNextLine()){
            line = scan1.nextLine();
            String[] countyInfo = line.split(" ");
            countyNames.add(countyInfo[0]);//save county name into counties array
            countyPopulation.add(Integer.parseInt(countyInfo[2].trim()));//save county population into population array
            lineNumber++;
        }
    }
    public static void printData() throws FileNotFoundException{
        for(int i = 0; i < countyPopulation.size(); i++){
            System.out.printf("%-20s",countyNames.get(i)+" County");
            System.out.printf("%8s",countyPopulation.get(i)+ "\n");
        }
    }
    //method finds and returns total
    public static int findTotal(){
        int total = 0;
        for(int i = 0; i < countyPopulation.size(); i++){
            total += countyPopulation.get(i);
        }
        return total;
    }
    
    public static void randomCounty()
    {
        int value = (int)(Math.random()*countyNames.size());
        System.out.println("Randomly chosen county at index  " + value + " is:  " + countyNames.get(value) + " County and its population is:  " + countyPopulation.get(value));
    }
    
    public static void showLeadingDigit()
    {
        System.out.println("Enter the leading digit 1 -9:  ");
        String leadingDigit = scan.nextLine();
        System.out.println("Showing data with a leading digit of:  " + leadingDigit);
        for(int i = 0; i < countyPopulation.size(); i++){
            if((String.valueOf(countyPopulation.get(i)).substring(0,1)).equals(leadingDigit)){
                System.out.printf("%-20s",countyNames.get(i)+" County");
                System.out.printf("%8s",countyPopulation.get(i) + "\n");
            }
        }
    }
    public static void analysis()
    {
        System.out.printf("%-10s","digit");
        System.out.printf("%-10s","number");
        System.out.printf("percentage\n");
        float total = 0;
         for(int leadingDigit = 1; leadingDigit < 10; leadingDigit++){
            System.out.printf("%3s",leadingDigit);
            int populationTotal = 0;
            int number = 0;
            for(int i = 0; i < countyPopulation.size(); i++){
                if((String.valueOf(countyPopulation.get(i)).substring(0,1)).equals(String.valueOf(leadingDigit))){
                    populationTotal += countyPopulation.get(i);
                    number++;
                }
            }
            System.out.printf("%10s",number);
            double percentage = (double)populationTotal/findTotal();
            percent.add(percentage *100);
            System.out.printf("%12.2f",((percentage*100)));
            System.out.printf("\n");
        }
    }
    //draws graph of percentages of Leading digit representation in Texa's population
    public static void drawGraph() throws FileNotFoundException{
        canvas = new Canvas("Percentage Graph", 500, 500);
        //x axis
        canvas.drawLine(50, 450, 450, 450);
        //y axis
        canvas.drawLine(50, 450, 50, 50);
        //draws increments for y axis
        for(int i = 5; i <=30; i+=5){
            canvas.drawString(Integer.toString(i), 30, 455-10*i);
            canvas.drawLine(45, 450-10*i, 55, 450-10*i);
        }
        //draws lable for y axis
        String yAxisLable = "Percentage of Population";
        for(int i = 0; i < yAxisLable.length(); i++){
            canvas.drawString(yAxisLable.substring(i,i+1), 20, 100+10*i);
        }
        //draws increments fo x axis
        for(int i = 1; i<=9; i++){
            canvas.drawString(Integer.toString(i), 50+40*i, 460);
            
        }
        //draws lable for x axis
        canvas.drawString("Leading Digits of Population", 200, 470);
        //draws title
        canvas.drawString("Leading Digit Representation", 200, 20);
        //draws bar graph for percentages
        for(int i = 1; i<=9; i++){
            canvas.setForegroundColor();
            canvas.fillRectangle(43+40*i,450-(int)(percent.get(i-1)*10),20,(int)(percent.get(i-1)*10));
        }
        
        
    }
    public boolean isIn(String countyName){
       return countyNames.contains(countyName);
    }
}
