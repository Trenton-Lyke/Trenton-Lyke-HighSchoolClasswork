﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compusci2020
{
    class Program
    {
        static void Main(string[] args)
        {
            const double radiusOfCircle = 1;
            const double sideOfSquare = radiusOfCircle * 2;
            const int nPoints = 1000000000;

            Random generator = new Random();
            int nInside = 0;
            for (int i=0; i < nPoints; i++)
            {
                double xCoord = GetRandomCoordinate(radiusOfCircle, sideOfSquare, generator);
                double yCoord = GetRandomCoordinate(radiusOfCircle, sideOfSquare, generator);

                if (xCoord * xCoord + yCoord * yCoord <= radiusOfCircle * radiusOfCircle) {
                    nInside++;
                }

            }

            double ratio = (double)nInside / nPoints;
            double areaOfSquare = sideOfSquare * sideOfSquare;
            double areaOfCircle = ratio * areaOfSquare;

            Console.WriteLine("Area of Circle: " + areaOfCircle);
            Console.ReadKey();
        }

        private static double GetRandomCoordinate(double radiusOfCircle, double sideOfSquare, Random generator)
        {
            return generator.NextDouble() * sideOfSquare - radiusOfCircle;
        }
    }
}
