﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecisionTree
{
    class Program
    {
        private static readonly string path = @"C:\Computational Science Data\";

        static void Main(string[] args)
        {
            // Load training samples
            var signal = DataSet.ReadDataSet(path + "signal.dat");
            var background = DataSet.ReadDataSet(path + "background.dat");



            // Load data sample
            var data = DataSet.ReadDataSet(path + "decisionTreeData.dat");
            StreamWriter file, file2;
            
            //Level 2
            //Level2(signal, background, data, out file, out file2, "Level2.txt", "Level2Signal.txt");

            //Level 3
            //Level3And4(signal, background, data, out file, out file2,"Level3.txt", "Level3Signal.txt", false);

            //Level 4
            Level3And4(signal, background, data, out file, out file2, "Level4.txt", "Level4Signal.txt", true);

        }

        //Creates and uses decision forest developed following the requirements of levels 3 and 4
        private static void Level3And4(DataSet signal, DataSet background, DataSet data, out StreamWriter file, out StreamWriter file2, string fileName, string file2Name, bool prune)
        {
            Forest forest = new Forest(20, prune);
            forest.Train(signal, background);

            foreach (Tree tree in forest.Trees)
            {
                Console.WriteLine(tree.getNumberOfBranchesAndLeaes());
            }
            file = File.CreateText(path + fileName);
            file2 = File.CreateText(path + file2Name);
            file.WriteLine("Event\tPurity");

            for (int i = 0; i < data.Points.Count; ++i)
            {
                double output = forest.RunDataPoint(data.Points[i]);



                file.WriteLine(i.ToString() + '\t' + output.ToString());

            }
            //just to make sure the decision forest isn't way off
            for (int i = 0; i < signal.Points.Count; ++i)
            {
                double output = forest.RunDataPoint(signal.Points[i]);



                file2.WriteLine(i.ToString() + '\t' + output.ToString());

            }
        }
        //Creates and uses decision tree developed following the requirements of level 2
        private static void Level2(DataSet signal, DataSet background, DataSet data, out StreamWriter file, out StreamWriter file2, string fileName, string file2Name)
        {
            Tree tree = new Tree();
            tree.Train(signal, background);

            
            file = File.CreateText(path + "fileName");
            file2 = File.CreateText(path + "file2Name");
            file.WriteLine("Event\tPurity");

            for (int i = 0; i < data.Points.Count; ++i)
            {
                double output = tree.RunDataPoint(data.Points[i]);



                file.WriteLine(i.ToString() + '\t' + output.ToString());

            }
            //just to make sure the decision tree isn't way off
            for (int i = 0; i < signal.Points.Count; ++i)
            {
                double output = tree.RunDataPoint(signal.Points[i]);



                file2.WriteLine(i.ToString() + '\t' + output.ToString());

            }
        }
    }
}
