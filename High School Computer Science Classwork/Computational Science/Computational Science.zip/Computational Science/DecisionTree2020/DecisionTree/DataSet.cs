﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecisionTree
{
    /// <summary>
    /// A collection of DataPoints used for training and evaluating machine learning algorithms
    /// </summary>
    public class DataSet
    {
        Random randomGenerator = new Random();
        /// <summary>
        /// All the points in the set
        /// </summary>
        public List<DataPoint> Points { get; } = new List<DataPoint>();

        /// <summary>
        /// The name of each variable used, in case you are interested
        /// </summary>
        public string[] Names { get; }

        /// <param name="names">An array of the names of each variable</param>
        public DataSet(string[] names)
        {
            Names = names;
        }

        /// <summary>
        /// Add a DataPoint to the Points list
        /// </summary>
        public void AddDataPoint(DataPoint point)
        {
            Points.Add(point);
        }

        private const string header = "DecisionTreeDataSet";

        /// <summary>
        /// Write the entire DataSet to a binary file
        /// </summary>
        public void WriteToFile(string filename)
        {
            using (var file = new BinaryWriter(File.Create(filename)))
            {
                file.Write(header);
                file.Write(this);
            }
        }

        /// <summary>
        /// Read a DataSet from a saved file
        /// </summary>
        static public DataSet ReadDataSet(string filename)
        {
            using (var file = new BinaryReader(File.OpenRead(filename)))
            {
                string fileHeader = file.ReadString();
                if (fileHeader != header)
                    throw new FormatException("Header does not match DataSet header!");

                return file.ReadDataSet();
            }
        }

        /// <summary>
        /// divides DataSet into two DataSets one of the specified fraction of the original DataSet (DataPoints selected at random)
        /// and the other with the rest of the DataPoints
        /// </summary>
        /// <param name="fraction">Fractions of DataPoints in the first DataSet in the DataSet array</param>
        /// <returns>Array of DataSets with two DataSets made up by the DataPoints of the original DataSet</returns>
        public DataSet[] divide(double fraction) {
            DataSet[] partians = new DataSet[] { new DataSet(Names), new DataSet(Names) };
            
            int portion = (int)(fraction * Points.Count);
            int[] randomIndexes = new int[portion];
            for (int i = 0; i < portion; i++) {
                int randomIndex = randomGenerator.Next(0, Points.Count);
                while (randomIndexes.Contains(randomIndex)) {
                    randomIndex = randomGenerator.Next(0, Points.Count);
                }
                randomIndexes[i] = randomIndex;
            }
            for (int i = 0; i < Points.Count; i++) {
                if (randomIndexes.Contains(i))
                {
                    partians[0].AddDataPoint(Points[i]);
                }
                else {
                    partians[1].AddDataPoint(Points[i]);
                }
            }
            return partians;
        }
    }
}
