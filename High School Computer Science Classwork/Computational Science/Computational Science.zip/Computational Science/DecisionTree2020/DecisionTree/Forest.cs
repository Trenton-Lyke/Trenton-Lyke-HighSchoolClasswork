﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DecisionTree
{
    
            
            
    class Forest
    {
        /// <summary>
        /// List of trees making up the random decision forest
        /// </summary>
        public Tree[] Trees { get;  }

        private bool prune;

        /// <summary>
        /// The count of trees taking their weights into account
        /// </summary>
        public double GetWeightedTreeCount() {
            double weightedTreeCount = 0;
            foreach (Tree tree in Trees) {
                weightedTreeCount += tree.Weight;
            }
            return weightedTreeCount;
        } 

        //constructs decissin forest based on the number of decision trees and wether it should be pruned or not
        public Forest(int numberOfTrees, bool prune = false)
        {
            Trees = new Tree[numberOfTrees];
            this.prune = prune;
            
        }

        //trains all the decision trees in the forest based on the misclassified events of the previous decision tree
        public void Train(DataSet signal, DataSet background)
        {
            for (int i = 0; i < Trees.Length; i++)
            {
                Trees[i] = new Tree(prune);

                // Train the tree and get update DataSets
                DataSet[] dataSets = Trees[i].Train(signal, background);
                signal = dataSets[0];
                background = dataSets[1];

                //get the miscassified event weight and use it to update the tree weight and the events' weights
                double misclassifiedEventWeight = getMisclassifiedEventWeight(signal, background, dataSets);
                Trees[i].Weight = Math.Log(misclassifiedEventWeight);
                UpdateEventWeights(dataSets, misclassifiedEventWeight);
            }
        }

        //gets the weights of that the misclassified events will recieve when they enter the next tree
        private static double getMisclassifiedEventWeight(DataSet signal, DataSet background, DataSet[] dataSets)
        {
            double misclassificationFraction = 0;
            foreach (DataSet dataSet in dataSets)
            {
                foreach (DataPoint dataPoint in dataSet.Points)
                {
                    if (dataPoint.IsMisclassified)
                    {
                        misclassificationFraction++;
                    }
                    dataPoint.Weight = 1;
                }
            }
            misclassificationFraction /= (signal.Points.Count + background.Points.Count);
            double misclassifiedEventWeight = (1 - misclassificationFraction) / misclassificationFraction;
            return misclassifiedEventWeight;
        }

        //updates all the events' weights
        private static void UpdateEventWeights(DataSet[] dataSets, double misclassifiedEventWeight)
        {
            foreach (DataSet dataSet in dataSets)
            {
                foreach (DataPoint dataPoint in dataSet.Points)
                {
                    if (dataPoint.IsMisclassified)
                    {
                        dataPoint.Weight = misclassifiedEventWeight;
                    }
                    dataPoint.IsMisclassified = false;
                }
            }
        }

        //runs a dat point throught the forest and returns the purity of the leaf it ends up in
        public double RunDataPoint(DataPoint dp) {
            double overallPurity = 0;
            foreach (Tree tree in Trees) {
                double singleTreePurity = tree.RunDataPoint(dp);
                overallPurity += singleTreePurity * tree.Weight;
            }
            overallPurity /= GetWeightedTreeCount();
            return overallPurity;
        }
        
    }
}
