﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecisionTree
{
    /// <summary>
    /// A leaf or branch of a tree
    /// Does most of the work of decision trees
    /// </summary>
    internal class Leaf
    {
        
        /// <summary>
        /// A pointer to the next leaves, if this is a branch
        /// </summary>
        private Leaf output1 = null;
        /// <summary>
        /// A pointer to the next leaves, if this is a branch
        /// </summary>
        private Leaf output2 = null;
        /// <summary>
        /// The value of the cut that is applied at this branch (unneeded if it is a leaf)
        /// </summary>
        private double split;
        /// <summary>
        /// The index of the variable which is used to make the cut (unneeded if this is a leaf)
        /// </summary>
        private int variable;

        /// <summary>
        /// The number of background training events in this leaf
        /// </summary>
        private int nBackground = 0;
        /// <summary>
        /// The number of signal training events in this leaf
        /// </summary>
        private int nSignal = 0;

        /// <summary>
        /// A default constructor is needed for some applications, but it is generally not sensible
        /// </summary>
        internal Leaf() :
            this(-1, 0) // Default values will generate an error if used
        { }

        /// <param name="variable">The index of the variable used to make the cut</param>
        /// <param name="split">The value of the cut used for the branch</param>
        public Leaf(int variable, double split)
        {
            this.variable = variable;
            this.split = split;
        }

        public Leaf(Leaf node)
        {
            split = node.split;
            variable = node.variable;
            nSignal = node.nSignal;
            nBackground = node.nBackground;
            

            if (node.output1 != null)
            {
                output1 = new Leaf(node.output1);
            }
            else {
                node.output1 = null;
            }
            if (node.output2 != null)
            {
                output2 = new Leaf(node.output2);
            }
            else {
                node.output2 = null;
            }
        }



        /// <summary>
        /// Write the leaf to a binary file
        /// </summary>
        internal void Write(BinaryWriter bw)
        {
            bw.Write(variable);
            bw.Write(split);
            bw.Write(nSignal);
            bw.Write(nBackground);

            bw.Write(IsFinal);
            if (!IsFinal)
            {
                output1.Write(bw);
                output2.Write(bw);
            }
        }

        /// <summary>
        /// Construct a leaf from a binary file
        /// </summary>
        internal Leaf(BinaryReader br)
        {
            variable = br.ReadInt32();
            split = br.ReadDouble();
            nSignal = br.ReadInt32();
            nBackground = br.ReadInt32();

            bool fin = br.ReadBoolean();
            if (!fin)
            {
                output1 = new Leaf(br);
                output2 = new Leaf(br);
            }
        }

        private Random randomGenerator = new Random();

        /// <summary>
        /// Determines if it is a leaf or a branch (true for leaves)
        /// </summary>
        public bool IsFinal => output1 == null || output2 == null;

        /// <summary>
        /// The purity of the leaf
        /// </summary>
        public double Purity => (double)nSignal / (nSignal + nBackground);

        public int getNumberOfBranches()
        {
            if (IsFinal)
            {
                return 0;
            }
            else {
                int numberOfBranches = 1 + output1.getNumberOfBranches() + output2.getNumberOfBranches();
                return numberOfBranches;
            }
        }

        public int getNumberOfBranchesAndLeaves()
        {
            if (IsFinal)
            {
                return 1;
            }
            else
            {
                int numberOfBranches = 1 + output1.getNumberOfBranches() + output2.getNumberOfBranches();
                return numberOfBranches;
            }
        }

        public bool RemoveSingleTreeBranch() {
            if (getNumberOfBranches() == 0)
            {
                return false;
            }
            if (getNumberOfBranches() == 1)
            {
                output1 = null;
                output2 = null;
            }
            else {
                if (output1.getNumberOfBranches() >= 1 && output2.getNumberOfBranches() >= 1)
                {
                    if (randomGenerator.NextDouble() < .5)
                    {
                        output1.RemoveSingleTreeBranch();
                    }
                    else
                    {
                        output2.RemoveSingleTreeBranch();
                    }
                }
                else if (output1.getNumberOfBranches() >= 1)
                {
                    output1.RemoveSingleTreeBranch();
                }
                else {
                    output2.RemoveSingleTreeBranch();
                }
            }
            return true;
        }
        /// <summary>
        /// Calculates the return value for a single data point, forwarding it to other leaves as needed
        /// </summary>
        public double RunDataPoint(DataPoint dataPoint)
        {
            if (IsFinal)
            {
                return Purity;
            }

            if (DoSplit(dataPoint))
            {
                return output1.RunDataPoint(dataPoint);
            }
            else
            {
                return output2.RunDataPoint(dataPoint);
            }
        }

        /// <summary>
        /// Checks to see whether the DataPoint fails or passes the cut
        /// </summary>
        private bool DoSplit(DataPoint dataPoint)
        {
            return dataPoint.Variables[variable] <= split;
        }
        


        /// <summary>
        /// Trains this leaf based on input DataSets for signal and background
        /// </summary>
        public void Train(DataSet signal, DataSet background, DataSet newSignal, DataSet newBackground)
        {
            nSignal = signal.Points.Count;
            nBackground = background.Points.Count;

            // Determines whether this is a final leaf or if it branches
            bool branch = ChooseVariable(signal, background);
            DataSet signalLeft = new DataSet(signal.Names);
            DataSet signalRight = new DataSet(signal.Names);
            DataSet backgroundLeft = new DataSet(background.Names);
            DataSet backgroundRight = new DataSet(background.Names);

            if (branch)
            {
                // Creates a branch
                output1 = new Leaf();
                output2 = new Leaf();



                foreach (var dataPoint in signal.Points)
                {
                    if (DoSplit(dataPoint))
                    {
                        signalLeft.AddDataPoint(dataPoint);
                    }
                    else
                    {
                        signalRight.AddDataPoint(dataPoint);
                    }
                }

                foreach (var dataPoint in background.Points)
                {
                    if (DoSplit(dataPoint))
                    {
                        backgroundLeft.AddDataPoint(dataPoint);
                    }
                    else
                    {
                        backgroundRight.AddDataPoint(dataPoint);
                    }
                }

                // Trains each of the resulting leaves
                output1.Train(signalLeft, backgroundLeft, newSignal, newBackground);
                output2.Train(signalRight, backgroundRight, newSignal, newBackground);
                
            }
            else {
                UpdateWeightsAndMisclassifications(newSignal, newBackground, signal, background);
            }
            
            
            // Do nothing more if it is not a branch
        }

        private static void UpdateWeightsAndMisclassifications(DataSet newSignal, DataSet newBackground, DataSet signal, DataSet background)
        {
            double sidePurity = GetPurity(signal.Points, background.Points);
            if (sidePurity < .5)
            {
                foreach (DataPoint dataPoint in signal.Points)
                {
                    dataPoint.IsMisclassified = true;
                    dataPoint.Weight = 1;
                    newSignal.AddDataPoint(dataPoint);
                }
                foreach (DataPoint dataPoint in background.Points)
                {
                    dataPoint.IsMisclassified = false;
                    dataPoint.Weight = 1;
                    newBackground.AddDataPoint(dataPoint);
                }

            }
            else if (sidePurity > .5)
            {
                foreach (DataPoint dataPoint in signal.Points)
                {
                    dataPoint.IsMisclassified = false;
                    dataPoint.Weight = 1;
                    newSignal.AddDataPoint(dataPoint);
                }
                foreach (DataPoint dataPoint in background.Points)
                {
                    dataPoint.IsMisclassified = true;
                    dataPoint.Weight = 1;
                    newBackground.AddDataPoint(dataPoint);
                }
            }
            else
            {
                foreach (DataPoint dataPoint in signal.Points)
                {
                    dataPoint.IsMisclassified = true;
                    dataPoint.Weight = 1;
                    newSignal.AddDataPoint(dataPoint);
                }
                foreach (DataPoint dataPoint in background.Points)
                {
                    dataPoint.IsMisclassified = true;
                    dataPoint.Weight = 1;
                    newBackground.AddDataPoint(dataPoint);
                }
            }
        }

        /// <summary>
        /// Chooses which variable and cut value to use
        /// </summary>
        /// <returns>True if a branch was created, false if this is a final leaf</returns>
        private bool ChooseVariable(DataSet signal, DataSet background)
        {
            if (signal.Points.Count < 30 || background.Points.Count < 30) {
                return false;
            }
            
            List<List<DataPoint>> signalAndBackgroundDataPointList = new List<List<DataPoint>> {signal.Points,background.Points};
            int bestVariable = 0;
            double bestSplit = double.NaN;
            double largestPurityDifference = double.MinValue;
            
            for (variable=0; variable < signal.Names.Length; variable++)
            {
                double maxVariableValue, minVariableValue;
                GetMaxAndMinVariable(signalAndBackgroundDataPointList, out maxVariableValue, out minVariableValue);

                int numberOfSplits = 500;
                double splitStep = (maxVariableValue - minVariableValue) / numberOfSplits;
                for (split = minVariableValue; split <= maxVariableValue && minVariableValue != maxVariableValue; split += splitStep)
                {
                    List<DataPoint> yesSignalList = new List<DataPoint>();
                    List<DataPoint> noSignalList = new List<DataPoint>();
                    List<DataPoint> yesBackgroundList = new List<DataPoint>();
                    List<DataPoint> noBackgroundList = new List<DataPoint>();
                    SplitIntoSets(signalAndBackgroundDataPointList, yesSignalList, noSignalList, yesBackgroundList, noBackgroundList);
                    if ((yesSignalList.Count + yesBackgroundList.Count) != 0 && (noSignalList.Count + noBackgroundList.Count) != 0)
                    {
                        double yesPurity = GetPurity(yesSignalList, yesBackgroundList);
                        double noPurity = GetPurity(noSignalList, noBackgroundList);
                        double purityDifference = Math.Abs(yesPurity - noPurity);


                        if (purityDifference > largestPurityDifference && !(yesSignalList.Count == 0 || noSignalList.Count == 0 || yesBackgroundList.Count == 0 || noBackgroundList.Count == 0))
                        {
                            largestPurityDifference = purityDifference;
                            bestSplit = split;
                            bestVariable = variable;
                        }

                    }
                }
            }

            if (largestPurityDifference > .01 && largestPurityDifference != double.MinValue) {
                variable = bestVariable;
                split = bestSplit;
                return true;
            }
            return false;


        }

        //split DataSet into different sets based on split and variable
        private void SplitIntoSets(List<List<DataPoint>> signalAndBackgroundDataPointList, List<DataPoint> yesSignalList, List<DataPoint> noSignalList, List<DataPoint> yesBackgroundList, List<DataPoint> noBackgroundList)
        {
            for (int setNumber = 0; setNumber < signalAndBackgroundDataPointList.Count; setNumber++)
            {
                foreach (DataPoint dataPoint in signalAndBackgroundDataPointList[setNumber])
                {
                    if (setNumber == 0)
                    {
                        if (DoSplit(dataPoint))
                        {
                            yesSignalList.Add(dataPoint);
                        }
                        else
                        {
                            noSignalList.Add(dataPoint);
                        }
                    }
                    else
                    {
                        if (DoSplit(dataPoint))
                        {
                            yesBackgroundList.Add(dataPoint);
                        }
                        else
                        {
                            noBackgroundList.Add(dataPoint);
                        }
                    }
                }
            }
        }

        //Gets the maximum and the minimum values of a variable in a given dataset
        private void GetMaxAndMinVariable(List<List<DataPoint>> signalAndBackgroundDataPointList, out double maxVariableValue, out double minVariableValue)
        {
            maxVariableValue = double.MinValue;
            minVariableValue = double.MaxValue;
            foreach (List<DataPoint> setOfDataPoints in signalAndBackgroundDataPointList)
            {
                foreach (DataPoint dataPoint in setOfDataPoints)
                {
                    if (maxVariableValue < dataPoint.Variables[variable])
                    {
                        maxVariableValue = dataPoint.Variables[variable];
                    }
                    if (minVariableValue > dataPoint.Variables[variable])
                    {
                        minVariableValue = dataPoint.Variables[variable];
                    }
                }
            }
        }

        //gets the purity of a leave based on the datapoints in a signal and background list
        private static double GetPurity(List<DataPoint> SignalList, List<DataPoint> BackgroundList)
        {
            return (double)GetWeightedCount(SignalList) / (GetWeightedCount(SignalList) + GetWeightedCount(BackgroundList));
        }

        //gets the count of events in a datapoint list taking there wights into account
        private static double GetWeightedCount(List<DataPoint> dataPoints) {
            double weightedCount = 0;
            foreach (DataPoint dataPoint in dataPoints) {
                weightedCount += dataPoint.Weight;
            }
            return weightedCount;
        }

    }
}
