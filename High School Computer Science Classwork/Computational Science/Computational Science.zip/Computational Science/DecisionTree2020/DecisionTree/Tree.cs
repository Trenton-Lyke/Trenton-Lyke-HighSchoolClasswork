﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecisionTree
{
    /// <summary>
    /// A class to represent a decision tree
    /// The Leaf class does all the work
    /// </summary>
    public class Tree
    {
        /// <summary>
        /// The top of the tree, which is all that is needed - all other leaves are accessed from here
        /// </summary>
        private Leaf headnode;

        public double Weight { get; set; }

        private bool prune;

        public Tree(bool prune)
        {
            headnode = new Leaf();
            Weight = 1;
            this.prune = prune;
        }
        public Tree()
        {
            headnode = new Leaf();
            Weight = 1;
            prune = false;
        }

        private Tree(Leaf givenHeadnode, double weight)
        {
            this.headnode = new Leaf(givenHeadnode);
            Weight = weight;
            

        }

        /// <summary>
        /// Writes the tree to a binary file
        /// </summary>
        public void WriteToFile(string filename)
        {
            using (var bw = new BinaryWriter(File.Create(filename)))
            {
                headnode.Write(bw);
            }
        }

        /// <summary>
        /// Constructs the tree from a binary file
        /// </summary>
        public Tree(string filename)
        {
            using (var br = new BinaryReader(File.OpenRead(filename)))
            {
                headnode = new Leaf(br);
            }
        }

        /// <summary>
        /// Trains the tree on signal and background samples
        /// </summary>
        public DataSet[] Train(DataSet signal, DataSet background )
        {
            if (prune)
            {

                int repititions = 10;
                DataSet[] signalPartians;
                DataSet[] backgroundPartians;
                DataSet[] trainingSets;
                DataSet[] testingSets;
                double ultimateComplexityPenalty = 0;
                for (int i = 0; i < repititions; i++)
                {

                    signalPartians = signal.divide((double)2 / 3);
                    backgroundPartians = background.divide((double)2 / 3);
                    trainingSets = new DataSet[] { signalPartians[0], backgroundPartians[0] };
                    testingSets = new DataSet[] { signalPartians[1], backgroundPartians[1] };
                    headnode.Train(trainingSets[0], trainingSets[1], new DataSet(signal.Names), new DataSet(background.Names));
                    int minNumberOfMisclassifiedEvents = int.MaxValue;
                    double bestComplexityPenalty = 0;
                    for (double k = 0; k < 100; k += 1)
                    {
                        Tree tree = getBestPrunedTree(k, trainingSets);
                        int numberOfMisclassifiedEvents = tree.getNumberOfMisclassifiedEvents(1, testingSets[0]) + tree.getNumberOfMisclassifiedEvents(0, testingSets[1]);
                        if (numberOfMisclassifiedEvents < minNumberOfMisclassifiedEvents)
                        {
                            minNumberOfMisclassifiedEvents = numberOfMisclassifiedEvents;
                            bestComplexityPenalty = k;
                        }
                    }
                    ultimateComplexityPenalty += bestComplexityPenalty;

                }
                ultimateComplexityPenalty /= repititions;
                headnode = getBestPrunedTree(ultimateComplexityPenalty, new DataSet[] { signal, background }).headnode;
            }
            else {
                headnode.Train(signal, background, new DataSet(signal.Names), new DataSet(background.Names));
            }
            return getUpdatedDataSets(new Tree(headnode, Weight),signal,  background);

        }

        /// <summary>
        /// Calculates the value for a single DataPoint
        /// Assumes the tree is trained already
        /// </summary>
        public double RunDataPoint(DataPoint dp)
        {
            return headnode.RunDataPoint(dp);
        }

        //gets the number of branches of a tree
        public int getNumberOfBranches() {
            return headnode.getNumberOfBranches();
        }

        //gets the number of branches and leaves of a tree
        public int getNumberOfBranchesAndLeaes()
        {
            return headnode.getNumberOfBranchesAndLeaves();
        }

        //prunes a tree by one branch (i.e. changes one branch to a leaf)
        public bool RemoveSingleTreeBranch() {
            return headnode.RemoveSingleTreeBranch();
        }

        //returns a list of trees filled with the possibly pruned trees
        public List<Tree> getPrunedTreeList() {
            List<Tree> prunedTreeList = new List<Tree>();
            bool wasPruned;
            Tree treeForPruning = new Tree(headnode, Weight);
            do {
                prunedTreeList.Add(new Tree(treeForPruning.headnode, treeForPruning.Weight));
                wasPruned = treeForPruning.RemoveSingleTreeBranch();
            } while (wasPruned);
            return prunedTreeList;
        }
        
        //gets the best pruned tree from a trees prune list based on a given complexity penalty and a training set
        public Tree getBestPrunedTree(double complexityPenalty, DataSet[] trainingSets) {
            List<Tree> prunedTreeList = getPrunedTreeList();
            double minErrorComplexity = double.MaxValue;
            Tree bestTree = new Tree();
            for (int i = 0; i < prunedTreeList.Count; i++) {
                double errorComplexity = prunedTreeList[i].getNumberOfMisclassifiedEvents(0, trainingSets[1]) + prunedTreeList[i].getNumberOfMisclassifiedEvents(1, trainingSets[0]) + complexityPenalty * prunedTreeList[i].getNumberOfBranches();
                if (errorComplexity < minErrorComplexity) {
                    minErrorComplexity = errorComplexity;
                    bestTree = prunedTreeList[i];
                }
            }
            return bestTree;
        }

        //gets the number of misclassified events run through a tree based on the correct classification and a dataset
        public int getNumberOfMisclassifiedEvents(int correctClassification, DataSet dataSet) {
            int numberOfMisclassifications = 0;
            foreach (DataPoint dataPoint in dataSet.Points) {
                double purity = RunDataPoint(dataPoint);
                if (correctClassification == 0)
                {
                    if (purity > .5) {
                        numberOfMisclassifications++;
                    }
                }
                else {
                    if (purity < .5)
                    {
                        numberOfMisclassifications++;
                    }
                }
                if (purity == .5) {
                    numberOfMisclassifications++;
                }
            }
            return numberOfMisclassifications;
            
        }

        //labels the misclassified events
        public DataSet lableMisclassifiedEvents(int correctClassification, DataSet dataSet)
        {
            
            foreach (DataPoint dataPoint in dataSet.Points)
            {
                double purity = RunDataPoint(dataPoint);
                if (correctClassification == 0)
                {
                    if (purity > .5)
                    {
                        dataPoint.IsMisclassified = true;
                    }
                    else if(purity < .5)
                    {
                        dataPoint.IsMisclassified = false;
                    }
                }
                else
                {
                    if (purity < .5)
                    {
                        dataPoint.IsMisclassified = true;
                    }
                    else if (purity > .5)
                    {
                        dataPoint.IsMisclassified = false;
                    }
                }
                if (purity == .5)
                {
                    dataPoint.IsMisclassified = true;
                }
            }
            return dataSet;

        }

        //gets the updated datasets by updating event and tree weights
        public DataSet[] getUpdatedDataSets(Tree tree, DataSet signal, DataSet background) {
            double misclassifiedFraction = (double)(tree.getNumberOfMisclassifiedEvents(1, signal) + tree.getNumberOfMisclassifiedEvents(0, background)) / (signal.Points.Count + background.Points.Count);
            double eventWeight = (1 - misclassifiedFraction) / misclassifiedFraction;
            tree.Weight = Math.Log(eventWeight);
            signal = lableMisclassifiedEvents(1, signal);
            background = lableMisclassifiedEvents(0, background);
            DataSet[] dataSets = new DataSet[] { signal, background };
            foreach (DataSet dataSet in dataSets) {
                foreach (DataPoint dataPoint in dataSet.Points) {
                    if (dataPoint.IsMisclassified)
                    {
                        dataPoint.Weight = eventWeight;
                    }
                    else {
                        dataPoint.Weight = 1;
                    }
                }
            }
            return dataSets;
        }
    }
}
