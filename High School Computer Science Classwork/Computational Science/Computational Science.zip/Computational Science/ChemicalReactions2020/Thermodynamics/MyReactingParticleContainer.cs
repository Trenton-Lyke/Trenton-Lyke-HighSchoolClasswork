﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Text;

namespace Thermodynamics
{
    public class MyReactingParticleContainer : ReactingParticleContainer
    {
      
                public MyReactingParticleContainer(double side, double collisionRadius) :
            base(side, collisionRadius)
        {
           
            
        }

        protected override void React(Particle particle, List<Particle> nearby)
        {
            //Level 1
            //Level1(particle, nearby);

            //Level 2 and 3
            //Level2And3(particle, nearby);

            //Level 4
            Level4(particle, nearby);

        }

        //logic for react method for level 1
        private void Level1(Particle particle, List<Particle> nearby)
        {
            foreach (Particle otherParticle in nearby)
            {
                if (particle.Info.Name != "NH4Cl" && otherParticle.Info.Name != "NH4Cl" && particle.Info.Name != otherParticle.Info.Name)
                {
                    AddParticle("NH4Cl", (particle.Position + nearby[0].Position) / 2, (particle.Momentum + nearby[0].Momentum) / (particle.Info.Mass + nearby[0].Info.Mass));
                    RemoveParticle(particle);
                    RemoveParticle(otherParticle);
                    break;
                }
            }
        }

        //logic for react method for level 2 and 3
        private void Level2And3(Particle particle, List<Particle> nearby)
        {
            String catalyst = "CA";
            Dictionary<string, List<Particle>> particles = new Dictionary<string, List<Particle>>();
            
            particles.Add(catalyst, new List<Particle>());
            double activationEnergy = 3e-20;
            foreach (Particle otherParticle in nearby)
            {
                if (otherParticle.Info.Name==catalyst) {
                    activationEnergy = 0;
                }
            }
            
            
            switch (particle.Info.Name)
            {
                case "CO2":
                    AttemptForwardReact(particle, nearby, "H2O", "H2O", "HCO3", "H3O", activationEnergy);
                    break;
                case "H2O":
                    AttemptForwardReact(particle, nearby, "H2O", "CO2", "HCO3", "H3O", activationEnergy);
                    break;
                case "HCO3":
                    AttemptReverseReact(particle, nearby, "H3O", "H2O", "H2O", "CO2", activationEnergy);
                    break;
                case "H3O":
                    AttemptReverseReact(particle, nearby, "HCO3", "H2O", "H2O", "CO2", activationEnergy);
                    break;
            }
        }

        //logic for react method for level 4
        private void Level4(Particle particle, List<Particle> nearby) {
            List<Reaction> reactions = new List<Reaction>() { new Reaction("C4H4O5+C23H38N7O17P3S+H2O=C21H36N7O16P3S+C6H8O7", 0, 0), new Reaction("C6H8O7=H2O+C6H6O6", 0, 0), new Reaction("H2O+C6H6O6=IC6H8O7", 0, 0), new Reaction("IC6H8O7+NAD=CO2+NADH+H+C5H6O5", 0, 0), new Reaction("C5H6O5+NAD+C21H36N7O16P3S=CO2+NADH+H+C25H40N7O19P3S", 0, 0), new Reaction("C25H40N7O19P3S+GDP+Pi+H2O=GTP+C21H36N7O16P3S+C4H6O4", 0, 0), new Reaction("C4H6O4+FAD=FADH2+C4H4O4", 0, 0), new Reaction("C4H4O4+H2O=C4H6O5", 0, 0), new Reaction("C4H6O5+NAD=NADH+H+C4H4O5", 0, 0) };

            foreach (Reaction aReaction in reactions)
            {
                IndividualReact(particle, nearby, aReaction);
            }
        }

        //checks and reacts based on a specific reaction for level 4
        private void IndividualReact(Particle particle, List<Particle> nearby, Reaction aReaction)
        {
            List<int> reactantIndexes = aReaction.GetReactantIndexes(particle, nearby);
            List<string> productNames = aReaction.GetProductNames();

            if (reactantIndexes != null)
            {
                List<Particle> reactants = new List<Particle>();
                reactants.Add(particle);
                List<Particle> products = new List<Particle>();
                foreach (int index in reactantIndexes)
                {
                    reactants.Add(nearby[index]);
                }
                foreach (string name in productNames)
                {
                    products.Add(new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[name]));
                }
                if (HasRequiredEnergy(reactants, aReaction.getActivationEnergy()))
                {
                    for (int k = 0; k < nearby.Count; k++)
                    {
                        if (!reactantIndexes.Contains(k))
                        {
                            nearby[k].Velocity += aReaction.getSign() * nearby[k].Velocity.UnitVector() * 1000;
                        }
                    }
                    replaceParticles(reactants, products);
                }
            }
        }

        //checks if the reactants have enough energy to react
        private bool HasRequiredEnergy(List<Particle> particles, double activationEnergy)
        {
            double KESum = 0;
            foreach (Particle particle in particles)
            {
                KESum += particle.KineticEnergy;
            }
            Console.WriteLine(KESum);
            if (KESum >= activationEnergy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //replaces reactants with products of reaction
        private void replaceParticles(List<Particle> reactants, List<Particle> products) {
            Vector positionSum = Vector.NullVector();
            Vector momentumSum = Vector.NullVector();
            double massSum = 0;
            foreach (Particle reactant in reactants) {
                positionSum += reactant.Position;
                momentumSum += reactant.Momentum;
                RemoveParticle(reactant);
            }
            
            Vector centerPosition = positionSum / reactants.Count;
            Vector momentumPartian = momentumSum / products.Count;

            foreach (Particle product in products) {
                AddParticle(product.Info.Name, centerPosition,  momentumPartian / product.Info.Mass);
                
                
            }
            
        }

        //checks and reacts based on levels 2 and 3's forward reaction
        public void AttemptForwardReact(Particle particle, List<Particle> nearby, string reactant2 , string reactant3, string product1, string product2, double activationEnergy) {
             for (int i = 0; i < nearby.Count; i++)
                {
                    if (nearby[i].Info.Name == reactant2)
                    {
                        for (int j = 0; j < nearby.Count; j++)
                        {
                            if (nearby[j].Info.Name == reactant3)
                            {
                                List<Particle> reactants = new List<Particle>() { particle, nearby[i], nearby[j] };
                                List<Particle> products = new List<Particle>() { new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product1]), new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product2]) };

                                if (i != j && HasRequiredEnergy(reactants, activationEnergy))
                                {
                                for (int k = 0; k < nearby.Count; k++) {
                                    if (k != i && k != j) {
                                        nearby[k].Velocity -= nearby[k].Velocity.UnitVector()*1000;
                                    }
                                }
                                    replaceParticles(reactants, products);
                                    return;
                                }
                            }
                        }
                    }
                }
            
        }

        //checks and reacts based on levels 2 and 3's reverse reaction
        public void AttemptReverseReact(Particle particle, List<Particle> nearby, string reactant2, string product1, string product2, string product3, double activationEnergy)
        {
            for (int i = 0; i < nearby.Count; i++)
            {
                if (nearby[i].Info.Name == reactant2)
                {
                    
                            List<Particle> reactants = new List<Particle>() { particle, nearby[i]};
                            List<Particle> products = new List<Particle>() { new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product1]), new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product2]), new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product3]) };

                            if ( HasRequiredEnergy(reactants, activationEnergy))
                            {
                                for (int k = 0; k < nearby.Count; k++)
                                {
                                    if (k != i )
                                    {
                                        nearby[k].Velocity += nearby[k].Velocity.UnitVector() * 1000;
                                    }
                                }
                                replaceParticles(reactants, products);
                                return;
                            }
                        
                }
            }

        }

    }

        
    
    
}
