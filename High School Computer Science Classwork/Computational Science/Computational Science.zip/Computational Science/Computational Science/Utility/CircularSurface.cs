﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utility
{
    public class CircularSurface
    {

        public List<Point> pointsInCircle { get; }

        public CircularSurface(double radius, Point centerPoint)
        {
            double angleStep = 1;
            double radiusStep = 1;
            for (double angle = 0; angle < 2 * Math.PI; angle += angleStep)
            {
                for (double increasingRadius = 0; increasingRadius <= radius; increasingRadius += radiusStep)
                {
                    double Xvalue = centerPoint.X + (radius * Math.Cos(angle));
                    double Yvalue = centerPoint.Y + (radius * Math.Sin(angle));
                    Point pointInCircle = new Point(Xvalue, Yvalue, centerPoint.Z);
                    pointsInCircle.Add(pointInCircle);
                }
            }
        }
    }
}
