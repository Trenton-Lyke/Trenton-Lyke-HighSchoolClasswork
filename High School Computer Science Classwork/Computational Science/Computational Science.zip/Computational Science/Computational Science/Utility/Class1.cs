﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utility
{
    public class Vector
    {
        /// <summary>
        /// returns and sets the x component of the vector
        /// </summary>
        public double X { get; set; }
        /// <summary>
        /// returns and sets the y component of the vector
        /// </summary>
        public double Y { get; set; }
        /// <summary>
        /// returns and sets the z component of the vector
        /// </summary>
        public double Z { get; set; }

        /// <summary>
        /// constructor for vector object
        /// </summary>
        /// <param name="x">x component</param>
        /// <param name="y">y component</param>
        /// <param name="z">z component</param>
        public Vector(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        /// <summary>
        /// returns the magnitude of the vector
        /// </summary>
        public double Magnitude => Math.Sqrt(X * X + Y * Y + Z * Z);

        /// <summary>
        /// returns the unit vector of the vector
        /// </summary>
        public Vector UnitVector => new Vector(X / Magnitude, Y / Magnitude, Z / Magnitude);

        /// <summary>
        /// finds the dot product of two vectors
        /// </summary>
        /// <param name="vec1">First vector</param>
        /// <param name="vec2">Second vector</param>
        /// <returns>returns dot product of two vectors</returns>
        static public double DotProduct(Vector vec1, Vector vec2)
        {
            return vec1.X * vec2.X + vec1.Y * vec2.Y + vec1.Z * vec2.Z;
        }
        /// <summary>
        /// Finds the sum of two vectors
        /// </summary>
        /// <param name="vec1">First vector</param>
        /// <param name="vec2">Second vector</param>
        /// <returns>returns the sum of two vectors</returns>
        static public Vector operator +(Vector vec1, Vector vec2)
        {
            return new Vector(
            vec1.X + vec2.X,
            vec1.Y + vec2.Y,
            vec1.Z + vec2.Z
            );
        }
        /// <summary>
        /// Finds the difference of two vectors
        /// </summary>
        /// <param name="vec1">First vector</param>
        /// <param name="vec2">Second vector</param>
        /// <returns>returns the difference of two vectors</returns>
        static public Vector operator -(Vector vec1, Vector vec2)
        {
            return vec1 + -vec2;
        }
        /// <summary>
        /// Finds the vector with the components with the opposite sign
        /// </summary>
        /// <param name="vec">A vector</param>
        /// <returns>returns the vector with an opposite sign components</returns>
        static public Vector operator -(Vector vec)
        {
            return -1 * vec;
        }

        /// <summary>
        /// Finds the product of a vector multiplied by scalar
        /// </summary>
        /// <param name="vec">A vector</param>
        /// <param name="scalar">A scalar</param>
        /// <returns>returns the product of a vector multiplied by the scalar</returns>
        static public Vector operator *(Vector vec, double scalar)
        {
            return new Vector(
            vec.X * scalar,
            vec.Y * scalar,
            vec.Z * scalar
            );
        }
        /// <summary>
        /// Finds the product of a vector multiplied by scalar
        /// </summary>
        /// <param name="vec">A vector</param>
        /// <param name="scalar">A scalar</param>
        /// <returns>returns the product of a vector multiplied by the scalar</returns>
        static public Vector operator *(double scalar, Vector vec)
        {
            return vec * scalar;
        }
        /// <summary>
        /// Finds the quotien of a vector divided by scalar
        /// </summary>
        /// <param name="vec">A vector</param>
        /// <param name="scalar">A scalar</param>
        /// <returns>returns the quotien of a vector divided by scalar</returns>
        static public Vector operator /(Vector vec, double scalar)
        {
            return vec * (1 / scalar);
        }
        /// <summary>
        /// Finds if vectors are equal
        /// </summary>
        /// <param name="vec1">First vector</param>
        /// <param name="vec2">Second vector</param>
        /// <returns>returns boolean for if vectors are equal</returns>
        static public bool operator ==(Vector vec1, Vector vec2)
        {
            if (vec1.X == vec2.X && vec1.Y == vec2.Y && vec1.Z == vec2.Z)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// Finds if vectors are not equal
        /// </summary>
        /// <param name="vec1">First vector</param>
        /// <param name="vec2">Second vector</param>
        /// <returns>returns boolean for if vectors are not equal</returns>
        static public bool operator !=(Vector vec1, Vector vec2)
        {
            return !(vec1 == vec2);
        }
        /// <summary>
        /// creates a string from a vector
        /// </summary>
        /// <returns>returns the vector's string equivalent</returns>
        public override string ToString()
        {
            return "" + X + ", " + Y + ", " + Z;
        }
    }
}
