﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utility
{
    public class Vector
    {
        //getters and setter functions
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        //constructor
        public Vector(double x, double y, double z) {
            X = x;
            Y = y;
            Z = z;
        }

        //magnitude property
        public double Magnitude => Math.Sqrt(X * X + Y * Y + Z * Z);

        //unit vector property
        public Vector UnitVector => new Vector(X / Magnitude, Y / Magnitude, Z / Magnitude);

        /// <summary>
        /// Dot product of two vectors
        /// </summary>
        /// <param name="vec1"></param>
        /// <param name="vec2"></param>
        /// <returns></returns>
        static public double DotProduct(Vector vec1, Vector vec2) {
            return vec1.X * vec2.X + vec1.Y * vec2.Y +vec1.Z * vec2.Z;
        }
        /// <summary>
        /// Adds two vectors
        /// </summary>
        /// <param name="vec1"></param>
        /// <param name="vec2"></param>
        /// <returns></returns>
        static public Vector operator+(Vector vec1, Vector vec2) {
            return new Vector(
            vec1.X + vec2.X,
            vec1.Y + vec2.Y,
            vec1.Z + vec2.Z
            );
        }
        /// <summary>
        /// subtracts two vectors
        /// </summary>
        /// <param name="vec1"></param>
        /// <param name="vec2"></param>
        /// <returns></returns>
        static public Vector operator -(Vector vec1, Vector vec2)
        {
            return vec1 + -vec2;
        }
        /// <summary>
        /// makes vector have opposite sign components
        /// </summary>
        /// <param name="vec"></param>
        /// <returns></returns>
        static public Vector operator -(Vector vec)
        {
            return -1 * vec;
        }

        /// <summary>
        /// multiplies vector by scalar
        /// </summary>
        /// <param name="vec"></param>
        /// <param name="scalar"></param>
        /// <returns></returns>
        static public Vector operator *(Vector vec, double scalar)
        {
            return new Vector(
            vec.X * scalar,
            vec.Y * scalar,
            vec.Z * scalar
            );
        }
        /// <summary>
        /// multiplies a vector by a scalar
        /// </summary>
        /// <param name="scalar"></param>
        /// <param name="vec"></param>
        /// <returns></returns>
        static public Vector operator *(double scalar, Vector vec) {
            return vec * scalar;
        }
        /// <summary>
        /// divides a vector by a scalar
        /// </summary>
        /// <param name="vec"></param>
        /// <param name="scalar"></param>
        /// <returns></returns>
        static public Vector operator /(Vector vec, double scalar)
        {
            return vec * (1 / scalar);
        }
        /// <summary>
        /// returns boolean for if vectors are equal
        /// </summary>
        /// <param name="vec1"></param>
        /// <param name="vec2"></param>
        /// <returns></returns>
        static public bool operator ==(Vector vec1, Vector vec2)
        {
            if (vec1.X == vec2.X && vec1.Y == vec2.Y && vec1.Z == vec2.Z)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// returns boolean for if the vectors are not equal
        /// </summary>
        /// <param name="vec1"></param>
        /// <param name="vec2"></param>
        /// <returns></returns>
        static public bool operator !=(Vector vec1, Vector vec2)
        {
            return !(vec1 == vec2);
        }
        /// <summary>
        /// creates a string from a vector
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return ""+X+", "+Y +", "+ Z;
        }
    }
}
