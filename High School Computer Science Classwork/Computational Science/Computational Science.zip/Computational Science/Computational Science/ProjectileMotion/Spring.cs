﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    public class Spring
    {

        public Spring(Vector initialPosition, Vector unstretchedSpringLength, double springConstant)
        {
            Position = initialPosition;
            UnstretchedSpringLength = unstretchedSpringLength;
            SpringConstant = springConstant;
        }
        /// <summary>
        /// returns and sets the vector for the position of the projectile
        /// </summary>
        public Vector Position { get; set; }
        /// <summary>
        /// returns the spring constant of the worlds spring
        /// </summary>
        public double SpringConstant { get; }
        /// <summary>
        /// returns the unstretched spring length of the worlds spring
        /// </summary>
        public Vector UnstretchedSpringLength { get; }
    }
}
