﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    class Driver
    {
        /// <summary>
        /// simulates projectiles in a world
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {


            //LevelI();

            //LevelII();

            //LevelIII();

        }


        /// <summary>
        /// simulates a projectile moving along the x and z  with gravity
        /// </summary>
        /*static void LevelI()
        {

            Projectile projectile1 = new Projectile(new Vector(0, 0, 0), new Vector(10 * Math.Cos(Math.PI / 4), 0, 10 * Math.Cos(Math.PI / 4)), new Vector(0, 0, 0), 0, 5);

            List<Projectile> projectiles = new List<Projectile>();
            projectiles.Add(projectile1);
            World world = new World(0, new Vector(0, 0, -9.8), 0, new Vector(0, 0, 0), projectiles);

            world.Simulate(1.5, .01);
        }

        /// <summary>
        /// simulates a projectile moving along the x and z  with gravity and air resistance
        /// </summary>
        static void LevelII()
        {

            Projectile projectile1 = new Projectile(new Vector(0, 0, 0), new Vector(10 * Math.Cos(Math.PI / 4), 0, 10 * Math.Cos(Math.PI / 4)), new Vector(0, 0, 0), .3, 5);
            Projectile projectile2 = new Projectile(new Vector(0, 0, 0), new Vector(10 * Math.Cos(Math.PI / 4), 0, 10 * Math.Cos(Math.PI / 4)), new Vector(0, 0, 0), .3, 5);

            List<Projectile> projectiles = new List<Projectile>();
            projectiles.Add(projectile1);
            projectiles.Add(projectile2);
            World world = new World(0, new Vector(0, 0, -9.8), 0, new Vector(0, 0, 0), projectiles);

            world.Simulate(1.31, .01);

        }
        /// <summary>
        /// simulates a projectile on a spring moving along the x, y, and z axises with gravity and air resistance
        /// </summary>
        static void LevelIII()
        {
            Projectile projectile1 = new Projectile(new Vector(1, 1, 1), new Vector(-2, 1, 3), new Vector(0, 0, 0), .3, 5);

            List<Projectile> projectiles = new List<Projectile>();
            projectiles.Add(projectile1);

            World world = new World(0, new Vector(0, 0, -9.8), 2, new Vector(1 / Math.Sqrt(3), 1 / Math.Sqrt(3), 1 / Math.Sqrt(3)), projectiles);

            world.Simulate(35, .01);

        }*/
    }    
}
