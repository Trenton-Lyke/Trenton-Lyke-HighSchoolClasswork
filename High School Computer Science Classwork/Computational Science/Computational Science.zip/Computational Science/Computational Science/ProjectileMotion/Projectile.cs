﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    public class Projectile
    {
        public Projectile(Vector initialPosition, Vector initialVelocity, Vector initialAcceleration, double dragConstant, double mass) {
            Position = initialPosition;
            Velocity = initialVelocity;
            Acceleration = initialAcceleration;
            DragConstant = dragConstant;
            Mass = mass;

        }
        /// <summary>
        /// returns and sets the vector for the position of the projectile
        /// </summary>
        public Vector Position { get; set; }
        /// <summary>
        /// returns and sets the vector for the velocity of the projectile
        /// </summary>
        public Vector Velocity { get; set; }
        /// <summary>
        /// returns and sets the vector for the acceleration of the projectile
        /// </summary>
        public Vector Acceleration { get; set; }
        /// <summary>
        /// returns the drag constant of the projectile
        /// </summary>
        public double DragConstant { get;}
        /// <summary>
        /// returns the mass of the projectile
        /// </summary>
        public double Mass  { get; }
        /// <summary>
        /// updates the projectiles position and velocity
        /// </summary>
        /// <param name="changeInTime">the elapsed time since the last update</param>
        public void Update(double changeInTime) {
            Vector averageVelocity = GetAverageVelocity(changeInTime);
            Position += changeInTime * Velocity;
            Velocity = GetNewVelocity(changeInTime);
        }

        /// <summary>
        /// Gets the Vector for the new velocity of the projectile
        /// </summary>
        /// <param name="velocity">Vector for the projectile's velocity</param>
        /// <param name="changeInTime">Amount of time that the projectile has been accelerating</param>
        /// <param name="acceleration">Vector for the acceleration of the projectile</param>
        /// <returns>The Vector for the new velocity</returns>
        private Vector GetNewVelocity(double changeInTime)
        {
            Vector newVelocity = Velocity + changeInTime * Acceleration;
            return newVelocity;
        }
        /// <summary>
        /// Gets the Vector for the average velocity of a projectile after accelerating for a certain timespan
        /// </summary>
        /// <param name="velocity">Vector for the projectile's velocity</param>
        /// <param name="changeInTime">Amount of time that the projectile has been accelerating</param>
        /// <param name="acceleration">Vector for the acceleration of the projectile</param>
        /// <returns>The Vector for the average velocity</returns>
        /// <returns>The vector for the average velocity</returns>
        private Vector GetAverageVelocity(double changeInTime)
        {
            Vector newVelocity = GetNewVelocity(changeInTime);
            Vector averageVelocity = (Velocity + newVelocity) / 2;
            return averageVelocity;
        }

    }
}
