﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    public class World
    {
        /// <summary>
        /// Constructor for the world
        /// </summary>
        /// <param name="time">Overall elapsed time</param>
        /// <param name="gravitationalAcceleration">vector for acceleration due to gravity</param>
        /// <param name="springConstant">spring constant</param>
        /// <param name="unstretchedSpringLengths">unstretched spring length of springs</param>
        /// <param name="projectiles">projectiles in the world</param>
        public World(double time, Vector gravitationalAcceleration, List<Spring> springs, List<Projectile> projectiles)
        {
            Time = time;
            GravitationalAcceleration = gravitationalAcceleration;
            Springs = springs;
            Projectiles = projectiles;
        }
        /// <summary>
        /// returns and sets the elapsed time in the world
        /// </summary>
        public double Time { get; set; }
        /// <summary>
        /// returns the acceleration due to gravity in the world
        /// </summary>
        public Vector GravitationalAcceleration { get; }
      
        /// <summary>
        /// returns and sets the list of projectiles in the world
        /// </summary>
        public List<Projectile> Projectiles { get; set; }


        public List<Spring> Springs { get; set; }
        /// <summary>
        /// Updates all the projectiles accelerations and has the projectiles update their positions and velocities based on the change in time
        /// </summary>
        /// <param name="changeInTime">elapsed time since last update</param>
        /// <param name="sw">stream writer that writes in the document</param>
        public void Update(double changeInTime/*, StreamWriter sw*/)
        {
            for (int i = 0; i < Projectiles.Count(); i++ )
            {
                
                double displacementFromUnstretchedPosition = (Projectiles[i].Position.Magnitude - (Springs[i].UnstretchedSpringLength + Springs[i].Position).Magnitude);
                Vector projectilePositionUnitVector = Projectiles[i].Position.UnitVector;
                if (Projectiles[i].Position.Magnitude == 0) {
                    projectilePositionUnitVector = new Vector(0,0,0);
                }
                    Vector springAcceleration = (-Springs[i].SpringConstant * (projectilePositionUnitVector * displacementFromUnstretchedPosition)) / Projectiles[i].Mass;
                    double airResistanceAccelerationMagnitude = (Projectiles[i].DragConstant * Vector.DotProduct(Projectiles[i].Velocity, Projectiles[i].Velocity) / Projectiles[i].Mass);
                    Vector airResistanceAcceleration = airResistanceAccelerationMagnitude * -Projectiles[i].Velocity.UnitVector;

                    Projectiles[i].Acceleration = springAcceleration + GravitationalAcceleration + airResistanceAcceleration;
                    Projectiles[i].Update(changeInTime);
                    //sw.Write(Time + "\t" + projectile.Position.X + "\t" + projectile.Position.Y + "\t" + projectile.Position.Z + "\t" + projectile.Position.Magnitude + "\t" + projectile.Velocity.X + "\t" + projectile.Velocity.Y + "\t" + projectile.Velocity.Z + "\t" + projectile.Velocity.Magnitude + "\t" + projectile.Acceleration.X + "\t" + projectile.Acceleration.Y + "\t" + projectile.Acceleration.Z + "\t" + projectile.Acceleration.Magnitude+ "\t");
            }
            if (Springs.Count() > 1)
            {
                Springs[1].Position = Projectiles[0].Position;
            }
            //sw.WriteLine("");
            Time += changeInTime;
        }
        /// <summary>
        /// Continually updates the time and calls the update method untill the time limit is reached
        /// </summary>
        /// <param name="totalTime">time limit for simulation</param>
        /// <param name="changeInTime">elapsed time between updates</param>
        public void Simulate(double totalTime, double changeInTime)
        {
            /*using (StreamWriter sw = File.CreateText(@"C:\imsa\output.txt"))
            {*/
                foreach (var projectile in Projectiles)
                {
                    //sw.Write("Time\tx\ty\tz\tDistance\tvx\tvy\tvz\tSpeed\tax\tay\taz\tm_Acc\t");
                }
                //sw.WriteLine("");
                while (Time <= totalTime)
                {
                    Update(changeInTime);

                }
           //}
        }
        //not sure if neccessary for right now
        /*
        public void AddProjectile(Projectile projectile) {
            Projectiles.Add(projectile);
        }
        */
    }
}
