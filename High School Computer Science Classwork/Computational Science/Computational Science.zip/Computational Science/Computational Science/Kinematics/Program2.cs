﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace Kinematics
{
    class Program2
    {
        static void Main(string[] args)
        {
            Vector vec1 = new Vector(1, 2, 3);
            Vector vec2 = new Vector(4, 5, 6);
            Vector vec3 = vec1 - vec2;
            /*
            Console.ReadKey();*/
            //calls function for level1's task
            level1();

            //calls function for level2's task
            //level2();

            //calls function for level3's task
            //level3();

            //calls function for level4's task
            //challenge();
        }

        //simulates an object moving at a constant velocity
        static void level1() {

            //constant varibles in simulation
            decimal velocity = 1;
            const decimal changeInTime = (decimal).1;
            const int timeInterval = 100;
            
            //dynamic variables in simulation
            decimal position = -1;
            decimal pastTime = 0;

            //displays coloumn titles
            Console.WriteLine("{0,-10} {1,-15} {2,-15}", "Time(s)", "Position(m)", "Velocity (m/s)");
            
            //loops until the current time reaches the specified time interval
            for (decimal currentTime = 0; currentTime <= timeInterval; currentTime += changeInTime)
            {
                
                //calculates position
                position += (currentTime - pastTime) * (velocity +  position * position);
                velocity = position * position;
                //displays table entry with information about the objects motion
                Console.WriteLine("{0,-10} {1,-15} {2,-15}", currentTime, position, velocity);

                //sets the past time to the current time for the next iteration
                pastTime = currentTime;
            }
            Console.ReadKey();
        }

        //simulates an object moving with a constant acceleration
        static void level2()
        {

            //constant varibles in simulation
            const decimal acceleration = (decimal)9.8;
            const decimal changeInTime = (decimal).1;
            const int timeInterval = 100;

            //dynamic variables in simulation
            decimal velocity = 0;
            decimal position = 0;
            decimal pastTime = 0;

            //displays coloumn titles
            Console.WriteLine("{0,-10} {1,-15} {2,-15} {3,-15}", "Time(s)", "Position(m)", "Velocity (m/s)", "Acceleration(m/s/s)");

            //loops until the current time reaches the specified time interval
            for (decimal currentTime = 0; currentTime <= timeInterval; currentTime += changeInTime)
            {
                //calculates velocity and position
                 
                position += (currentTime - pastTime) * (2*velocity + (currentTime - pastTime) * acceleration)/2;
                velocity += (currentTime - pastTime) * acceleration;
                //displays table entry with information about the objects motion
                Console.WriteLine("{0,-10} {1,-15} {2,-15} {3,-15}", currentTime, position, velocity, acceleration);

                //sets the past time to the current time for the next iteration
                pastTime = currentTime;
            }
            Console.ReadKey();
        }

        /*simulates an object moving with an acceleration being affected by earth's gravity and air resistance*/
        static void level3()
        {
            //constant varibles in simulation
            const decimal gravitationalAcceleration = (decimal)9.8;
            const decimal C = (decimal).3;
            const decimal mass = 5;
            const decimal changeInTime = (decimal).1;
            const int timeInterval = 100;

            //dynamic variables in simulation
            decimal airResistanceAcceleration;
            decimal netAcceleration;
            decimal velocity = 0;
            decimal position = 0;
            decimal pastTime = 0;

            //displays coloumn titles
            Console.WriteLine("{0,-10} {1,-25} {2,-25} {3,-25}", "Time(s)", "Position(m)", "Velocity (m/s)", "Acceleration(m/s/s)");
            

            //loops until the current time reaches the specified time interval
            for (decimal currentTime = 0; currentTime <= timeInterval; currentTime += changeInTime)
            {
                //calculate acceleration due to air resistance, net Acceleration, velocit, and position
                airResistanceAcceleration = (C*(decimal)Math.Pow((double)velocity, 2))/mass;
                netAcceleration = gravitationalAcceleration - airResistanceAcceleration;
                
                position += (currentTime - pastTime) * (2 * velocity + (currentTime - pastTime) * netAcceleration)/2;
                velocity += (currentTime - pastTime) * netAcceleration;
                //displays table entry about the objects motion
                Console.WriteLine("{0,-10} {1,-25} {2,-25} {3,-25}", currentTime, position, velocity, netAcceleration);

                //sets the past time to the current time for the next iteration
                pastTime = currentTime;
            }
            Console.ReadKey();
        }

        /*simulates an object connected to a spring moving with an acceleration being affected by an 
            unspecified force and air resistance*/
        static void challenge()
        {
            //constant varibles in simulation
            const decimal k = (decimal)2;
            const decimal gravitationalAcceleration = (decimal)9.8;
            const decimal C = (decimal).3;
            const decimal mass = 5;
            const decimal changeInTime = (decimal).1;
            const int timeInterval = 100;

            //dynamic variables in simulation
            decimal springAcceleration;
            decimal airResistanceAcceleration;
            decimal netAcceleration;
            decimal velocity = 0;
            decimal position = 0;
            decimal pastTime = 0;

            //displays coloumn titles
            Console.WriteLine("{0,-10} {1,-33} {2,-33} {3,-33}", "Time(s)", "Position(m)", "Velocity (m/s)", "Acceleration(m/s/s)");
            

            //loops until the current time reaches the specified time interval
            for (decimal currentTime = 0; currentTime <= timeInterval; currentTime += changeInTime)
            {
                /*calculates acceleration due to the spring, acceleration due to air resistance, 
                 * net acceleration, velocity, and position*/
                springAcceleration = (-k * position)/mass;
                if (velocity > 0)
                {
                    airResistanceAcceleration = (C * (decimal)Math.Pow((double)velocity, 2)) / mass;
                }
                else {
                    airResistanceAcceleration = -(C * (decimal)Math.Pow((double)velocity, 2)) / mass;
                }
                netAcceleration = gravitationalAcceleration - airResistanceAcceleration + springAcceleration;
                
                position += (currentTime - pastTime) * (2 * velocity + (currentTime - pastTime) * netAcceleration) / 2;
                velocity += (currentTime - pastTime) * netAcceleration;
                //displays table entry about the objects motion
                Console.WriteLine("{0,-10} {1,-33} {2,-33} {3,-33}", currentTime, position, velocity, netAcceleration);

                //sets the past time to the current time for the next iteration
                pastTime = currentTime;
            }
            Console.ReadKey();
        }
    }
}
