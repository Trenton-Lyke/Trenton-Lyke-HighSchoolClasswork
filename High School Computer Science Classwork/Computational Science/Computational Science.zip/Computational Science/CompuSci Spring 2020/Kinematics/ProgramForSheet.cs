﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace Kinematics
{
    class Program
    {
        static void Main(string[] args)
        {
            //calls the level_1 method with parameters necessary to level
            //level_1(.1, 0, 4, 100);

            //calls the level_2 method with parameters necessary to level
            //level_2(.1, 0, 4, 100);

            //calls the level_3 method with parameters necessary to level
            //level_3(.1, 0, 4, 100);

            //calls the level_4 method with parameters necessary to level
            //level_4(.1, 3, 4, 100);


            Vector coolVector = new Vector(1,1,1);
            Console.WriteLine(coolVector);
            //waits for key to be hit before closing the console 
            Console.ReadKey();
        }

        /// <summary>
        /// Simulates a particle traveling at a constant velocity
        /// </summary>
        /// <param name="dt">The change in time between each iteration in the simulation</param>
        /// <param name="initialPosition">The initial position of the particle</param>
        /// <param name="velocity">The velocity of the particle</param>
        /// <param name="totalTime">The total time of the simulation</param>
        static void level_1(double dt, double initialPosition, double velocity, double totalTime)
        {
            //the number of iterations necessary for the for loop to run for the elapsed time
            int iterations = (int)(totalTime / dt);
            //position of the particle
            double position = initialPosition;
            //elapsed time of the simulation
            double elapsedTime = 0;

            //displays headers for columns in the console
            Console.WriteLine("Time(s)!Position(m)!Velocity(m/s)");

            //updates position, and velocity as time progresses and displays updated values in the console
            for (int i = 0; i < iterations; i++)
            {
                position += velocity * dt;
                elapsedTime += dt;
                Console.WriteLine(elapsedTime + "!" + position + "!" + velocity);
            }
            
        }

        /// <summary>
        /// Simulates a particle in free fall 
        /// </summary>
        /// <param name="dt">The change in time between each iteration in the simulation</param>
        /// <param name="initialPosition">The initial position of the particle</param>
        /// <param name="initialVelocity">The initial velocity of the particle</param>
        /// <param name="totalTime">The total time of the simulation</param>
        static void level_2(double dt, double initialPosition, double initialVelocity, double totalTime)
        {
            //the number of iterations necessary for the for loop to run for the elapsed time
            int iterations = (int)(totalTime / dt);
            //position of the particle
            double position = initialPosition;
            //velocity of the particle
            double velocity = initialVelocity;
            //acceleration of the particle
            double acceleration = 9.8;
            //elapsed time of the simulation
            double elapsedTime = 0;

            //displays headers for columns in the console
            Console.WriteLine("Time(s)!Position(m)!Velocity(m/s)!Acceleration(m/s/s)");

            //updates position, velocity, and acceleration as time progresses and displays updated values in the console
            for (int i = 0; i < iterations; i++)
            {
                position += velocity * dt;
                velocity += acceleration * dt;
                elapsedTime += dt;
                Console.WriteLine(elapsedTime + "!" + position + "!" + velocity + "!" + acceleration);
            }
            
        }

        /// <summary>
        /// Simulates a mass falling with air resistance
        /// </summary>
        /// <param name="dt">The change in time between each iteration in the simulation</param>
        /// <param name="initialPosition">The initial position of the mass</param>
        /// <param name="initialVelocity">The initial velocity of the mass</param>
        /// <param name="totalTime">The total time of the simulation</param>
        static void level_3(double dt, double initialPosition, double initialVelocity, double totalTime)
        {
            //mass in kilograms
            const double mass = 5;
            //Air resistant coefficient in kg/m
            const double airResistancCoefficient = .4;
            //Gravitation field in m/s/s
            const double gravitationalField = 9.8;

            //the gravitational force acting on the mass
            double gravitationalForce = mass * gravitationalField;
            //position of the mass
            double position = initialPosition;
            //velocity of the mass
            double velocity = initialVelocity;
            //acceleration of the mass
            double acceleration = gravitationalField;
            //elapsed time of the simulation
            double elapsedTime = 0;
            //the number of iterations necessary for the for loop to run for the elapsed time
            int iterations = (int)(totalTime / dt);

            //displays headers for columns in the console
            Console.WriteLine("Time(s)!Position(m)!Velocity(m/s)!Acceleration(m/s/s)");

            //updates position, velocity, and accelerations as time progresses and displays updated values in the console
            for (int i = 0; i < iterations; i++)
            {
                position += velocity * dt;
                velocity += acceleration * dt;
                acceleration = (gravitationalForce - airResistancCoefficient * Math.Pow(velocity, 2)) / mass;
                elapsedTime += dt;
                Console.WriteLine(elapsedTime + "!" + position + "!" + velocity + "!" + acceleration);
            }
            
        }

        /// <summary>
        /// Simulates a mass attached to a spring, falling within a gravitational field, 
        /// and in the presence of air resistance. 
        /// </summary>
        /// <param name="dt">The change in time between each iteration in the simulation</param>
        /// <param name="initialPosition">The initial position of the mass</param>
        /// <param name="initialVelocity">The initial velocity of the mass</param>
        /// <param name="totalTime">The total time of the simulation</param>
        static void level_4(double dt, double initialPosition, double initialVelocity, double totalTime)
        {

            //mass of weight in kg
            const double mass = 5;
            //air resistant coefficient for weight in kg/m
            const double airResistanceCoefficient = .4;
            //gravitational field in m/s/s
            const double gravitationalField = 9.8;
            //k or spring coefficient in kg/s/s
            const double springCoefficient = 5;
            //the point that the spring is anchored at
            const double springAnchorPoint = 0;
            //the unstretched length of the spring
            const double springUnstretchedLength = 2;

            //the gravitational force acting on the mass
            double gravitationalForce = mass * gravitationalField;
            //position of the mass
            double position = initialPosition;
            //velocity of the mass
            double velocity = initialVelocity;
            //acceleration of the mass
            double acceleration = gravitationalField;
            //elapsed time of the simulation
            double elapsedTime = 0;
            //the number of iterations necessary for the for loop to run for the elapsed time
            int iterations = (int)(totalTime / dt);

            //displays headers for columns in the console
            Console.WriteLine("Time(s)!Position(m)!Velocity(m/s)!Acceleration(m/s/s)");

            //updates position, velocity, and accelerations as time progresses and displays updated values in the console
            for (int i = 0; i < iterations; i++)
            {
                position += velocity * dt;
                velocity += acceleration * dt;
               
                //ensures that the force of air resistances changes direction as velocity changes direction
                if (velocity > 0) {
                    acceleration = (gravitationalForce - airResistanceCoefficient * Math.Pow(velocity, 2) - springCoefficient * (position - (springAnchorPoint + springUnstretchedLength))) / mass;
                }
                else {
                    acceleration = (gravitationalForce + airResistanceCoefficient * Math.Pow(velocity, 2) - springCoefficient * (position - (springAnchorPoint + springUnstretchedLength))) / mass;
                }
                elapsedTime += dt;
                Console.WriteLine(elapsedTime + "!" + position + "!" + velocity + "!" + acceleration);
            }

            
        }
    }
}

