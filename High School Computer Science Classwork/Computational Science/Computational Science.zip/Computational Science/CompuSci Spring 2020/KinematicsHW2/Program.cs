﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace KinematicsHW2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            
            //Level_1();


            //Level_2();


            Level_3();






            //waits for key to be hit before closing the console 
            Console.ReadKey();
        }

        /// <summary>
        /// Simulates a 5kg ball being launched with an initial velocity in free fall
        /// </summary>
        static void Level_1()
        {
            
            
            //gravitational field in m/s/s
            const double gravitationalField = -9.8;
            
            //mass of ball 
            const double mass = 5;
            //path to the file that the data is written to
            const string filePath = @"C:\imsa\Projectile level 1.txt";
            //calls the MainLoopAboveGround method with parameters necessary for the level
            MainLoopAboveGround(.001, new Vector(0, 0, 0), new Vector(4 / Math.Sqrt(2), 0, 4 / Math.Sqrt(2)), gravitationalField, mass, 0, filePath);
        }

        /// <summary>
        /// Simulates a 5kg ball being launched with an initial velocity in the presence of air resistance
        /// </summary>
        static void Level_2()
        {


            //gravitational field in m/s/s
            const double gravitationalField = -9.8;
            //mass of ball 
            const double mass = 5;
            //drag coefficient in kg/m
            const double dragCoefficient = 0.4;
            //path to the file that the data is written to
            const string filePath = @"C:\imsa\Projectile level 2.txt";
            //calls the MainLoopAboveGround method with parameters necessary for the level
            MainLoopAboveGround(.001, new Vector(0, 0, 0), new Vector(4 / Math.Sqrt(2), 0, 4 / Math.Sqrt(2)), gravitationalField, mass, dragCoefficient, filePath);
        }

        /// <summary>
        /// Simulates the balls motion and displays data based of given parameters while has not touched the ground for a second time
        /// </summary>
        /// <param name="increment">The increment of time that pass with each iteration of the simulation</param>
        /// <param name="initialPosition">The initial position of the ball</param>
        /// <param name="initialVelocity">The initial velocity of the ball</param>
        /// <param name="gravitationalField">The gravitation field that the ball is in</param>
        /// <param name="mass">The mass of the ball</param>
        /// <param name="dragCoefficient">The drag coefficient of the ball</param>
        /// <param name="filePath">path to the file that the data is written to</param>
        private static void MainLoopAboveGround(double increment, Vector initialPosition, Vector initialVelocity, double gravitationalField, double mass, double dragCoefficient, string filePath)
        {
            //force of gravity in N
            double gravitationalForce = gravitationalField * mass;
            //acceleration of ball
            Vector acceleration = new Vector(0, 0, gravitationalField);
            //position of the ball
            Vector position = initialPosition;
            //velocity of ball
            Vector velocity = initialVelocity;

            //elapsed time of the simulation
            double elapsedTime = 0;


            //uses stream writer to write information into a text file
            using (StreamWriter sw = File.CreateText(filePath))
            {
                //dispays headers
                sw.WriteLine("Time!x!y!z!Distance!vx!vy!vz!Speed!ax!ay!az!m_Acc");

                //calculates and displays elapsed time, position, velocity, and acceleration of the ball while it is above the ground
                do
                {
                    sw.WriteLine(elapsedTime + "!" + position.X + "!" + position.Y + "!" + position.Z + "!" + position.Magnitude + "!" + velocity.X + "!" + velocity.Y + "!" + velocity.Z + "!" + velocity.Magnitude + "!" + acceleration.X + "!" + acceleration.Y + "!" + acceleration.Z + "!" + acceleration.Magnitude);
                    position += increment * velocity;
                    velocity += increment * acceleration;

                    acceleration = (Vector.ComponentMultiplication(Vector.ComponentSign(-velocity), (Vector.ComponentPow(velocity, 2) * dragCoefficient)) + (new Vector(0, 0, gravitationalForce))) / mass;

                    
                    elapsedTime += increment;
                }
                while (position.Z > 0);
            }
        }

        /// <summary>
        /// Simulates a 5kg ball being launched with an initial velocity in the presence of air resistance
        /// </summary>
        static void Level_3()
        {


            //gravitational field in m/s/s
            const double gravitationalField = -9.8;
            //mass of ball 
            const double mass = 5;



            //drag coefficient in kg/m
            const double dragCoefficient = 0.4;
            //spring constant in kg/s/s
            const double springConstant = 5;
            //length of the unstreched spring in m
            const double unstretchedSpringLength = 2;
            //path to the file that the data is written to
            const string filePath = @"C:\imsa\Projectile level 3.txt";
            //calls the MainLoopUntilIdle method with parameters necessary for the level
            MainLoopUntilIdle(.001, new Vector(1, 1, 1), new Vector(-2, 1, 3), gravitationalField, mass, filePath, dragCoefficient, springConstant, unstretchedSpringLength);
        }
        /// <summary>
        /// Simulates the balls motion and displays data based of given parameters while the speed has not settled below 1m/s
        /// </summary>
        /// <param name="increment">The increment of time that pass with each iteration of the simulation</param>
        /// <param name="initialPosition">The initial position of the ball</param>
        /// <param name="initialVelocity">The initial velocity of the ball</param>
        /// <param name="gravitationalField">The gravitation field that the ball is in</param>
        /// <param name="mass">The mass of the ball</param>
        /// <param name="dragCoefficient">The drag coefficient of the ball</param>
        /// <param name="filePath">path to the file that the data is written to</param>
        /// <param name="springConstant">spring constant of the sping the ball is attatched too</param>
        /// <param name="unstretchedSpringLength">unstretched length of the spring</param>
        private static void MainLoopUntilIdle(double increment, Vector initialPosition, Vector initialVelocity, double gravitationalField, double mass, string filePath = @"C:\imsa\output.txt", double dragCoefficient = 0, double springConstant = 0, double unstretchedSpringLength = 0)
        {
            //elapsed time of the simulation
            double elapsedTime = 0;
            //boolean thats is true while the speed does not peak under 1m/s
            bool isNotIdle = true;
            //force of gravity in N
            double gravitationalForce = gravitationalField * mass;
            //position of the ball
            Vector position = initialPosition;
            //velocity of ball
            Vector velocity = initialVelocity;
            //acceleration of ball
            Vector acceleration = new Vector(0, 0, gravitationalField);

            //uses stream writer to write information into a text file
            using (StreamWriter sw = File.CreateText(filePath))
            {
                //dispays headers
                sw.WriteLine("Time!x!y!z!Distance!vx!vy!vz!Speed!ax!ay!az!m_Acc");

                //speed of the ball in the iteration before the previous iteration
                double? previousPastSpeed = null;
                //speed of the ball in the previous iteration
                double? pastSpeed = null;
                //the last elapsed time when the speed was 1m/s
                double? last1time = null;

                //calculates and displays elapsed time, position, velocity, and acceleration of the ball while it is above the ground
                do
                {
                    sw.WriteLine(elapsedTime + "!" + position.X + "!" + position.Y + "!" + position.Z + "!" + position.Magnitude + "!" + velocity.X + "!" + velocity.Y + "!" + velocity.Z + "!" + velocity.Magnitude + "!" + acceleration.X + "!" + acceleration.Y + "!" + acceleration.Z + "!" + acceleration.Magnitude);

                    position += increment * velocity;
                    velocity += increment * acceleration;
                    Vector unstretchedComponentLengths = unstretchedSpringLength * position.UnitVector;
                    Console.WriteLine(velocity.Magnitude);
                    acceleration = (Vector.ComponentMultiplication(Vector.ComponentSign(-velocity) , (Vector.ComponentPow(velocity, 2) * dragCoefficient)) - springConstant * (position - unstretchedComponentLengths)+(new Vector(0,0, gravitationalForce)))/mass;
                    
                    //updates last elapsed time the speed was above 1 
                    if (velocity.Magnitude >= 1)
                    {
                        last1time = elapsedTime;
                    }

                    //determines if the ball has settled under a speed of 1m/s
                    if (pastSpeed != null && previousPastSpeed != null)
                    {
                        if (pastSpeed > previousPastSpeed && pastSpeed > velocity.Magnitude && pastSpeed < 1)
                        {
                            isNotIdle = false;
                            sw.WriteLine("last time speed was 1m/s: " + last1time);
                        }

                    }
                    
                    //updates previous past speed and past speed
                    if (pastSpeed != null)
                    {
                        previousPastSpeed = pastSpeed;
                    }
                    pastSpeed = velocity.Magnitude;

                    elapsedTime += increment;
                }
                while (isNotIdle);
            }
        }
    }
       
}

