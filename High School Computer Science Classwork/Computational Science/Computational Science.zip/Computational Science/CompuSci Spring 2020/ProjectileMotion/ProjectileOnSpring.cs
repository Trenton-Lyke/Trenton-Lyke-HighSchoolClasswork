﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    /// <summary>
    /// A class of projectiles that a attached to springs
    /// </summary>
    public class ProjectileOnSpring
    {
        public ProjectileOnSpring(Projectile aProjectile, Spring aSpring) {
            AProjectile = aProjectile;
            ASpring = aSpring;
            ProjectilePosition = AProjectile.Position;
            ProjectileVelocity = AProjectile.Velocity;
            ProjectileAcceleration = AProjectile.Acceleration;
        }

        public ProjectileOnSpring(double mass, double dragCoefficient, Vector position, Vector velocity, Vector acceleration, Vector anchorPoint, double springConstant, double unstretchedSpringLength) {
            AProjectile = new Projectile(mass, dragCoefficient, position, velocity, acceleration);
            ASpring = new Spring(anchorPoint, springConstant, unstretchedSpringLength);
            ProjectilePosition = position;
            ProjectileVelocity = velocity;
            ProjectileAcceleration = acceleration;
        }

        /// <summary>
        /// The projectile that is attached to the spring
        /// </summary>
        public Projectile AProjectile { get; private set; }
        /// <summary>
        /// Position of the projectile that is attached to the spring
        /// </summary>
        public Vector ProjectilePosition { get; private set; }
        /// <summary>
        /// Velocity of the projectile that is attached to the spring
        /// </summary>
        public Vector ProjectileVelocity { get; private set; }
        /// <summary>
        /// Acceleration of the projectile that is attached to the spring
        /// </summary>
        public Vector ProjectileAcceleration { get; private set; }
        /// <summary>
        /// spring that the projectile is attached to
        /// </summary>
        public Spring ASpring { get; set; }


        /// <summary>
        /// updates the position, velocity, and acceleration of the projectile attached to the spring
        /// </summary>
        public void UpdateProjectile(double increment, double gravitationalField=0) {
            AProjectile.UpdateProjectile(increment, gravitationalField, ASpring.AnchorPoint, ASpring.SpringConstant, ASpring.UnstretchedSpringLength);
            ProjectilePosition = AProjectile.Position;
            ProjectileVelocity = AProjectile.Velocity;
            ProjectileAcceleration = AProjectile.Acceleration;
        }

        /// <summary>
        /// updates the position, velocity, and acceleration of the projectile attached to the spring with an additional force
        /// </summary>
        public void UpdateProjectile(double increment, Vector additionalForce, double gravitationalField=0)
        {
            AProjectile.UpdateProjectile(increment, gravitationalField, ASpring.AnchorPoint, ASpring.SpringConstant, ASpring.UnstretchedSpringLength);
            ProjectilePosition = AProjectile.Position;
            ProjectileVelocity = AProjectile.Velocity;
            ProjectileAcceleration = AProjectile.Acceleration;
        }


    }
}
