﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    /// <summary>
    /// A classs to simulate the world
    /// </summary>
    public class World
    {

        public World( double gravitationalField, Dictionary<ProjectileOnSpring, List<int>> projectilesOnMultipleSprings, double elapsedTime) {
            
            GravitationalField = gravitationalField;
            ProjectilesOnMultipleSprings = projectilesOnMultipleSprings;
            Projectiles = projectilesOnMultipleSprings.Keys.ToList();
            Time = 0;
            ElapsedTime = elapsedTime;
        }


        public List<ProjectileOnSpring> Projectiles { get; set; }

        public Dictionary<ProjectileOnSpring, List<int>> ProjectilesOnMultipleSprings { get; set; }

        /// <summary>
        /// Gravitation field in N/kg
        /// </summary>
        public double GravitationalField { get; set; }
        public double Time { get; set; }

        public double ElapsedTime { get; set; }
        
        
        



        /// <summary>
        /// Increments time in the world and updates all projectiles on springs
        /// </summary>
        public void Tick(double increment){

            UpdateProjectiles(.01,-9.8);
            Time += increment;
            

        }

        /// <summary>
        /// Updates all the projectilse in the world
        /// </summary>
        public void UpdateProjectiles(double increment, double gravitationalField = 0)
        {
            
            foreach (ProjectileOnSpring projectile in Projectiles)
            {
                Vector additionalForce = new Vector(0, 0, 0);
                foreach (int i in ProjectilesOnMultipleSprings[projectile])
                {
                    Projectiles[i].ASpring.AnchorPoint = projectile.AProjectile.Position;
                    Vector unstretchedComponentLengths = Projectiles[i].ASpring.UnstretchedSpringLength * (Projectiles[i].ASpring.AnchorPoint - Projectiles[i].AProjectile.Position).UnitVector;
                    additionalForce += -Projectiles[i].ASpring.SpringConstant * (Projectiles[i].ProjectilePosition - Projectiles[i].ASpring.AnchorPoint - unstretchedComponentLengths);
                    Projectiles[i].UpdateProjectile(increment, new Vector(0, 0, 0), gravitationalField);
                }
                projectile.UpdateProjectile(increment, additionalForce, gravitationalField);
            }
        }
    }
}
