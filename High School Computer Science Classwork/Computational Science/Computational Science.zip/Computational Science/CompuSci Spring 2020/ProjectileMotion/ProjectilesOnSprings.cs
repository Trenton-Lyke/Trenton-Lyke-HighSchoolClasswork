﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    /// <summary>
    /// A class of projectiles that a attached to springs
    /// </summary>
    public class ProjectilesOnSprings
    {
        public ProjectilesOnSprings(Dictionary<ProjectileOnSpring,List<ProjectileOnSpring>> projectilesOnSprings) {
            Dictionary<ProjectileOnSpring, List<ProjectileOnSpring>> ProjectilesOnSprings = projectilesOnSprings;
        }

        

       
        public Dictionary<ProjectileOnSpring, List<ProjectileOnSpring>> ProjectilesOnSprings { get; private set; }
        


        /// <summary>
        /// updates the position, velocity, and acceleration of the projectile attached to the spring
        /// </summary>
        public void UpdateProjectile(double increment, double gravitationalField = 0) {
            List<ProjectileOnSpring> projectilesOnMultipleSprings = ProjectilesOnSprings.Keys;
            foreach (ProjectileOnSpring projectileOnMultipleSpring in projectilesMultipleOnSprings) {
                Vector additionalForce = 0;
                foreach (ProjectileOnSpring projectileOnSpring in ProjectilesOnSprings[projectileOnMultipleSpring]) {
                    projectileOnSpring.ASpring.AnchorPoint = projectileOnMultipleSpring.AProjectile.Position;
                    Vector unstretchedComponentLengths = projectileOnSpring.ASpring.unstretchedSpringLength * (projectileOnSpring.ASpring.AnchorPoint - projectileOnSpring.AProjectile.Position).UnitVector;
                    additionalForce += -projectileOnSpring.ASpring.springConstant * (projectileOnSpring.Position - projectileOnSpring.ASpring.springAnchorPoint - unstretchedComponentLengths);
                    projectileOnSpring.UpdateProjectile(increment, new Vector(0,0,0), gravitationalField);
                }
                projectileOnMultipleSpring.UpdateProjectile(increment, additionalForce, gravitationalField);
            }
        }

    }
}
