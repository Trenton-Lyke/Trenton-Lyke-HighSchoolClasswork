﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    /// <summary>
    /// A class for representing springs
    /// </summary>
    public class Spring
    {
        public Spring(Vector anchorPoint, double springConstant = 0, double unstretchedSpringLength = 0)
        {
            SpringConstant = springConstant;
            UnstretchedSpringLength = unstretchedSpringLength;
            AnchorPoint = anchorPoint;
        }

        /// <summary>
        /// spring constant in kg/s/s
        /// </summary>
        public double SpringConstant { get; private set; }
        /// <summary>
        /// Length at which spring does not exert any force in m
        /// </summary>
        public double UnstretchedSpringLength { get; private set; }
        /// <summary>
        /// The point in space where one end of the spring is fixed
        /// </summary>
        public Vector AnchorPoint { get; set; }

    }
}
