﻿using System;

namespace Utility
{
    /// <summary>
    /// A basic three-dimensional vector class
    /// </summary>
    public struct Vector
    {

        public Vector(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }
        
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        

        /// <summary>
        /// The square of the magnitude much faster than the magnitude
        /// </summary>
        public double Mag2 => X * X + Y * Y + Z * Z;
        
        public double Magnitude => Math.Sqrt(Mag2);

        public Vector UnitVector => new Vector(X / Magnitude, Y / Magnitude, Z / Magnitude);

        /// <summary>
        /// Dot product of two vectors
        /// </summary>
        static public double DotProduct(Vector vec1, Vector vec2)
        {
            return vec1.X * vec2.X + vec1.Y * vec2.Y + vec1.Z * vec2.Z;
        }

        /// <summary>
        /// Angle between two vectors in radians
        /// </summary>
        static public double GetAngleBetween(Vector vec1, Vector vec2)
        {
            return Math.Acos(Vector.DotProduct(vec1,vec2)/(vec1.Magnitude*vec2.Magnitude));
        }

        /// <summary>
        /// Cross product of two vectors
        /// </summary>
        static public Vector CrossProduct(Vector vec1, Vector vec2)
        {
            return new Vector(vec1.Y * vec2.Z - vec1.Z * vec2.Y, vec1.Z * vec2.X - vec1.X * vec2.Z, vec1.X * vec2.Y - vec1.Y * vec2.X);
        }

        static public Vector operator +(Vector vec1, Vector vec2)
        {
            return new Vector(
            vec1.X + vec2.X,
            vec1.Y + vec2.Y,
            vec1.Z + vec2.Z
            );
        }

        
        static public Vector operator -(Vector vec1, Vector vec2)
        {
            return vec1 + -vec2;
        }

        /// <summary>
        /// makes vector have opposite sign components
        /// </summary>
        static public Vector operator -(Vector vec)
        {
            return -1 * vec;
        }
        
        static public Vector operator *(Vector vec, double scalar)
        {
            return new Vector(vec.X * scalar, vec.Y * scalar, vec.Z * scalar);
        }

        static public Vector operator *(double scalar, Vector vec)
        {
            return vec * scalar;
        }
        
        static public Vector operator /(Vector vec, double scalar)
        {
            return vec * (1 / scalar);
        }
        
        /// <summary>
        /// returns boolean for if vectors are equal
        /// </summary>
        static public bool operator ==(Vector vec1, Vector vec2)
        {
            if (vec1.X == vec2.X && vec1.Y == vec2.Y && vec1.Z == vec2.Z)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// returns boolean for if the vectors are not equal
        /// </summary>
        static public bool operator !=(Vector vec1, Vector vec2)
        {
            return !(vec1 == vec2);
        }

        /// <summary>
        /// Raises Each component of a vector to a specified power
        /// </summary>
        /// <returns>a vector with each component raised to the specified power</returns>
        static public Vector ComponentPow(Vector vec, double power) {
            return new Vector(Math.Pow(vec.X,power), Math.Pow(vec.Y, power), Math.Pow(vec.Z, power));
        }

        /// <summary>
        /// Multiplies the components of two vectors
        /// </summary>
        /// <returns>a vector resulting of the component-wise multiplication</returns>
        static public Vector ComponentMultiplication(Vector vec1, Vector vec2) {
            return new Vector(vec1.X * vec2.X, vec1.Y * vec2.Y, vec1.Z * vec2.Z);
        }

        /// <summary>
        /// Divides the components of the vector
        /// </summary>
        /// <returns>a vector resulting of the component-wise division</returns>
        static public Vector ComponentDivision(Vector vec1, Vector vec2)
        {
            return ComponentMultiplication(vec1, ComponentPow(vec2, -1));
        }

        /// <summary>
        /// gets the sign of each component of a vector
        /// </summary>
        /// <returns>vector of signs of each component</returns>
        static public Vector ComponentSign(Vector vec)
        {
            return new Vector(Math.Sign(vec.X), Math.Sign(vec.Y), Math.Sign(vec.Z));
        }

        /// <summary>
        /// creates a string from a vector
        /// </summary>
        public override string ToString()
        {
            return "" + X + ", " + Y + ", " + Z;
        }
    }
}

