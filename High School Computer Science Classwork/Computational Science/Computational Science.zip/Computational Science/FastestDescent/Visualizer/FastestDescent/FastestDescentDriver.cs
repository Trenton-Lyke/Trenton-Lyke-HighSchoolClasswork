﻿using DongUtility;
using MotionVisualizerControl;
using PhysicsUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using static WPFUtility.UtilityFunctions;

namespace Visualizer.FastestDescent
{
    class FastestDescentDriver
    {
        static internal void RunFastestDescent()
        {
            Level1();
            //Level2();
            //Level3();
            //Level4();
        }

        /// <summary>
        /// Gets optimal parameters for level 1 contraints and runs visualizer
        /// </summary>
        private static void Level1()
        {
            const double delta_parameter = .15;
            const double learning_rate = .005;
            const double training_period = 400;
           
            double[] bestParameters = new double[] { 0, 0, 0 };
            double bestTime = Double.MaxValue;

            double lower_bound = -50;
            double upper_bound = 50;
            double step = .5;
            bestParameters = BruteForceGradientDecent(delta_parameter, learning_rate, training_period,  ref bestParameters, ref bestTime, lower_bound, upper_bound, step, 1);
            VisualizeFastestDescent(1, bestParameters);
        }

        /// <summary>
        /// Gets optimal parameters for level 2 contraints and runs visualizer
        /// </summary>
        private static void Level2()
        {
            const double delta_parameter = .15;
            const double learning_rate = .05;
            const double training_period = 400;
           
            double[] bestParameters = new double[] { 0, 0, 0, 0 };
            double bestTime = Double.MaxValue;

            double lower_bound = -5;
            double upper_bound = 1;
            double step = 1;
            bestParameters = BruteForceGradientDecent(delta_parameter, learning_rate, training_period,  ref bestParameters, ref bestTime, lower_bound, upper_bound, step, 2);
            VisualizeFastestDescent(2, bestParameters);
        }

        /// <summary>
        /// Gets optimal parameters for level 3 contraints and runs visualizer
        /// </summary>
        private static void Level3()
        {
            double[] delta_parameters = { .035, .035 };
            double[] learning_rates = { .01, .01 };
            const double training_period = 1;

            double[][] bestParameters = new double[2][];
            double bestTime = Double.MaxValue;
            //-0.19999999999999929,-4.3700000000000134
            double[] lower_bounds = { -0.20753428571429991, -4.3775342857143418 };
            double[] upper_bounds = { -0.20753428571429991, -4.3775342857143418 };
            double[] steps = { .01, .01};
            bestParameters = BruteForceGradientDecentMultiDimension(3, delta_parameters, learning_rates, training_period, ref bestParameters, ref bestTime, lower_bounds, upper_bounds, steps, new int[]{3, 2});
           VisualizeFastestDescentMultiDimensions(3, bestParameters);
        }

        /// <summary>
        /// Gets optimal parameters for level 4 contraints and runs visualizer
        /// </summary>
        private static void Level4()
        {
            double[] delta_parameters = { .15, .15 };
            double[] learning_rates = { .1, .1 };
            const double training_period = 500;

            double[][] bestParameters = new double[2][];
            double bestTime = Double.MaxValue;

            double[] lower_bounds = { 0.64666666666666273, 12.146666666666647 };
            double[] upper_bounds = { 0.64666666666666273, 12.146666666666647 };
            double[] steps = { .1, .1 };
            bestParameters = BruteForceGradientDecentMultiDimension(4, delta_parameters, learning_rates, training_period, ref bestParameters, ref bestTime, lower_bounds, upper_bounds, steps, new int[] { 4, 5 });
            VisualizeFastestDescentMultiDimensions(4, bestParameters);
        }

        //optimizes single set of coefficients using brute force and gradient descent on each individual parameters and each iteration of the brute force
        private static double[] BruteForceGradientDecent(double delta_parameter, double learning_rate, double training_period,  ref double[] bestParameters, ref double bestTime, double lower_bound, double upper_bound, double step, int level)
        {
            for (double b = lower_bound; b <= upper_bound; b += step)
            {
                b = TrainGradientDescent(delta_parameter, learning_rate, training_period, level, b);

                double[] parameters = generateParameters(level, b);
                double time = RunOnce(level, parameters);
                if (time < bestTime)
                {
                    bestTime = time;
                    bestParameters = parameters;
                }
                
            }
            return bestParameters;
        }

        //optimizes the b coefficient which all the other coefficients are dependent on with gradient descent of a certain training period
        private static double TrainGradientDescent(double delta_parameter, double learning_rate, double training_period, int level, double b)
        {
            for (int i = 0; i < training_period; i++)
            {
                double old_b = b;
                b = GradientDescent(delta_parameter, learning_rate, level, b);
                //breaks if the gradient descent is ineffective to save time
                if (b == old_b) {
                    break;
                }
            }

            return b;
        }

        //optimizes the b coefficient with a single iteration of gradient descent
        private static double GradientDescent(double delta_parameter, double learning_rate, int level, double b)
        {
            double adjustedB = b + delta_parameter;
            double time1 = RunOnce(level, generateParameters(level, b));
            double time2 = RunOnce(level, generateParameters(level, adjustedB));
            double gradient = (time2 - time1) / delta_parameter;
            b -= learning_rate * gradient;
            return b;
        }

        //optimizes multiple sets of coeeficients using brute force and gradient descent on each individual parameters and each iteration of the brute force 
        private static double[][] BruteForceGradientDecentMultiDimension(int path_level, double[] delta_parameters, double[] learning_rates, double training_period, ref double[][] bestParameters, ref double bestTime, double[] lower_bounds, double[] upper_bounds, double[] steps, int[] levels)
        {
            double[] bParameters = new double[lower_bounds.Length];

            Array.Copy(lower_bounds, bParameters, lower_bounds.Length);
            for (double b0 = lower_bounds[0]; b0 <= upper_bounds[0]; b0 += steps[0])
            {
                if (b0 == 0) {
                    b0 = 0;
                }
                for (double b1 = lower_bounds[1]; b1 <= upper_bounds[1]; b1 += steps[1])
                {
                    bParameters[0] = b0;
                    bParameters[1] = b1;
                    double[][] parameters = TrainGradientDescentMultiDimension(path_level, delta_parameters, learning_rates, training_period, bestParameters, levels, bParameters);

                    
                    double time = RunOnceMultiDimensions(path_level, parameters);
                    if (time < bestTime)
                    {
                        bestTime = time;
                        bestParameters = parameters;
                    }
                    
                }
            }
            return bestParameters;
        }

        //optimizes the b coefficients which all the other coefficients are dependent on with gradient descent of a certain training period

        private static double[][] TrainGradientDescentMultiDimension(int path_level, double[] delta_parameters, double[] learning_rates, double training_period, double[][] bestParameters, int[] levels, double[] bParameters)
        {
            double[][] parameters = new double[bestParameters.Length][];
            for (int i = 0; i < training_period; i++)
            {
                for (int z = 0; z < bParameters.Length; z++)
                {
                    parameters[z] = generateParameters(levels[z], bParameters[z]);
                }
                double[] old_bParameters = new double[bParameters.Length];
                Array.Copy(bParameters, old_bParameters, bParameters.Length);
                bParameters = GradientDescentMultiDimension(path_level, delta_parameters, learning_rates, levels, bParameters, parameters);
                if (Enumerable.SequenceEqual(bParameters, old_bParameters)) {
                    break;
                }
                for (int z = 0; z < bParameters.Length; z++)
                {
                    parameters[z] = generateParameters(levels[z], bParameters[z]);
                }
            }

            return parameters;
        }

        //optimizes the b coefficients with a single iteration of gradient descent
        private static double[] GradientDescentMultiDimension(int path_level, double[] delta_parameters, double[] learning_rates, int[] levels, double[] bParameters, double[][] parameters)
        {
            double[] adjustedBs = new double[bParameters.Length];
            for (int a = 0; a < bParameters.Length; a++)
            {
                adjustedBs[a] = bParameters[a] + delta_parameters[a];
            }



            
            double[][] adjustedParameters = new double[parameters.Length][];
            for (int z = 0; z < bParameters.Length; z++)
            {
                adjustedParameters[z] = generateParameters(levels[z], adjustedBs[z]);
            }
            // You will want to do your optimization here,
            // calling RunOnce() many times
            for (int a = 0; a < bParameters.Length; a++)
            {

                double time1 = RunOnceMultiDimensions(path_level, parameters);

                double time2 = RunOnceMultiDimensions(path_level, adjustedParameters);
                double partial = (time2 - time1) / delta_parameters[a];
                bParameters[a] -= learning_rates[a] * partial;
            }
            return bParameters;
        }

        //generates all the coeficents for equations based on the b coefficient
        public static double[] generateParameters(int level, double b) {
            switch (level) {
                case 1:
                    return new double[] { 0, b, (1 + b) / 10 };   
                case 2:
                    return new double[] { 0, b, (48 * b + 73) / 180, (6 * b + 11) / 360 };
                case 3:
                    return new double[] { 0, b, (24*b + 1 )/ 90, (3*b + 2) / 180  };
                case 4:
                    return new double[] { 0, b,  (13496*b - 77411) / 20160 , (18088*b - 178877) / 120960 , (280*b - 3799) / 20160,  (56*b - 943) /120960  };
                case 5:
                    return new double[] { 0, b, (121464*b - 502391) / 181440, (162792*b - 1021801) / 1088640, (2520*b - 21883) / 181440, (504*b - 6035 )/ 1088640  };
                default:
                    return new double[] { 0, b, (48 * b + 73) / 180, (6 * b + 11) / 360 };
            }
        }

        //runs ball on path once and returns the descent time
        static private double RunOnce(int level, params double[] parameters)
        {
            var engine = SetupEngine(level, parameters);
            const double timeStep = .001;
            
            while (engine.Tick(engine.Time + timeStep) && engine.Time <2.4)
            { }
            return engine.Time;
        }

        //runs path once and returns the descent working in a 3 dimentsional space
        static private double RunOnceMultiDimensions(int level, params double[][] parameters)
        {
            var engine = SetupEngineMultiDimensions(level, parameters);
            const double timeStep = .01;
            
            while (engine.Tick(engine.Time + timeStep) && engine.Time < 4.7)
            { }
            
            return engine.Time;
        }

        //sets up an engine with a 2D path based on the level
        static private Engine SetupEngine(int level, params double[] parameters)
        {

            // Initial position is set by the path, so it doesn't need to be set now
            var projectile = new Projectile(Vector.NullVector(), Vector.NullVector(), 1); // The mass does not matter
            Path path;
            switch (level) {
                case 1:
                    path = new Simple2DQuadratic(parameters);
                    break;
                case 2:
                    path = new Simple2DCubic(parameters);
                    break;
                default:
                    path = new Simple2DQuadratic(parameters);
                    break;
            }
            return new Engine(projectile, path);
        }

        //sets up an engine with a 3D path based on the level
        static private Engine SetupEngineMultiDimensions(int level, params double[][] parameters)
        {

            // Initial position is set by the path, so it doesn't need to be set now
            var projectile = new Projectile(Vector.NullVector(), Vector.NullVector(), 1); // The mass does not matter
            Path path;
            switch (level)
            {
                case 3:
                    path = new Simple3DCubic(parameters);
                    break;
                case 4:
                    path = new Simple3DQuintic(parameters);
                    break;
                default:
                    path = new Simple3DCubic(parameters);
                    break;
            }
            
            return new Engine(projectile, path);
        }

        static internal void VisualizeFastestDescent(int level, params double[] parameters)
        {
            var engine = SetupEngine(level, parameters);
            ConfigureVisualization(engine);
        }
        static internal void VisualizeFastestDescentMultiDimensions(int level, params double[][] parameters)
        {
            var engine = SetupEngineMultiDimensions(level, parameters);
            ConfigureVisualization(engine);
        }

        private static void ConfigureVisualization(Engine engine)
        {
            var visualization = new DescentVisualization(engine)
            {
                PathThickness = .5,
                PathColor = Colors.IndianRed,
                ProjectileSize = 1,
                ProjectileColor = Colors.NavajoWhite
            };

            var fullViz = new MotionVisualizer(visualization);
            //fullViz.BackgroundFile = "stars.jpg";

            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertVector(engine.Projectile.Position), "Time (s)", "Position (m)");
            fullViz.AddText("Time", Colors.MidnightBlue, () => (Math.Round(engine.Time, 3)).ToString() + " s");

            fullViz.SlowDraw = true;
            fullViz.TimeIncrement = .01;

            fullViz.Show();
        }
    }
}
