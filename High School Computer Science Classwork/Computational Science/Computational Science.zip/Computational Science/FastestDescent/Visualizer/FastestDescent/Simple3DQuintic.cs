﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Text;
using static DongUtility.UtilityFunctions;

namespace Visualizer.FastestDescent
{
    class Simple3DQuintic : Path
    {
        private double[][] parameters;

        public Simple3DQuintic(params double[][] parameters)
        {
            this.parameters = parameters;
        }
        public override double InitialParameter => -10;

        public override double FinalParameter => 0;

        //a function where the y nad y a quintically related to t in a 3d space
        protected override Vector Function(double parameter)
        {
            double y = parameters[0][0] + parameters[0][1] * parameter + parameters[0][2] * Square(parameter) + parameters[0][3] * Cube(parameter) + parameters[0][4] * fourthPower(parameter) + parameters[0][5] * fifthPower(parameter);
            double z = parameters[1][0] + parameters[1][1] * parameter + parameters[1][2] * Square(parameter) + parameters[1][3] * Cube(parameter) + parameters[1][4] * fourthPower(parameter) + parameters[1][5] * fifthPower(parameter);
            return new Vector(parameter, y, z);
        }
        //cubes input
        public double Cube(double param)
        {
            return param * param * param;
        }
        //raises input to the fourth power
        public double fourthPower(double param)
        {
            return param * param * param*param;
        }
        //raises the input to the fifth power
        public double fifthPower(double param)
        {
            return param * param * param * param*param;
        }
    }
}
