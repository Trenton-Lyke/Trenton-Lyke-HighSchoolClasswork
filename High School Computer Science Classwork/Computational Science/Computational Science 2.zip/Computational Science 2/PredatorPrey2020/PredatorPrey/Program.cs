﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredatorPrey
{
    class Program
    {
        //static void Main(string[] options)
        //{
        //    const double width = 50;
        //    const double height = 50;
        //    const double timeStep = .01;

        //    var arena = new Arena(width, height);
        //    var hare = new Hare(arena);
        //    var lynx = new Lynx(arena);

        //    hare.Other = lynx;
        //    lynx.Other = hare;

        //    arena.AddAnimal(hare);
        //    arena.AddAnimal(lynx);

        //    // Here is where you do stuff to the Perceptron
        //    hare.Perceptron.RandomWeights(5);

        //    // Here is how you copy a Perceptron
        //    var clone = hare.Perceptron.Clone();

        //    // Here is hwo you make a copy with random variation in weights
        //    var randomClone = hare.Perceptron.RandomClone(4);

        //    bool keepRunning = true;
            
        //    while (keepRunning)
        //    {
        //        keepRunning = arena.Update(arena.Time + timeStep);
        //    }

        //    Console.WriteLine("Total time to death: " + arena.Time);
        //    Console.ReadKey();
   //     }
    }
}
