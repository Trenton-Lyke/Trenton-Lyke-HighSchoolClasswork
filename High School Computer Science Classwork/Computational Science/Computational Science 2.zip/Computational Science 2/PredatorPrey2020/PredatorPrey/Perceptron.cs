﻿using DongUtility;
using System;
using System.Collections.Generic;

namespace PredatorPrey
{
    public class Perceptron
    {
        static public Random Random { get; } = new Random();

        public class Connector
        {
            public double Weight { get; set; }
            public Node Node { get; set; }
        }

        public class Node
        {
            public List<Connector> Connectors { get; set; } = new List<Connector>();

            private double total = 0;

            public void Reset()
            {
                total = 0;
            }

            public void AddData(double value, double weight = 1)
            {
                
                double test = ((new Random()).NextBool() ? -1 : 1) * Math.Sin(value) * weight;
                
                

                total += test;

            }

            public void FeedForward()
            {
                HashSet<Node> nodes = new HashSet<Node>();
                foreach (Connector connector in Connectors) {
                    connector.Node.AddData(total, connector.Weight);
                    nodes.Add(connector.Node);
                }
                foreach (Node node in nodes) {
                    node.FeedForward();
                }
                
            }

            public double GetValue()
            {
                return total;
            }
        }

        public List<Node> InputNodes { get; } = new List<Node>();

        public List<Node>[] hiddenLayers { get; }

        public int[] nHiddenLayerNodes { get; }
        public List<Node> OutputNodes { get; } = new List<Node>();

        public void AddInput(int index, double value)
        {
            InputNodes[index].AddData(value);
        }

        public void Run()
        {
            InputNodes.ForEach((x) => x.FeedForward());

        }

        public Perceptron Clone()
        {
            var clone = new Perceptron(InputNodes.Count, nHiddenLayerNodes, OutputNodes.Count);

            if (nHiddenLayerNodes.Length >= 1)
            {
                for (int inode = 0; inode < InputNodes.Count; ++inode)
                {
                    for (int iconnect = 0; iconnect < InputNodes[inode].Connectors.Count; ++iconnect)
                    {
                        clone.InputNodes[inode].Connectors[iconnect].Weight =
                            InputNodes[inode].Connectors[iconnect].Weight;
                    }
                }
                for (int i = 0; i < hiddenLayers.Length; i++)
                {
                    for (int inode = 0; inode < nHiddenLayerNodes[i]; inode++)
                    {

                        for (int iconnect = 0; iconnect < hiddenLayers[i][inode].Connectors.Count; ++iconnect)
                        {
                            clone.hiddenLayers[i][inode].Connectors[iconnect].Weight =
                                hiddenLayers[i][inode].Connectors[iconnect].Weight;
                        }

                    }
                }
            }
            else {
                for (int inode = 0; inode < InputNodes.Count; ++inode)
                {
                    for (int iconnect = 0; iconnect < InputNodes[inode].Connectors.Count; ++iconnect)
                    {
                        clone.InputNodes[inode].Connectors[iconnect].Weight =
                            InputNodes[inode].Connectors[iconnect].Weight;
                    }
                }
            }

            return clone;
        }

        public Perceptron RandomClone(double standardDeviation)
        {
            var clone = Clone();

            clone.RandomWeights(standardDeviation);

            return clone;
        }

        public double GetOutput(int index)
        {
            return OutputNodes[index].GetValue();
        }

        public Perceptron(int nInputs, int[] nHiddenLayerNodes,int nOutputs)
        {
            this.nHiddenLayerNodes = nHiddenLayerNodes;
            if (nHiddenLayerNodes.Length >= 1)
            {
                
                hiddenLayers = new List<Node>[nHiddenLayerNodes.Length];
                for (int i = 0; i < hiddenLayers.Length; i++)
                {
                    hiddenLayers[i] = new List<Node>();
                }
                for (int i = 0; i < nOutputs; ++i)
                {
                    OutputNodes.Add(new Node());
                }

                for (int i = 0; i < nHiddenLayerNodes[nHiddenLayerNodes.Length - 1]; ++i)
                {
                    var node = new Node();
                    foreach (var output in OutputNodes)
                    {
                        node.Connectors.Add(new Connector() { Weight = 1, Node = output });
                    }
                    hiddenLayers[nHiddenLayerNodes.Length - 1].Add(node);
                }

                for (int i = hiddenLayers.Length - 2; i >= 0; i--)
                {
                    for (int k = 0; k < nHiddenLayerNodes[i]; ++k)
                    {
                        var node = new Node();
                        foreach (var hiddenNode in hiddenLayers[i + 1])
                        {
                            node.Connectors.Add(new Connector() { Weight = 1, Node = hiddenNode });
                        }
                        hiddenLayers[i].Add(node);
                    }

                }

                for (int i = 0; i < nInputs; ++i)
                {
                    var node = new Node();
                    foreach (var hiddenNode in hiddenLayers[0])
                    {
                        node.Connectors.Add(new Connector() { Weight = 1, Node = hiddenNode });
                    }
                    InputNodes.Add(node);
                }
            }
            else {
                for (int i = 0; i < nOutputs; ++i)
                {
                    OutputNodes.Add(new Node());
                }

                for (int i = 0; i < nInputs; ++i)
                {
                    var node = new Node();
                    foreach (var output in OutputNodes)
                    {
                        node.Connectors.Add(new Connector() { Weight = 1, Node = output });
                    }
                    InputNodes.Add(node);
                }
            }
        }

        public void RandomWeights(double standardDeviation)
        {
            foreach (var node in InputNodes)
            {
                foreach (var connector in node.Connectors)
                {
                    connector.Weight *= Random.NextGaussian(1, standardDeviation);
                }
            }
            if (nHiddenLayerNodes.Length >= 1)
            {
                foreach (List<Node> hiddenLayer in hiddenLayers)
                {
                    foreach (var node in hiddenLayer)
                    {
                        foreach (var connector in node.Connectors)
                        {
                            connector.Weight *= Random.NextGaussian(1, standardDeviation);
                        }
                    }
                }
            }
        }
    }
}
