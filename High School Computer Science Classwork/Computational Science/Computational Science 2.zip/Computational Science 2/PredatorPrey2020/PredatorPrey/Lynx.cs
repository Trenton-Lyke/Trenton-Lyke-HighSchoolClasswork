﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredatorPrey
{
    public class Lynx : Animal
    {
        private const double myWidth = .3;
        private const double myLength = 1;
        private const double myMaxSpeed = 10;
        private const double myStepTime = .3;
        private const double myMaxAccel = 4;
        private const double initialx = 25;
        private const double initialy = 40;
       
        public Hare Other { get; set; }
        public Perceptron Perceptron { get; set; } = new Perceptron(19, new int[] { 19,3 }, 2);
        public Lynx(Arena arena) :
            base(myWidth, myLength, myMaxSpeed, myMaxAccel, myStepTime, new Vector2D(initialx, initialy), arena)
        { }

        protected override Vector2D ChooseVelocityChange()
        {
            if (Perceptron != null) {

            Perceptron.AddInput(0, 4*(Other.Position.X - Position.X));
            Perceptron.AddInput(1, 4 * (Other.Position.Y - Position.Y));
            Perceptron.AddInput(2, Position.Y <5?100:0);
            Perceptron.AddInput(3, 2*(Arena.Height / 2 - Position.Y));
            Perceptron.AddInput(4, (Arena.Height-Position.Y) < 5 ? -100 : 0);
            Perceptron.AddInput(5, (Arena.Width - Position.X) < 5 ? -100 : 0);
            Perceptron.AddInput(6, Position.X < 5 ? 100 : 0);
            Perceptron.AddInput(7, Other.Velocity.X);
            Perceptron.AddInput(8,5 / (Position.X == 0 ? .000001 : Position.X));
            Perceptron.AddInput(9,5 / (Position.Y == 0 ? .000001 : Position.Y));
            Perceptron.AddInput(12, -5 / (Arena.Width-Position.X == 0 ? .000001 : Arena.Width - Position.X));
            Perceptron.AddInput(13, -5 / (Arena.Width - Position.Y == 0 ? .000001 : Arena.Width - Position.Y));
            Perceptron.AddInput(14, 2*(Arena.Width/2- Position.X));
                Perceptron.AddInput(15, Other.Velocity.Y);
                Perceptron.AddInput(16, 1);
                Perceptron.AddInput(17, Other.Velocity.Y-Velocity.Y);
                Perceptron.AddInput(18, Other.Velocity.X-Velocity.X);

                Perceptron.Run();

                double x = Perceptron.GetOutput(0);
                double y = Perceptron.GetOutput(1);

                //double x = 2 / (Position.X - Other.Position.X == 0 ? .000001 : Position.X - Other.Position.X) + 5 / (Position.X == 0 ? .000001 : Position.X) + 5 / (Position.X - Arena.Width == 0 ? .000001 : Position.X - Arena.Width);//Perceptron.GetOutput(0);
                //double y = 2 / (Position.Y - Other.Position.Y == 0 ? .000001 : Position.Y - Other.Position.Y) + 5 / (Position.Y == 0 ? .000001 : Position.Y) + 5 / (Position.Y - Arena.Height == 0 ? .000001 : Position.Y - Arena.Height);//Perceptron.GetOutput(1);
                acc = new Vector2D(x, y);
            return new Vector2D(x, y);

    }
            else {
                Vector2D diff = Other.Position - Position;

                return diff.UnitVector() * myMaxAccel + (new Vector2D((new Random()).NextBool() ? -1 : 1 * 2 *(new Random()).NextDouble(), (new Random()).NextBool() ? -1:1*2 * (new Random()).NextDouble()));
            }
        }

        protected override void Eat()
        {
            double xdiff = Math.Abs(Other.Position.X - Position.X);
            double ydiff = Math.Abs(Other.Position.Y - Position.Y);
            if (xdiff < myWidth / 2 && ydiff < myLength / 2)
            {
                Arena.RemoveAnimal(Other);
            }
        }
    }
}
