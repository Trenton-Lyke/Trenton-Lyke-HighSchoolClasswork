﻿namespace Visualizer
{
    class Driver
    {

        static internal void Run()
        {
            //Kinematics.KinematicsDriver.RunKinematics();
            //FiniteElement.FiniteElementDriver.RunFiniteElement();
            //MarbleMadness.MarbleMadnessDriver.RunMarbleMadness();
            //Thermodynamics.ThermodynamicsDriver.Run();
            //ChemicalReactions.ChemicalDriver.Run();
            //FastestDescent.FastestDescentDriver.RunFastestDescent();
            //ChemicalReactions.ChemicalDriver.Epidemiology();
            //RaceToTheBottom.RaceToTheBottomDriver.Run();
            PredatorPrey.PredatorPreyDriver.Run();
        }



    }

}
