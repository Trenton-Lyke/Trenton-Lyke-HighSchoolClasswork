﻿using DongUtility;
using MotionVisualizerControl;
using PredatorPrey;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace Visualizer.PredatorPrey
{

    static class PredatorPreyDriver
    {
        private static readonly string path = @"C:\Computational Science Data\";
        private const double width = 50;
        private const double height = 50;
        private const double timeStep = .01;
        private const double maxTime = 100;

        static private Arena PrepareArena(Perceptron harePerceptron, Perceptron lynxPerceptron=null)
        {
            var arena = new Arena(width, height);
            var hare = new Hare(arena);
            var lynx = new Lynx(arena);

            hare.Other = lynx;
            lynx.Other = hare;

            arena.AddAnimal(hare);
            arena.AddAnimal(lynx);

            hare.Perceptron = harePerceptron;
            lynx.Perceptron = lynxPerceptron;

            return arena;
        }

        static public double RunOnce(Arena arena)
        {
            bool keepRunning = true;

            while (keepRunning && arena.Time < maxTime)
            {
                keepRunning = arena.Update(arena.Time + timeStep);
            }

            return arena.Time;
        }
        //
        static private Perceptron TrainHare(int nInputNodes, int[] nHiddenLayerNodes, int nOutputNodes, Perceptron LynxPerceptron=null)
        {
            var file = File.CreateText(path + "Level1 Generation vs. Time Hare.txt");
            var perceptron = new Perceptron(nInputNodes, nHiddenLayerNodes, nOutputNodes );
            using (file)
            {
                file.WriteLine("Generation\t" + "Time");
                
                // Random starting point
                perceptron.RandomWeights(10);
                int numberOfSavedPerceptrons = 40;
                Perceptron[] perceptronArray = new Perceptron[numberOfSavedPerceptrons];
                perceptronArray[0] = perceptron;
                for (int i = 1; i < perceptronArray.Length; i++)
                {
                    Perceptron aPerceptron = new Perceptron(nInputNodes, new int[]{ }, nOutputNodes);
                    aPerceptron.RandomWeights(10);
                    perceptronArray[i] = aPerceptron;
                }
                int numberOfPerceptrons = 10000;

                double oldTime = RunOnce(PrepareArena(perceptron, LynxPerceptron));
                double currentBestTime = oldTime;
                double minTimeDifferenceAllowed = 0;
                double timeDifference = 0;
                double[] standardDeviations = new double[] { 1, 5, 20,100 };
                int generationNumber = 0;
                file.WriteLine(generationNumber + "\t" + currentBestTime);

                // Do stuff here to modify the perceptron, cloning it and so forth
                do
                {
                    generationNumber++;
                    Perceptron[] perceptrons = new Perceptron[numberOfPerceptrons * numberOfSavedPerceptrons];
                    foreach (Perceptron savedPerceptron in perceptronArray)
                    {
                        for (int i = 0; i < perceptrons.Length; i++)
                        {
                            perceptrons[i] = savedPerceptron.RandomClone(standardDeviations[i % standardDeviations.Length]);
                        }
                    }
                    ConcurrentDictionary<Perceptron, double> perceptronLivingTimes = new ConcurrentDictionary<Perceptron, double>();
                    Parallel.ForEach(perceptrons, (aPerceptron) =>
                    {
                        perceptronLivingTimes.TryAdd(aPerceptron, RunOnce(PrepareArena(aPerceptron, LynxPerceptron)));
                    });
                    Perceptron[] topPerceptrons = new Perceptron[numberOfSavedPerceptrons];
                    double[] topPerceptronTimes = new double[numberOfSavedPerceptrons];

                    for (int i = 0; i < topPerceptrons.Length; i++)
                    {
                        topPerceptrons[i] = new Perceptron(nInputNodes, nHiddenLayerNodes, nOutputNodes);
                        topPerceptronTimes[i] = double.MinValue;
                    }


                    foreach (Perceptron aPerceptron in perceptronLivingTimes.Keys)
                    {
                        double aTime = double.MinValue;
                        perceptronLivingTimes.TryGetValue(aPerceptron, out aTime);
                        for (int i = 0; i < topPerceptrons.Length; i++)
                        {


                            if (aTime > topPerceptronTimes[i])
                            {
                                for (int k = i; k < topPerceptrons.Length - 1; k++)
                                {
                                    topPerceptrons[k + 1] = topPerceptrons[k];
                                    topPerceptronTimes[k + 1] = topPerceptronTimes[k];
                                }
                                topPerceptrons[i] = aPerceptron;
                                topPerceptronTimes[i] = aTime;
                                break;
                            }
                        }

                    }
                    
                    oldTime = currentBestTime;
                    currentBestTime = topPerceptronTimes[0];
                    if (currentBestTime > oldTime)
                    {
                        perceptron = topPerceptrons[0];
                    }


                    for (int i = 0; i < perceptronArray.Length; i++)
                    {
                        perceptronArray[i] = topPerceptrons[i];
                    }



                    file.WriteLine(generationNumber + "\t" + topPerceptronTimes[0]);
                    timeDifference = currentBestTime - oldTime;
                } while (timeDifference > minTimeDifferenceAllowed);
            }
            return perceptron;
        }
        static private Perceptron TrainLynx(int nInputNodes, int[] nHiddenLayerNodes, int nOutputNodes, Perceptron harePerceptron=null)
        {
            var file = File.CreateText(path + "Level1 Generation vs. Time Lynx.txt");
            var perceptron = new Perceptron(nInputNodes, nHiddenLayerNodes, nOutputNodes);
            using (file)
            {
                file.WriteLine("Generation\t" + "Time");

                // Random starting point
                perceptron.RandomWeights(10);
                int numberOfSavedPerceptrons = 20;
                Perceptron[] perceptronArray = new Perceptron[numberOfSavedPerceptrons];
                perceptronArray[0] = perceptron;
                for (int i = 1; i < perceptronArray.Length; i++)
                {
                    perceptronArray[i] = new Perceptron(nInputNodes, nHiddenLayerNodes, nOutputNodes);
                    perceptronArray[i].RandomWeights(0);
                }
                int numberOfPerceptrons = 100;

                double oldTime = RunOnce(PrepareArena(harePerceptron, perceptron));
                double currentBestTime = oldTime;
                double minTimeDifferenceAllowed = 0;
                double timeDifference = 0;
                double[] standardDeviations = new double[] { 1,5,20,100 };
                int generationNumber = 0;
                file.WriteLine(generationNumber + "\t" + currentBestTime);

                // Do stuff here to modify the perceptron, cloning it and so forth
                do
                {
                    generationNumber++;
                    Perceptron[] perceptrons = new Perceptron[numberOfPerceptrons * numberOfSavedPerceptrons];
                    foreach (Perceptron savedPerceptron in perceptronArray)
                    {
                        for (int i = 0; i < perceptrons.Length; i++)
                        {
                            perceptrons[i] = savedPerceptron.RandomClone(standardDeviations[i % standardDeviations.Length]);
                        }
                    }
                    ConcurrentDictionary<Perceptron, double> perceptronLivingTimes = new ConcurrentDictionary<Perceptron, double>();
                    Parallel.ForEach(perceptrons, (aPerceptron) =>
                    {
                        perceptronLivingTimes.TryAdd(aPerceptron, RunOnce(PrepareArena(harePerceptron, aPerceptron)));
                    });
                    Perceptron[] topPerceptrons = new Perceptron[numberOfSavedPerceptrons];
                    double[] topPerceptronTimes = new double[numberOfSavedPerceptrons];

                    for (int i = 0; i < topPerceptrons.Length; i++)
                    {
                        topPerceptrons[i] = new Perceptron(nInputNodes, nHiddenLayerNodes, nOutputNodes);
                        topPerceptronTimes[i] = double.MaxValue;
                    }


                    foreach (Perceptron aPerceptron in perceptronLivingTimes.Keys)
                    {
                        double aTime = double.MaxValue;
                        perceptronLivingTimes.TryGetValue(aPerceptron, out aTime);
                        for (int i = 0; i < topPerceptrons.Length; i++)
                        {


                            if (aTime < topPerceptronTimes[i])
                            {
                                for (int k = i; k < topPerceptrons.Length - 1; k++)
                                {
                                    topPerceptrons[k + 1] = topPerceptrons[k];
                                    topPerceptronTimes[k + 1] = topPerceptronTimes[k];
                                }
                                topPerceptrons[i] = aPerceptron;
                                topPerceptronTimes[i] = aTime;
                                break;
                            }
                        }

                    }

                    oldTime = currentBestTime;
                    currentBestTime = topPerceptronTimes[0];
                    if (currentBestTime < oldTime)
                    {
                        perceptron = topPerceptrons[0];
                    }
                    else {
                        currentBestTime = oldTime;
                    }


                    for (int i = 0; i < perceptronArray.Length; i++)
                    {
                        perceptronArray[i] = topPerceptrons[i];
                    }



                    file.WriteLine(generationNumber + "\t" + topPerceptronTimes[0]);
                    timeDifference = oldTime - currentBestTime;
                } while (generationNumber<10);
            }
            return perceptron;
        }

        static public void Run()
        {
            Perceptron harePerceptron = TrainHare(25, new int[] {  }, 2);
            Perceptron lynxPerceptron = TrainLynx(19, new int[] { 19,3}, 2, harePerceptron);
            var arena = PrepareArena(harePerceptron, lynxPerceptron);

            var visualization = new PredatorPreyVisualization(arena);
            var visualizer = new MotionVisualizer(visualization);
            //visualizer.AddText("(X,Y)",System.Windows.Media.Colors.Red, () => new Vector(arena.Animals[1].acc.X, arena.Animals[1].acc.Y, 0).ToString()) ;
            visualizer.Show();
        }
        
    }
}
