﻿using ProjectileMotion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using VisualizerControl.Shapes;

namespace Visualizer.Kinematics
{
    /// <summary>
    /// Class that acts as an adapter between my Projectile class and the IProjectile interface
    /// </summary>
    public class ProjectileAdapter : IProjectile
    {
        private ProjectileOnSpring Projectile;

        public ProjectileAdapter(ProjectileOnSpring Projectile)
        {
            this.Projectile = Projectile;
        }
        public Vector3D Position => new Vector3D(Projectile.ProjectilePosition.X, Projectile.ProjectilePosition.Y, Projectile.ProjectilePosition.Z);

        public Color Color => Colors.Crimson;

        public Shape3D Shape => new Sphere3D();

        public double Size => 1;
    }
}
