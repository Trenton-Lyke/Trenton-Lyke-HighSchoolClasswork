﻿using DongUtility;
using Utility;
using GraphControl;
using MotionVisualizerControl;
using ProjectileMotion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using VisualizerControl.Shapes;

namespace Visualizer.Kinematics
{
    static internal class KinematicsDriver
    {
        /// <summary>
        /// Runs levels of simulations
        /// </summary>
        static internal void RunKinematics()
        {
            Level1();
            //Level2();
            //Level3();
            //Level4();
        }
        /// <summary>
        /// Simulates a 5 kg ball in free fall
        /// </summary>
        static internal void Level1() 
        {
           
   
            ProjectileOnSpring proj1 = new ProjectileOnSpring(5, 0, new Utility.Vector(0, 0, 0), new Utility.Vector(4 / Math.Sqrt(2), 0, 4 / Math.Sqrt(2)), new Utility.Vector(0, 0, 0), new Utility.Vector(0, 0, 0), 0, 0);
            Dictionary<ProjectileOnSpring, List<int>> projDict = new Dictionary<ProjectileOnSpring, List<int>>();
            projDict.Add(proj1, new List<int>());
            
            // This should connect to your World or Engine class from your kinematics project
            var engine = new World(-9.8, projDict, 0.578);
            Simulate(engine);
        }

        /// <summary>
        /// Simulates a 5 kg ball in with air resistance
        /// </summary>
        static internal void Level2()
        {
            
            

            ProjectileOnSpring proj1 = new ProjectileOnSpring(5, .4, new Utility.Vector(0, 0, 0), new Utility.Vector(4 / Math.Sqrt(2), 0, 4 / Math.Sqrt(2)), new Utility.Vector(0, 0, 0), new Utility.Vector(0, 0, 0), 0, 0);
            Dictionary<ProjectileOnSpring, List<int>> projDict = new Dictionary<ProjectileOnSpring, List<int>>();
            projDict.Add(proj1, new List<int>());
            var engine = new World(-9.8, projDict, 0.569);
            Simulate(engine);
        }
        /// <summary>
        /// Simulates a 5 kg ball in on a spring in air resistance
        /// </summary>
        static internal void Level3()
        {
           
            
            ProjectileOnSpring proj1 = new ProjectileOnSpring(5, .4, new Utility.Vector(1, 1, 1), new Utility.Vector(-2, 1, 3), new Utility.Vector(0, 0, 0), new Utility.Vector(0, 0, 0), 5, 2);
            Dictionary<ProjectileOnSpring, List<int>> projDict = new Dictionary<ProjectileOnSpring, List<int>>();
            projDict.Add(proj1, new List<int> ());
            var engine = new World(-9.8, projDict, 34.7920000000096);
            SimulateWithSpring(engine);
        }

        /// <summary>
        /// Simulates a 5kg ball on a spring with a 3kg ball connected to it by a spring
        /// </summary>
        static internal void Level4()
        {

            
            ProjectileOnSpring proj1 = new ProjectileOnSpring(5, .4, new Utility.Vector(1, 1, 1), new Utility.Vector(-2, 1, 3), new Utility.Vector(0, 0, 0), new Utility.Vector(0, 0, 0), 5, 2);
            ProjectileOnSpring proj2 = new ProjectileOnSpring(3, 4, new Utility.Vector(2, 2, 2), new Utility.Vector(1, -3, 4), new Utility.Vector(0, 0, 0), new Utility.Vector(0, 0, 0), 5, 2);

            
            Dictionary<ProjectileOnSpring, List<int>> projDict = new Dictionary<ProjectileOnSpring, List<int>>();
            projDict.Add(proj1, new List<int> { 1});
            projDict.Add(proj2, new List<int>());
            var engine = new World(-9.8, projDict, 34.7920000000096);
            SimulateWithMultipleSprings(engine);
        }

        /// <summary>
        /// Creates visualizer based on given world
        /// </summary>

        static internal void Simulate(World engine) {
            // This will work once you define an EngineAdapter that inherits from IEngine
            var adapter = new WorldAdapter(engine);

            Sphere3D.NSegments = 40;
            var visualization = new KinematicsVisualization(adapter);

            

            Timeline.MaximumPoints = 3000;

            var fullViz = new MotionVisualizer(visualization);



            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectilePosition), "Time (s)", "CM Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectileVelocity), "Time (s)", "CM Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectileAcceleration), "Time (s)", "CM Acceleration (m/s^2)");

            //fullViz.AddSingleGraph("Velocity", Colors.Blue, () => engine.Time, () => engine.ProjectilesOnSprings.ElementAt(0).ProjectileVelocity.Magnitude,
            //"Time (s)", "Magnitude of Velocity");

            fullViz.Show();
        }

        /// <summary>
        /// Creates visualizer with a spring based on given world
        /// </summary>
        
        static internal void SimulateWithSpring(World engine)
        {
            // This will work once you define an EngineAdapter that inherits from IEngine
            var adapter = new WorldAdapter(engine);

            Sphere3D.NSegments = 40;
            var visualization = new KinematicsVisualization(adapter);

            visualization.ConnectorRadiusScale = .1;
            visualization.AddAnchoredConnector(0, new Vector3D(0, 0, 0), Colors.Gray);

            Timeline.MaximumPoints = 3000;

            var fullViz = new MotionVisualizer(visualization);



            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectilePosition), "Time (s)", "CM Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectileVelocity), "Time (s)", "CM Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectileAcceleration), "Time (s)", "CM Acceleration (m/s^2)");

            //fullViz.AddSingleGraph("Velocity", Colors.Blue, () => engine.Time, () => engine.ProjectilesOnSprings.ElementAt(0).ProjectileVelocity.Magnitude,
            //"Time (s)", "Magnitude of Velocity");

            fullViz.Show();
        }

        /// <summary>
        /// Creates visualizer with 2 springs based on given world
        /// </summary>

        static internal void SimulateWithMultipleSprings(World engine)
        {
            // This will work once you define an EngineAdapter that inherits from IEngine
            var adapter = new WorldAdapter(engine);

            Sphere3D.NSegments = 40;
            var visualization = new KinematicsVisualization(adapter);

            visualization.ConnectorRadiusScale = .1;
            visualization.AddAnchoredConnector(0, new Vector3D(0, 0, 0), Colors.Gray);
            visualization.AddTwoParticleConnector(0, 1, Colors.Gray);

            Timeline.MaximumPoints = 3000;

            var fullViz = new MotionVisualizer(visualization);

            

            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectilePosition), "Time (s)", "CM Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectileVelocity), "Time (s)", "CM Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(0).ProjectileAcceleration), "Time (s)", "CM Acceleration (m/s^2)");


            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(1).ProjectilePosition), "Time (s)", "CM Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(1).ProjectileVelocity), "Time (s)", "CM Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.Projectiles.ElementAt(1).ProjectileAcceleration), "Time (s)", "CM Acceleration (m/s^2)");

            fullViz.AddSingleGraph("Distance", Colors.Blue, () => engine.Time, () => (engine.Projectiles.ElementAt(0).ProjectilePosition- engine.Projectiles.ElementAt(1).ProjectilePosition).Magnitude,
            "Time (s)", "Distance Betwen Particles (m)");

            fullViz.Show();
        }
        /// <summary>
        /// Converts my utility's vector to a 3DVector
        /// </summary>
        private static Vector3D ConvertToVector3D(Utility.Vector vec)
        {
            return new Vector3D(vec.X, vec.Y, vec.Z);
        }
    }
}
