﻿using ProjectileMotion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visualizer.Kinematics
{
    /// <summary>
    /// Class that acts as an adapter between my World class and the IEngine interface
    /// </summary>
    class WorldAdapter : IEngine
    {
        private World world;
        private List<IProjectile> projectiles;
        public WorldAdapter(World world)
        {
            this.world = world;
            projectiles = new List<IProjectile>();
            foreach (ProjectileOnSpring projectile in world.Projectiles)
            {
                projectiles.Add(new ProjectileAdapter(projectile));
            }
        }

        

        public double Time => world.Time;

        List<IProjectile> IEngine.Projectiles => projectiles;

        /// <summary>
        /// updates time and the positions, velocities, and accelerations of projectiles
        /// </summary>
        
        public bool Tick(double newTime)
        {
            world.Tick(.01);
            return Time < world.ElapsedTime;
        }
    }
}
