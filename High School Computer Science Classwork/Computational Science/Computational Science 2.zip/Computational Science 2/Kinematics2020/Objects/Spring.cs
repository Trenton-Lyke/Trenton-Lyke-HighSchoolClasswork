﻿using System;
using Utility;

namespace Objects
{/// <summary>
 /// A class for representing springs
 /// </summary>
    public class Spring
    {
        public Spring(Vector anchorPoint1, Vector anchorPoint2, double springConstant = 0, double unstretchedSpringLength = 0)
        {
            SpringConstant = springConstant;
            UnstretchedSpringLength = unstretchedSpringLength;
            AnchorPoint1 = anchorPoint1;
            AnchorPoint2 = anchorPoint2;
        }

        /// <summary>
        /// spring constant in kg/s/s
        /// </summary>
        public double SpringConstant { get; private set; }
        /// <summary>
        /// Length at which spring does not exert any force in m
        /// </summary>
        public double UnstretchedSpringLength { get; private set; }
        /// <summary>
        /// The point in space where one end of the spring is fixed
        /// </summary>
        public Vector AnchorPoint1 { get; set; }

        public Vector AnchorPoint2 { get; set; }

    }
}
