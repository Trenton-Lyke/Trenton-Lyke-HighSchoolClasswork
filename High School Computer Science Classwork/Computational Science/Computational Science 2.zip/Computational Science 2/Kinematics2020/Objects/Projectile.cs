﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ProjectileMotion
{
    /// <summary>
    /// A class to represent projectiles
    /// </summary>
    public class Projectile
    {
        public Projectile(double mass, double dragCoefficient, Vector position, Vector velocity, Vector acceleration) {
            Mass = mass;
            Position = position;
            Velocity = velocity;
            Acceleration = acceleration;
            DragCoefficient = dragCoefficient;
        }

        /// <summary>
        /// Mass of projectile in kg
        /// </summary>
        public double Mass { private get; set; }
        /// <summary>
        /// Drag coefficient of projectile in kg/m
        /// </summary>
        public double DragCoefficient { private get; set; }
        /// <summary>
        /// Position of projectile in m
        /// </summary>
        public Vector Position { get; set; }
        /// <summary>
        /// Velocity of projectile in m/s
        /// </summary>
        public Vector Velocity { get; set; }
        /// <summary>
        /// Acceleration of projectile in m/s/s
        /// </summary>
        public Vector Acceleration { get; set; }

        
        /// <summary>
        /// Updates the position, velocity, and acceleration of the projectile
        /// </summary>
        public void UpdateProjectile(double increment, double gravitationalField, Vector springAnchorPoint, double springConstant, double unstretchedSpringLength) {
            double gravitationalForce = gravitationalField * Mass;
            Position += increment * Velocity;
            Velocity += increment * Acceleration;
            Vector unstretchedComponentLengths = unstretchedSpringLength * Position.UnitVector;
            Acceleration = (Vector.ComponentMultiplication(Vector.ComponentSign(-Velocity), (Vector.ComponentPow(Velocity, 2) * DragCoefficient)) - springConstant * (Position - springAnchorPoint - unstretchedComponentLengths) + (new Vector(0, 0, gravitationalForce))) / Mass;

        }
        
    }
}
