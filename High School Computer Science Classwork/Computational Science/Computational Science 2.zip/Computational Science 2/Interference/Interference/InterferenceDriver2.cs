﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Media;


namespace Interference
{
    static internal class InterferenceDriver
    {
        //speed of light in meters per second
        static double speedOfLight = 299792458;
        static public void Run()
        {
            
            levelI();
            //levelII();
            //levelIII();
            //Challenge();
        }
        /// <summary>
        /// Simulates double slit inteference assuming that the slits don't have a finite width
        /// </summary>
        private static void levelI()
        {

            const int numberOfColumns = 10000;
            const int numberOfRows = 1;
            // Create the visualizer
            // Use integers for the number of columns and rows
            var viz = new InterferenceVisualizer(numberOfColumns + 1, numberOfRows);

            // Do your work here
            //L distance from screen in meters
            const double distanceFromScreen = 10;

            //d distance between slits in meters
            const double distanceBetweenSlits = .125;

            //lambda wavelength in nanometers
            const double wavelength = .000000525;
            
            //width of screen in meters
            const double widthOfScreen = 1;

            //height of screen in meters
            const double heightOfScreen = 1;

            const double centerOfSlits = widthOfScreen / 2;

            const double leftSlitXPosition = centerOfSlits - (distanceBetweenSlits / 2);

            const double rightSlitXPosition = centerOfSlits + (distanceBetweenSlits / 2);

            //width of each column
            const double columnWidth = widthOfScreen / numberOfColumns;

            //height of each row in meter
            const double rowHeight = heightOfScreen / numberOfRows;

            //k phase shift 1/meters
            const double phaseShift = (2 * Math.PI) / wavelength;

            //A amplitude is 1/2 so that the range of intensities will be between 0 and 1
            const double intensityScalingCoefficient = .25;




            using (StreamWriter sw = File.CreateText(@"C:\imsa\output.txt"))
            {
                for (int column = 0; column < numberOfColumns + 1; column++)
                {
                    for (int row = 0; row < numberOfRows; row++)
                    {



                        /*point or cell with x,y, and z components calculated using the column and row of the cell, 
                        the width and heights of the columns and rows, and the distance from the screen*/
                        IDictionary<string, double> point = new Dictionary<string, double>()
                        {
                            {"X",column * columnWidth},
                            {"Y", row * rowHeight},
                            {"Z",distanceFromScreen}
                        };

                        //d1 distance from left slit to point
                        double distanceFromLeftSlitToPoint = Math.Sqrt(Math.Pow(point["X"] - leftSlitXPosition, 2) + Math.Pow(point["Y"] - 0, 2) + Math.Pow(distanceFromScreen, 2));

                        //d2 distance from right slit to point
                        double distanceFromRightSlitToPoint = Math.Sqrt(Math.Pow(point["X"] - rightSlitXPosition, 2) + Math.Pow(point["Y"] - 0, 2) + Math.Pow(distanceFromScreen, 2));

                        //amplitude of cosine function
                        double amplitude = 2 * Math.Cos((phaseShift * (distanceFromRightSlitToPoint - distanceFromLeftSlitToPoint) / 2));

                        //intensity of light in the cell
                        double intensity = intensityScalingCoefficient * Math.Abs(Math.Pow(amplitude, 2));

                       
                        // Use this to set the color and intensity of a cell
                        // Intensity must be between zero and one
                        viz.Display.SetCell(column, row, wavelength, intensity);
                        sw.WriteLine(intensity);
                    }
                }
            }

            // See it!
            viz.Show();
        }
        /// <summary>
        /// Finds the peak points and adds their shortest and longest distances between them into a given file along with other variable
        /// </summary>
        /// <param name="sw">stream witer used to write in file</param>
        /// <param name="wavelength">wavelength of light in meters</param>
        /// <param name="distanceBetweenSlits">distance between slits in meters</param>
        /// <param name="distanceFromScreen">distance from screen in meters</param>
        /// <param name="writeDifferences">if you want information to be written into a text file</param>
        /// <returns>the list of peak positions</returns>
        private static List<double> levelIIGetPeakPositions(StreamWriter sw, double wavelength, double distanceBetweenSlits, double distanceFromScreen, bool writeDifferences)
        {
            const int numberOfColumns = 1000001;
            const int numberOfRows = 1;
            // Create the visualizer
            // Use integers for the number of columns and rows
            var viz = new InterferenceVisualizer(numberOfColumns + 1, numberOfRows);

            // Do your work here
            //L distance from screen in meters
            

            //d distance between slits in meters
            

            //lambda wavelength in nanometers
            

            //width of screen in meters
            const double widthOfScreen = 1;

            //height of screen in meters
            const double heightOfScreen = 1;

            const double centerOfSlits = widthOfScreen / 2;

            double leftSlitXPosition = centerOfSlits - (distanceBetweenSlits / 2);

            double rightSlitXPosition = centerOfSlits + (distanceBetweenSlits / 2);

            //width of each column
            const double columnWidth = widthOfScreen / numberOfColumns;

            //height of each row in meter
            const double rowHeight = heightOfScreen / numberOfRows;

            //k
            double phaseShift = (2 * Math.PI) / wavelength;

            //A amplitude is 1/2 so that the range of intensities will be between 0 and 1
            const double intensityScalingCoefficient = .25;




            
            //past intensity (-1 acts as null for past intensities if there was none)
            double pastIntensity = -1;
            //past trend (can be "positive", "negative", or null if their was no past trend)  
            string pastTrend = null;
            //past position of the previous cell
            double pastPosition = 0;
            //list of positions of peak points
            List<double> peakPositions = new List<double>();
            List<double> intensities = new List<double>();
            List<double> intensityPositions = new List<double>();
            for (int column = 0; column < numberOfColumns + 1; column++)
            {
                for (int row = 0; row < numberOfRows; row++)
                {

                    
                    //point to represent cell with its x,y, and z components
                    IDictionary<string, double> point = new Dictionary<string, double>()
                    {
                        {"X",column * columnWidth},
                        {"Y", row * rowHeight},
                        {"Z",distanceFromScreen}
                    };

                    //d1 distance from left slit to point
                    double distanceFromLeftSlitToPoint = Math.Sqrt(Math.Pow(point["X"] - leftSlitXPosition, 2) + Math.Pow(point["Y"] - 0, 2) + Math.Pow(distanceFromScreen, 2));

                    //d2 distance from right slit to point
                    double distanceFromRightSlitToPoint = Math.Sqrt(Math.Pow(point["X"] - rightSlitXPosition, 2) + Math.Pow(point["Y"] - 0, 2) + Math.Pow(distanceFromScreen, 2));

                    //amplitude of cosine function
                    double amplitude = 2 * Math.Cos((phaseShift * (distanceFromRightSlitToPoint - distanceFromLeftSlitToPoint) / 2));

                    //intensity of cell
                    double intensity = intensityScalingCoefficient * Math.Abs(Math.Pow(amplitude, 2));


                    //intensities.Add(intensity);
                    //sw.WriteLine(intensity);
                    // Use this to set the color and intensity of a cell
                    // Intensity must be between zero and one
                    viz.Display.SetCell(column, row, wavelength, intensity);
                    

                    //adds the past cells position to the list of peak positions if it was a peak
                    if (isPastPeak(pastTrend, pastIntensity, intensity))
                    {
                        peakPositions.Add(pastPosition);
                    }

                    //sets the past information equal to the current information for the next iteration
                    pastTrend = getTrend(pastIntensity, intensity);
                    pastIntensity = intensity;
                    pastPosition = point["X"];
                }
            }
            //Writes distances between peak points if it is specified in the parameters of the function
            if (writeDifferences)
            {
                sw.WriteLine(wavelength + "\t" + distanceBetweenSlits + "\t" + distanceFromScreen + "\t" + getShortestDistance(peakPositions) + "\t" + getLongestDistance(peakPositions));
            }

            // See it!
            viz.Show();
            return peakPositions;
        }
        private static void levelII() {

            using (StreamWriter sw = File.CreateText(@"C:\imsa\output.txt"))
            {
                //writes peak positions in the text file
                List<double> peakPositions = levelIIGetPeakPositions(sw, .000000525, .125, 10, false);
                sw.WriteLine("Peak Position \t Distance from Last Peak");
                for (int i = 1; i < peakPositions.Count(); i++)
                {
                    sw.WriteLine(peakPositions[i] + "\t" + (peakPositions[i]- peakPositions[i-1]));
                }
                sw.WriteLine("");

                /*Writes shortest and longest distances between peaks into a text file relative to
                wavelength, distance between slits, and distance from screen*/
                sw.WriteLine("Wavelength\tDistance Between Slits\tDistance From Screen\tShortest Distance\tLongest Distance");

                for (double wavelength = .000000325; wavelength <= .000003625; wavelength += .000000300)
                {
                    levelIIGetPeakPositions(sw, wavelength, .125, 10, true);
                }
                for (double distanceBetweenSlits = .01; distanceBetweenSlits <= .51; distanceBetweenSlits += .05)
                {
                    levelIIGetPeakPositions(sw, .000000525, distanceBetweenSlits, 10, true);
                }
                for (double distanceFromScreen = 14; distanceFromScreen <= 64; distanceFromScreen += 5)
                {
                    levelIIGetPeakPositions(sw, .000000525, .125, distanceFromScreen, true);
                }
            }
        }
        /// <summary>
        /// gets the trend based on the cange in intensity
        /// </summary>
        /// <param name="pastIntensity">past intensity</param>
        /// <param name="currentIntensity">current intensity</param>
        /// <returns>the trend</returns>
        private static string getTrend(double pastIntensity, double currentIntensity)
        {
            if (pastIntensity == -1) {
                return null;
            }
            else if (currentIntensity > pastIntensity)
            {
                return "positive";
            }
            else
            {
                return "negative";
            }
        }
        /// <summary>
        /// determines if the past point was a peak
        /// </summary>
        /// <param name="pastTrend">the previous intensity trend</param>
        /// <param name="pastIntensity">the previous cells intensity</param>
        /// <param name="currentIntensity">the current intensity</param>
        /// <returns>if the past cell had a peak intensity</returns>
        private static bool isPastPeak(String pastTrend, double pastIntensity, double currentIntensity) {
            string currentTrend = getTrend(pastIntensity, currentIntensity);
            if (pastTrend == "positive" && currentTrend == "negative")
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        /// <summary>
        /// gets the shortest distance between peaks
        /// </summary>
        /// <param name="peakPositions">list of peak positions</param>
        /// <returns>shortest distance between peak positions</returns>
        private static double getShortestDistance(List<double> peakPositions) {
            double shortestDistance = (double)int.MaxValue;
            for (int i = 1; i < peakPositions.Count(); i++) {
                if (peakPositions[i] - peakPositions[i - 1] < shortestDistance)
                {
                    shortestDistance = peakPositions[i] - peakPositions[i - 1];
                }
            }
            return shortestDistance;
        }
        /// <summary>
        /// gets the longest distance between peaks
        /// </summary>
        /// <param name="peakPositions">list of peak positions</param>
        /// <returns>longest distance between peak positions</returns>
        private static double getLongestDistance(List<double> peakPositions)
        {
            double longestDistance = (double)int.MinValue;
            for (int i = 1; i < peakPositions.Count(); i++)
            {
                if (peakPositions[i] - peakPositions[i - 1] > longestDistance)
                {
                    longestDistance = peakPositions[i] - peakPositions[i - 1];
                }
            }
            return longestDistance;
        }
        /// <summary>
        /// simulates double slit interference assuming that slits have fixed widths
        /// </summary>
        private static void levelIII()
        {

            //const int numberOfColumns = 10000;
            //const int numberOfPointsInSlit = 10000;
            const int numberOfColumns = 1000;
            //number of points in slit
            const int numberOfPointsInSlit = 100;
            const int numberOfRows = 1;
            // Create the visualizer
            // Use integers for the number of columns and rows
            var viz = new InterferenceVisualizer(numberOfColumns + 1, numberOfRows);

            // Do your work here
            //L distance from screen in meters
            const double distanceFromScreen = 10;

            //d distance between slits in meters
            const double distanceBetweenSlits = .125;

            //lambda wavelength in nanometers
            const double wavelength = .000000525;

            //width of screen in meters
            const double widthOfScreen = 1;

            //height of screen in meters
            const double heightOfScreen = 1;

            const double centerOfSlits = widthOfScreen / 2;

            const double leftSlitXPosition = centerOfSlits - (distanceBetweenSlits / 2);

            const double rightSlitXPosition = centerOfSlits + (distanceBetweenSlits / 2);

            //width of slit in meters
            const double slitWidth = 0.00001;

            //width of each column
            const double columnWidth = widthOfScreen / numberOfColumns;

            

            //height of each row in meter
            const double rowHeight = heightOfScreen / numberOfRows;

            const double slitPointsWidth = slitWidth / numberOfPointsInSlit;

            //k
            const double phaseShift = (2 * Math.PI) / wavelength;

            //w
            double w = speedOfLight * phaseShift;

            

            double intensityScalingCoefficient = 0.0000262010575096307;



            using (StreamWriter sw = File.CreateText(@"C:\imsa\output.txt"))
            {
                for (int column = 0; column < numberOfColumns + 1; column++)
                {
                    for (int row = 0; row < numberOfRows; row++)
                    {


                        //double[] point = { column * columnWidth, row * rowHeight, distanceFromScreen}

                        IDictionary<string, double> point = new Dictionary<string, double>()
                        {
                            {"X",column * columnWidth},
                            {"Y", row * rowHeight},
                            {"Z",distanceFromScreen}
                        };
                        //makes a list of point positions in the slit
                        List<double> slitXPointPositions = new List<double>();
                        for (int i = 0; i < numberOfPointsInSlit; i++) {
                            slitXPointPositions.Add(leftSlitXPosition - i*slitPointsWidth);
                            slitXPointPositions.Add(rightSlitXPosition + i * slitPointsWidth);
                        }
                        List<double> distances = getDistances(point, slitXPointPositions , distanceFromScreen);
                        double amplitude = getAmplitude(w, phaseShift, distances);
                        double intensity = intensityScalingCoefficient * Math.Abs(Math.Pow(amplitude, 2));


                        // Use this to set the color and intensity of a cell
                        // Intensity must be between zero and one
                        viz.Display.SetCell(column, row, wavelength, intensity);
                        sw.WriteLine(intensity);
                    }
                }
            }

            // See it!
            viz.Show();
        }
        /// <summary>
        /// Simulates double slit interference on a 2D screeen
        /// </summary>
        private static void Challenge()
        {

            //const int numberOfColumns = 10000;
            //const int numberOfPointsInSlit = 10000;
            const int numberOfColumns = 10000;
            const int numberOfPointsInSlit = 100;
            const int numberOfRows = 10;
            // Create the visualizer
            // Use integers for the number of columns and rows
            var viz = new InterferenceVisualizer(numberOfColumns + 1, numberOfRows);

            // Do your work here
            //L distance from screen in meters
            const double distanceFromScreen = 10;

            //d distance between slits in meters
            const double distanceBetweenSlits = .125;

            //lambda wavelength in nanometers
            const double wavelength = .000000525;

            //width of screen in meters
            const double widthOfScreen = 1;

            //height of screen in meters
            const double heightOfScreen = 1;

            const double centerOfSlits = widthOfScreen / 2;

            const double leftSlitXPosition = centerOfSlits - (distanceBetweenSlits / 2);

            const double rightSlitXPosition = centerOfSlits + (distanceBetweenSlits / 2);

            const double slitWidth = 0.00001;

            //width of each column
            const double columnWidth = widthOfScreen / numberOfColumns;



            //height of each row in meter
            const double rowHeight = heightOfScreen / numberOfRows;

            const double slitPointsWidth = slitWidth / numberOfPointsInSlit;

            //k
            const double phaseShift = (2 * Math.PI) / wavelength;

            //w
            double w = speedOfLight * phaseShift;

            //A amplitude is 1/2 so that the range of intensities will be between 0 and 1
            double intensityScalingCoefficient = 0.0000262010575096307;




            using (StreamWriter sw = File.CreateText(@"C:\imsa\output.txt"))
            {
                for (int column = 0; column < numberOfColumns + 1; column++)
                {
                    for (int row = 0; row < numberOfRows; row++)
                    {


                        //double[] point = { column * columnWidth, row * rowHeight, distanceFromScreen}

                        IDictionary<string, double> point = new Dictionary<string, double>()
                        {
                            {"X",column * columnWidth},
                            {"Y", row * rowHeight},
                            {"Z",distanceFromScreen}
                        };
                        List<double> slitXPointPositions = new List<double>();
                        for (int i = 0; i < numberOfPointsInSlit; i++)
                        {
                            slitXPointPositions.Add(leftSlitXPosition - i * slitPointsWidth);
                            slitXPointPositions.Add(rightSlitXPosition + i * slitPointsWidth);
                        }
                        List<double> distances = getDistances(point, slitXPointPositions, distanceFromScreen, centerOfSlits);
                        double amplitude = getAmplitude(w, phaseShift, distances);
                        double intensity = intensityScalingCoefficient * Math.Abs(Math.Pow(amplitude, 2));


                        // Use this to set the color and intensity of a cell
                        // Intensity must be between zero and one
                        viz.Display.SetCell(column, row, wavelength, intensity);
                        sw.WriteLine(intensity);
                    }
                }
            }

            // See it!
            viz.Show();
        }
        /// <summary>
        /// gets the distances that each point in the slits are from a point on the screen
        /// </summary>
        /// <param name="point">point on the screen</param>
        /// <param name="slitXPositions">points in the slits</param>
        /// <param name="distanceFromScreen">distance from the screen</param>
        /// <returns>distances from points in slit to a point on the screen</returns>
        private static List<double> getDistances(IDictionary<string, double> point, List<double> slitXPositions, double distanceFromScreen) {
            return getDistances(point, slitXPositions, distanceFromScreen, 0);
        }
        /// <summary>
        /// gets the distances that each point in the slits are from a point on the screen
        /// </summary>
        /// <param name="point">point on the screen</param>
        /// <param name="slitXPositions">points in the slits</param>
        /// <param name="distanceFromScreen">distance from the screen</param>
        /// <returns>distances from points in slit to a point on the screen</returns>
        private static List<double> getDistances(IDictionary<string, double> point, List<double> slitXPositions, double distanceFromScreen, double slitYPosition)
        {
            List<double> distancesFromSlitToPoint = new List<double>();
            foreach (var slitXPosition in slitXPositions)
            {
                distancesFromSlitToPoint.Add(Math.Sqrt(Math.Pow(point["X"] - slitXPosition, 2) + Math.Pow(point["Y"] - slitYPosition, 2) + Math.Pow(distanceFromScreen, 2)));
            }
            return distancesFromSlitToPoint;
        }
        /// <summary>
        /// gets the period of the cosine function
        /// </summary>
        /// <param name="w"></param>
        /// <returns>period of cosine function</returns>
        private static double getPeriod(double w) {
            //T
            double period = (2 * Math.PI) / w;
            return period;
        }
        /// <summary>
        /// gets the sum of the cosine functions at a certain time
        /// </summary>
        /// <param name="w"></param>
        /// <param name="phaseShift"></param>
        /// <param name="distances">distance from point in slit to screen</param>
        /// <param name="time">given time</param>
        /// <returns>sum of cosine functions</returns>
        private static double getSumAtTime(double w, double phaseShift, List<double> distances, double time) {
            double sum = 0;
            foreach (var distance in distances) {
                sum += Math.Cos(w*time-phaseShift*distance);
            }
            return sum;
        }
        /// <summary>
        /// gets the amplitude
        /// </summary>
        /// <param name="w"></param>
        /// <param name="phaseShift"></param>
        /// <param name="distances">distances from points in slits to points on screen</param>
        /// <returns>amplitude of function</returns>
        private static double getAmplitude(double w, double phaseShift, List<double> distances) {
            double period = getPeriod(w);
            //double step = 0.0000000000000000001;
            double step = 0.0000000000000001;
            double amplitude = 0;
            for (double time = 0; time <= period; time += step) {
                double currentSum = getSumAtTime(w, phaseShift, distances, time);
                if (Math.Abs(currentSum) > Math.Abs(amplitude))
                {
                    amplitude = currentSum;
                }
            }
            return amplitude;
        }
    }
}

