﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DongUtility
{
    public class Line
    {
        public List<Point> pointsInLine { get; }
        public Point endPoint1 { get; }
        public Point endPoint2 { get; }
        public Line(Point point1, Point point2)
        {
            endPoint1 = point1;
            endPoint2 = point2;
            double step = .01;
            Vector slope = DifferenceOfPoints / (DifferenceOfPoints.X);
            
            pointsInLine = new List<Point>();
            for (double i = 0; i <= endPoint2.X-endPoint1.X; i+=step) {
                Point pointInLine = new Point(slope.X * i, slope.Y * i, slope.Z * i) + endPoint1;
                pointsInLine.Add(pointInLine);
            }
        }
        public Vector DifferenceOfPoints
        {
            get => new Vector(endPoint2.X - endPoint1.X, endPoint2.Y - endPoint1.Y, endPoint2.Z - endPoint1.Z);
        }

    }
}
