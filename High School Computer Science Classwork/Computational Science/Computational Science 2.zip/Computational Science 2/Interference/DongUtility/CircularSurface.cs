﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DongUtility
{
    public class CircularSurface
    {

        public List<Point> pointsInCircle { get; }

        public CircularSurface(double radius, Point centerPoint)
        {
            pointsInCircle = new List<Point>();
            double angleStep = .01;
            double radiusStep = .01;
            for (double angle = 0; angle < 2 * Math.PI; angle += angleStep)
            {
                for (double increasingRadius = 0; increasingRadius <= radius; increasingRadius += radiusStep)
                {
                    double Xvalue = centerPoint.X + (increasingRadius * Math.Cos(angle));
                    double Yvalue = centerPoint.Y + (increasingRadius * Math.Sin(angle));
                    Point pointInCircle = new Point(Xvalue, Yvalue, centerPoint.Z);
                    pointsInCircle.Add(pointInCircle);
                }
            }
        }
    }
}
