﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DongUtility
{
    public class Point
    {
        /// <summary>
        /// returns and sets the x component of the point
        /// </summary>
        public double X { get; set; }
        /// <summary>
        /// returns and sets the y component of the point
        /// </summary>
        public double Y { get; set; }
        /// <summary>
        /// returns and sets the z component of the point
        /// </summary>
        public double Z { get; set; }

        /// <summary>
        /// constructor for point object
        /// </summary>
        /// <param name="x">x component</param>
        /// <param name="y">y component</param>
        /// <param name="z">z component</param>
        public Point(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        static public Point operator +(Point point1, Point point2)
        {
            return new Point(
            point1.X + point2.X,
            point1.Y + point2.Y,
            point1.Z + point2.Z
            );
        }
        /// <summary>
        /// Finds the difference of two points
        /// </summary>
        /// <param name="point1">First point</param>
        /// <param name="point2">Second point</param>
        /// <returns>returns the difference of two points</returns>
        static public Point operator -(Point point1, Point point2)
        {
            return point1 + -point2;
        }
        /// <summary>
        /// Finds the point with the components with the opposite sign
        /// </summary>
        /// <param name="point">A point</param>
        /// <returns>returns the point with an opposite sign components</returns>
        static public Point operator -(Point point)
        {
            return -1 * point;
        }

        /// <summary>
        /// Finds the product of a pointtor multiplied by scalar
        /// </summary>
        /// <param name="point">A pointtor</param>
        /// <param name="scalar">A scalar</param>
        /// <returns>returns the product of a pointtor multiplied by the scalar</returns>
        static public Point operator *(Point point, double scalar)
        {
            return new Point(
            point.X * scalar,
            point.Y * scalar,
            point.Z * scalar
            );
        }
        /// <summary>
        /// Finds the product of a pointtor multiplied by scalar
        /// </summary>
        /// <param name="point">A pointtor</param>
        /// <param name="scalar">A scalar</param>
        /// <returns>returns the product of a pointtor multiplied by the scalar</returns>
        static public Point operator *(double scalar, Point point)
        {
            return point * scalar;
        }
    }
}
