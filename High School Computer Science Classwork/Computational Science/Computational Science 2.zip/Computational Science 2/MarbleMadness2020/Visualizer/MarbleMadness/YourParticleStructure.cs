﻿using DongUtility;
using FiniteElement;
using PhysicsUtility;
using System;
using System.Collections.Generic;
using System.Text;

namespace Visualizer.MarbleMadness
{
    class YourParticleStructure : ParticleStructure
    {
        public YourParticleStructure()
        {
            const double eachMass = .005 / 27;
            const double springConstant = .5;
            const double side = .01;
            const int nParticles = 3;

            Projectile[,,] projectiles = new Projectile[nParticles, nParticles, nParticles];
            for (int ix = 0; ix < nParticles; ++ix)
                for (int iy = 0; iy < nParticles; ++iy)
                    for (int iz = 0; iz < nParticles; ++iz)
                    {

                        var proj = new Projectile(new Vector((double)ix / nParticles * side,
                            (double)iy / nParticles * side, (double)iz / nParticles * side +.5), Vector.NullVector(), eachMass);
                        projectiles[ix, iy, iz] = proj;
                    }

            foreach (var proj in projectiles)
            {
                AddProjectile(proj);
            }

            for (int ix = 0; ix <= side; ++ix)
                for (int iy = 0; iy <= side; ++iy)
                    for (int iz = 0; iz <= side; ++iz)
                    {
                        if (ix < side)
                            AddConnector(projectiles[ix, iy, iz], projectiles[ix + 1, iy, iz], springConstant);
                        if (iy < side)
                            AddConnector(projectiles[ix, iy, iz], projectiles[ix, iy + 1, iz], springConstant);
                        if (iz < side)
                            AddConnector(projectiles[ix, iy, iz], projectiles[ix, iy, iz + 1], springConstant);
                    }
        }
    }
}
