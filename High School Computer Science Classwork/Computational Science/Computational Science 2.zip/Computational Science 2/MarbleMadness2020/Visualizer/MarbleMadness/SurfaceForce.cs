﻿using DongUtility;
using FiniteElement;
using PhysicsUtility;
using System;
using System.Collections.Generic;
using System.Text;

namespace Visualizer.MarbleMadness
{
    class SurfaceForce : GlobalForce
    {
        private List<Surface> surfaces = new List<Surface>();
        private KinematicsEngine engine;

        public SurfaceForce(KinematicsEngine engine) :
            base(engine)
        {
            this.engine = engine;
        }

        private Vector GetDeltaV(Projectile projectile, Triangle triangle,
            double elasticity, double frictionCoefficient)
        {
            Vector velocity = PredictVelocity(projectile);
            Vector perpendicularComponent = velocity.ProjectOnto(triangle.Normal);
            Vector parallelComponent = triangle.Normal - perpendicularComponent;

            Vector newPerpendicularVelocity = Bounce(perpendicularComponent, elasticity);
            double deltaVPerp = (newPerpendicularVelocity - perpendicularComponent).Magnitude;
            Vector perpendicularNormalForce = NormalForceToCancel(projectile, triangle, perpendicularComponent);
            double deltaVParallel = CalcDeltaVParallel(deltaVPerp, frictionCoefficient, projectile.Mass, perpendicularNormalForce.Magnitude);
            Vector newParallelVelocity = Friction(parallelComponent, deltaVParallel);

            Vector totalNewVelocity = newParallelVelocity + newPerpendicularVelocity;
            return totalNewVelocity - projectile.Velocity;
        }

        private Vector Bounce(Vector perpendicularVelocity, double elasticity)
        {
            return -perpendicularVelocity * elasticity;
        }

        private Vector Friction(Vector parallelVelocity, double deltaV)
        {
            double speed = parallelVelocity.Magnitude;

            if (speed < deltaV)
            {
                return Vector.NullVector();
            }
            else
            {
                double newSpeed = speed - deltaV;
                return parallelVelocity * (newSpeed / speed);
            }
        }

        private double CalcDeltaVParallel(double deltaVPerp, double frictionCoefficient, double mass, double externalNormalForce)
        {
            double acceleration = deltaVPerp / engine.DeltaTime;
            double normalForce = mass * acceleration + externalNormalForce;
            double frictionForce = normalForce * frictionCoefficient;
            double newAcceleration = frictionForce / mass;
            return newAcceleration * engine.DeltaTime;
        }

        private Vector NormalForceToCancel(Projectile projectile, Triangle triangle, Vector velocityTowardTriangle)
        {
            Vector currentForcePerp = projectile.NetForce.ProjectOnto(triangle.Normal);
            double dotProd = Vector.Dot(currentForcePerp, velocityTowardTriangle);
            if (dotProd >= 0)
            {
                return Vector.NullVector();
            }
            else
            {
                return -currentForcePerp;
            }
        }

        private Vector CalcForce(Projectile projectile, Triangle triangle, Vector deltaV)
        {

            Vector velocityTowardTriangle = deltaV.ProjectOnto(triangle.Normal);
            Vector acceleration = deltaV / engine.DeltaTime;
            return projectile.Mass * acceleration + NormalForceToCancel(projectile, triangle, velocityTowardTriangle);
        }

        private Vector PredictVelocity(Projectile projectile)
        {
            Vector newAcceleration = projectile.NetForce * projectile.Mass;
            return projectile.Velocity + newAcceleration * engine.DeltaTime;
        }

        private Vector PredictPosition(Projectile projectile)
        {
            return projectile.Position + PredictVelocity(projectile) * engine.DeltaTime;
        }

        override protected Vector GetForce(Projectile projectile)
        {
            Vector nextLocation = PredictPosition(projectile);

            Vector totalForce = Vector.NullVector();
            foreach (var surface in surfaces)
                foreach (var triangle in surface.Triangles)
                {
                    if (triangle.PassedThrough(projectile.Position, nextLocation))
                    {
                        Vector deltaV = GetDeltaV(projectile, triangle,
                            surface.Elasticity, surface.FrictionCoefficient);
                        totalForce += CalcForce(projectile, triangle, deltaV);
                    }
                }

            //Vector newVelocity = projectile.Velocity + totalDeltaV;
            //projectile.Velocity = newVelocity;

            return totalForce;
        }

        public void AddSurface(Surface surface)
        {
            surfaces.Add(surface);
        }
    }
}
