﻿using DongUtility;
using PhysicsUtility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace Visualizer.MarbleMadness
{
    public class YOURNAMEMarbleMachine : MarbleMachine
    {
        public YOURNAMEMarbleMachine()
        {
            var surface1 = new Surface(.5, 1);
            surface1.AddQuad(new Vector(-.5, -.5, 0),
            new Vector(-.5, .5, 0),
            new Vector(.5, .5, -.5),
            new Vector(.5, -.5, -.5),
            WPFUtility.UtilityFunctions.ConvertColor(Colors.Fuchsia));
            //surface1.AddQuad(new Vector(-.5, .5, .5),
            //new Vector(-.5, 0, 0),
            //new Vector(.5, 0, -.5),
            //new Vector(.5, .5, -.5),
            //WPFUtility.UtilityFunctions.ConvertColor(Colors.Fuchsia));
            AddSurface(surface1);
        }

        protected override Vector Beginning => new Vector(0, 0, .5);

        protected override Vector Ending => new Vector(.5, 0, -.5);
    }
}
