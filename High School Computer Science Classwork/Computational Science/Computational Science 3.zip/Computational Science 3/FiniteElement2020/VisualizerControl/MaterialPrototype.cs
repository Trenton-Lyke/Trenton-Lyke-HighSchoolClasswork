﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace VisualizerControl
{
    abstract public class MaterialPrototype
    {
        abstract public Material Material { get; }
    }
}
