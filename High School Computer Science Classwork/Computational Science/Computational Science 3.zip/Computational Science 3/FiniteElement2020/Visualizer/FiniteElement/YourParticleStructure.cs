﻿using DongUtility;
using FiniteElement;
using System;
using System.Collections.Generic;
using System.Text;

namespace Visualizer.FiniteElement
{
    class YourParticleStructure : ParticleStructure
    {
        
        static List<Projectile> ProjectilesList = new List<Projectile>();

        public YourParticleStructure()
        {


            //Level1();
            Level2();



        }
        /// <summary>
        /// Creates an object made of projectiles and springs for level 1
        /// </summary>
        public void Level1()
        {
            const int numberOfProjectiles = 27;
            const double totalMass = 5;
            const double springConstant = 60000;
            const double eachMass = totalMass / numberOfProjectiles;
            const double cubeHeight = 1;
            int numberOfProjectileOnLine = (int)Math.Pow(numberOfProjectiles, ((double)1.0 / 3));
            double distanceBetweenProjectiles = cubeHeight / numberOfProjectileOnLine;
            Vector basePointPosition = new Vector(0, 0, 3);
            Vector zeroVector = new Vector(0, 0, 0);
            Projectile[,,] Projectiles = new Projectile[numberOfProjectileOnLine, numberOfProjectileOnLine, numberOfProjectileOnLine];

            for (int i = 0; i < numberOfProjectileOnLine; i++)
            {
                for (int j = 0; j < numberOfProjectileOnLine; j++)
                {
                    for (int k = 0; k < numberOfProjectileOnLine; k++)
                    {
                        Projectiles[i, j, k] = new Projectile(basePointPosition + new Vector(i * distanceBetweenProjectiles, j * distanceBetweenProjectiles, k * distanceBetweenProjectiles), zeroVector, eachMass);
                        ProjectilesList.Add(Projectiles[i, j, k]);
                        AddProjectile(Projectiles[i, j, k]);
                        
                    }
                }
            }
            
            addConnectors(Projectiles, numberOfProjectileOnLine, springConstant);
        }

        /// <summary>
        /// creates an object of projectiles and springs for levels 2 and 3
        /// </summary>
        public void Level2()
        {
            int numberOfProjectiles = 27;
            const double totalMass = 5;
            const double springConstant = 60000;
            double eachMass = totalMass / numberOfProjectiles;
            const double cubeHeight = 1;
            int numberOfProjectileOnLine = (int)Math.Pow(numberOfProjectiles, ((double)1.0 / 3));
            double distanceBetweenProjectiles = cubeHeight / numberOfProjectileOnLine;
            Vector basePointPosition = new Vector(0, 0, 3);
            Vector zeroVector = new Vector(0, 0, 0);
            Projectile[,,] Projectiles = new Projectile[numberOfProjectileOnLine, numberOfProjectileOnLine, numberOfProjectileOnLine];

            for (int i = 0; i < numberOfProjectileOnLine; i++)
            {
                for (int j = 0; j < numberOfProjectileOnLine; j++)
                {
                    for (int k = 0; k < numberOfProjectileOnLine; k++)
                    {
                        double x = i * distanceBetweenProjectiles;
                        double y = j * distanceBetweenProjectiles;
                        double z = k * distanceBetweenProjectiles;
                        double θ = Math.PI/3;
                        
                        Projectiles[i, j, k] = new Projectile(basePointPosition + new Vector(x, y * Math.Cos(θ)  -z * Math.Sin(θ), y * Math.Sin(θ) + z * Math.Cos(θ)), zeroVector, eachMass);
                        ProjectilesList.Add(Projectiles[i, j, k]);
                        AddProjectile(Projectiles[i, j, k]);
                        
                    }
                }
            }

            addConnectors(Projectiles, numberOfProjectileOnLine, springConstant);




        }

        /// <summary>
        /// Adds connectors between projectiles
        /// </summary>
        public void addConnectors(Projectile[,,] Projectiles, double numberOfProjectileOnLine, double springConstant) {
            for (int i = 0; i < numberOfProjectileOnLine; i++)
            {
                for (int j = 0; j < numberOfProjectileOnLine; j++)
                {
                    for (int k = 0; k < numberOfProjectileOnLine; k++)
                    {

                        if (i != 0)
                        {
                            AddConnector(Projectiles[i - 1, j, k], Projectiles[i, j, k], springConstant);
                        }
                        if (j != 0)
                        {
                            AddConnector(Projectiles[i, j - 1, k], Projectiles[i, j, k], springConstant);
                        }
                        if (k != 0)
                        {
                            AddConnector(Projectiles[i, j, k - 1], Projectiles[i, j, k], springConstant);
                        }
                        if (k != 0 && j != 0)
                        {
                            AddConnector(Projectiles[i, j - 1, k - 1], Projectiles[i, j, k], springConstant);
                        }
                        if (k != 0 && j != 0 && i != 0)
                        {
                            AddConnector(Projectiles[i - 1, j - 1, k - 1], Projectiles[i, j, k], springConstant);
                        }
                        if (k < numberOfProjectileOnLine - 1 && j != 0)
                        {
                            AddConnector(Projectiles[i, j - 1, k + 1], Projectiles[i, j, k], springConstant);
                        }
                        if (k != 0 && i != 0)
                        {
                            AddConnector(Projectiles[i - 1, j, k - 1], Projectiles[i, j, k], springConstant);
                        }
                        if (k < numberOfProjectileOnLine - 1 && i != 0)
                        {
                            AddConnector(Projectiles[i - 1, j, k + 1], Projectiles[i, j, k], springConstant);
                        }
                        if (i != 0 && j != 0)
                        {
                            AddConnector(Projectiles[i - 1, j - 1, k], Projectiles[i, j, k], springConstant);
                        }
                        if (i != 0 && j < numberOfProjectileOnLine - 1 && k < numberOfProjectileOnLine - 1)
                        {
                            AddConnector(Projectiles[i - 1, j + 1, k + 1], Projectiles[i, j, k], springConstant);
                        }
                        if (i < numberOfProjectileOnLine - 1 && j != 0 && k < numberOfProjectileOnLine - 1)
                        {
                            AddConnector(Projectiles[i + 1, j - 1, k + 1], Projectiles[i, j, k], springConstant);
                        }
                        if (i < numberOfProjectileOnLine - 1 && j < numberOfProjectileOnLine - 1 && k != 0)
                        {
                            AddConnector(Projectiles[i + 1, j + 1, k - 1], Projectiles[i, j, k], springConstant);
                        }
                        if (i != 0 && j < numberOfProjectileOnLine - 1)
                        {
                            AddConnector(Projectiles[i - 1, j + 1, k], Projectiles[i, j, k], springConstant);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Returns the center of mass of the object
        /// </summary>
        public static Vector CenterOfMass() {
            Vector sumPositionMass = new Vector(0,0,0);
            double sumMass = 0;
            foreach(var projectile in ProjectilesList)
            {
                sumPositionMass += projectile.Position*projectile.Mass;
                sumMass += projectile.Mass;
            }
            return sumPositionMass / sumMass;

        }
    }
}
