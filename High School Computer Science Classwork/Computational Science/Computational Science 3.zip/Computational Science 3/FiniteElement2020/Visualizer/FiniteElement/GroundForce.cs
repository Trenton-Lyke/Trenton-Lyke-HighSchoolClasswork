﻿using DongUtility;
using FiniteElement;
using System;
using System.Collections.Generic;
using System.Text;

namespace Visualizer.FiniteElement
{
    class GroundForce : GlobalForce
    {
        private double coefficientOfFriction = 1;
        private Vector finalPosition = Vector.NullVector();
        private KinematicsEngine engine;

        private Vector forceLastTime = Vector.NullVector();
        private double formerTime = 0;

        public GroundForce(KinematicsEngine engine) :
            base(engine)
        {
            this.engine = engine;
        }

        /// <summary>
        /// The condition that must be met for the force to "turn on"
        /// Otherwise, nothing happens
        /// </summary>
        protected bool ConditionMet(Projectile projectile)
        {
            return projectile.Position.Z <= 0;
        }

        override protected Vector GetForce(Projectile projectile)
        {
            Vector response = Vector.NullVector();

            if (engine.Time > 0 && ConditionMet(projectile))
            {
                if (projectile.Velocity.Z < 0)
                    projectile.Velocity = new Vector(projectile.Velocity.X, projectile.Velocity.Y, -projectile.Velocity.Z);
            }

            //adds a frictional force between the ground an the projectile if the projectile
            //has velocity parallel to the ground 
            if (engine.Time > 0 && ConditionMet(projectile))
            {
                double dt = .0005;
                double normalForce= Math.Abs(2 * projectile.Velocity.Z / dt)*projectile.Mass;
                //The X and Y components of the velocity would sometime be extremely small non zero numbers so to account for this
                //I use velocityRoundingError to ensure that the X and Y direction velocities are above a certain threshold so before
                //the frictional force comes into play
                double velocityRoundingError = .1;
                double frictionalAccelerationX = 0;
                double frictionalAccelerationY = 0;
                if (Math.Abs(projectile.Velocity.X)> velocityRoundingError) {
                    frictionalAccelerationX = -Math.Sign(projectile.Velocity.X) * coefficientOfFriction * normalForce/ projectile.Mass;
                }
                if (Math.Abs(projectile.Velocity.Y) > velocityRoundingError)
                {
                    frictionalAccelerationY = -Math.Sign(projectile.Velocity.Y) * coefficientOfFriction * normalForce/ projectile.Mass;
                }
                Console.WriteLine(frictionalAccelerationY);
                
                projectile.Velocity = new Vector(projectile.Velocity.X + frictionalAccelerationX*dt, projectile.Velocity.Y + frictionalAccelerationY*dt, projectile.Velocity.Z);

            }

            formerTime = engine.Time;
            forceLastTime = response;
            return response;
        }
    }
}
