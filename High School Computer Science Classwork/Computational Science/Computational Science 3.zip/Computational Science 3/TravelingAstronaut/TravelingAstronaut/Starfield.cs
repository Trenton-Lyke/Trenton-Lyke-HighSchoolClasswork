﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TravelingAstronaut
{

    /// <summary>
    /// A class to store the positions of stars
    /// </summary>
    public class Starfield
    {
        //object for locking the distance dictionary
        private readonly object distanceDictionaryLocker = new object();
        //dictionary for storing distances
        private Dictionary<string, double> distanceDictionary;
        
        public Starfield(List<Vector> points)
        {
            Points = points;
            distanceDictionary = new Dictionary<string, double>();
        }

        //adds entry to dictionary within a lock to avoid corrupting the dictionary
        public void addDistanceToDictionary(string key, double distance) {
            lock (distanceDictionaryLocker) {
                if (!distanceDictionary.ContainsKey(key))
                {
                    distanceDictionary.Add(key, distance);
                }
            }
        }

        //adds 2 entries to dictionary within a lock to avoid corrupting the dictionary
        public void addDistanceToDictionary(string key1, string key2, double distance)
        {
            lock (distanceDictionaryLocker)
            {
                if (!distanceDictionary.ContainsKey(key1))
                {
                    distanceDictionary.Add(key1, distance);
                }
                if (!distanceDictionary.ContainsKey(key1))
                {
                    distanceDictionary.Add(key2, distance);
                }
                Console.WriteLine("adding distance on thread: " + Thread.CurrentThread.Name);
            }
        }

        //checks if the distance was already calculated and stored in a dictionary under a lock so that there are no errors
        public bool alreadyCalculatedDistance(string key)
        {
            lock (distanceDictionaryLocker)
            {
                return distanceDictionary.ContainsKey(key);
            }

        }

        //gets a distance from the dictionary
        public double getDistanceFromDictionary(string key) {
            return distanceDictionary[key];
        }

        public List<Vector> Points { get; }
    }
}
