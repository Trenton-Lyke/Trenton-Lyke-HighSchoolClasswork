﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TravelingAstronaut
{
    class BestPathFinderAlgorithm
    {
        //instance variables
        public Random ramdomGenerator = new Random();
        public Starfield starfield { get; private set; }


        public int lastStaticIndex { get; private set; }
        public int[] points { get; private set; }
        public int[] dynamicPoints { get; private set; }
        public Path bestPath { get; private set; }
        public double minValue { get; private set; }
        public int decisionSize { get; private set; }
        public int counter { get; private set; }
        public bool original { get; private set; }

        //initizializes instance variables
        public BestPathFinderAlgorithm(Starfield starfield, int[] points, int lastStaticIndex,  bool original)
        {
            this.starfield = starfield;
            this.points = points;
            this.original = original;
            this.lastStaticIndex = lastStaticIndex;
            this.decisionSize = decisionSize;
            minValue = int.MaxValue;
            bestPath = null;
            counter = 0;
            UpdateDynamicPoints(points, lastStaticIndex);
        }

        //gets the updated dynamic points based on the last static index
        private void UpdateDynamicPoints(int[] points, int lastStaticIndex)
        {
            int numberOfDynamicPoints = points.Length - (lastStaticIndex + 1);
            if (numberOfDynamicPoints != 0)
            {
                dynamicPoints = new int[numberOfDynamicPoints];
                for (int i = lastStaticIndex + 1; i < points.Length; i++)
                {
                    dynamicPoints[i - (lastStaticIndex + 1)] = points[i];
                }
            }
            else
            {
                dynamicPoints = null;
            }
        }

        //finds the best path using a greedy algorithm
        public void Run()
        {
            if (original) {
                RunOriginal();
            }
            else
            {
                RunProgressive();
            }



        }

        //finds the best path using a greedy algorithm
        private void RunProgressive()
        {
            for (; lastStaticIndex < points.Length - 1; lastStaticIndex++)
            {
                UpdateDynamicPoints(points, lastStaticIndex);
                double minDistance = double.MaxValue;
                int bestIndex = -1;
                for (int i = 0; i < dynamicPoints.Length; i++)
                {

                    double length = Distance(new int[] { points[lastStaticIndex], dynamicPoints[i] });
                    if (length < minDistance)
                    {
                        minDistance = length;
                        bestIndex = i;
                    }

                }
                int[] newPoints = GetStaticPoints();
                newPoints[lastStaticIndex + 1] = dynamicPoints[bestIndex];
                AddRemainingDymanicPoints(bestIndex, newPoints);
                for (int i = 0; i < points.Length; i++)
                {
                    points[i] = newPoints[i];
                }

            }
            bestPath = new Path(points);
            minValue = bestPath.TotalDistance(starfield);
            ++counter;
        }

        //adds all the remaining dynamic points to an array of new points
        private void AddRemainingDymanicPoints(int bestIndex, int[] newPoints)
        {
            int k = 0;
            for (int j = 0; j < dynamicPoints.Length; j++)
            {
                if (bestIndex != j)
                {
                    newPoints[lastStaticIndex + 2 + k] = dynamicPoints[j];
                    k++;
                }
            }
        }

        //gets the distance between two points
        private double Distance(int[] twoPoints)
        {
            
            return (new Path(twoPoints)).Distance(twoPoints[0], twoPoints[1], starfield);
        }

        //runs a greedy algorithm at each possible starting point on seperate threads in order to 
        //find the best path then joins all the threads together and finds the best path out of all the greedy algorithms ran
        private void RunOriginal()
        {
            Thread[] threads = new Thread[points.Length];
            BestPathFinderAlgorithm[] bestPathFinderAlgorithms = new BestPathFinderAlgorithm[points.Length];
            for (int i = 0; i < points.Length; i++)
            {
                int k = 0;
                int[] newPoints = new int[points.Length];
                newPoints[0] = points[i];
                for (int j = 0; j < points.Length; j++)
                {
                    if (i != j)
                    {
                        newPoints[k + 1] = points[j];
                        k++;
                    }

                }
                bestPathFinderAlgorithms[i] = new BestPathFinderAlgorithm(starfield, newPoints, 0, false);
                threads[i] = new Thread(bestPathFinderAlgorithms[i].Run);
                threads[i].Name = ""+ ramdomGenerator.NextDouble();
                threads[i].Start();
            }
            joinThreads(threads);
            foreach (BestPathFinderAlgorithm bestPathFinderAlgorithm in bestPathFinderAlgorithms)
            {
                if (bestPathFinderAlgorithm.minValue < minValue)
                {
                    minValue = bestPathFinderAlgorithm.minValue;
                    bestPath = bestPathFinderAlgorithm.bestPath;
                }
                counter += bestPathFinderAlgorithm.counter;
            }
        }

        //joins threads
        private static void joinThreads(Thread[] threads)
        {
            foreach (Thread thread in threads)
            {
                thread.Join();
            }
        }

        //gets the static points based on the last static index and returns the array
        private int[] GetStaticPoints()
        {
            int[] newPoints = new int[points.Length];
            for (int i = 0; i <= lastStaticIndex; i++)
            {
                newPoints[i] = points[i];
            }
            return newPoints;
        }
    }
}
