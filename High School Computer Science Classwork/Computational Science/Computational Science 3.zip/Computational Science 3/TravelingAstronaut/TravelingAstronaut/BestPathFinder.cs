﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TravelingAstronaut
{
    //class that can find the best path on threads that branch off the main thread
    class BestPathFinder
    {
        //instance variables
        public Starfield starfield { get; private set; }
        public List<int[]> pointsList { get; private set; }
        public int[] startPoints { get; private set; }

        public Path bestPath { get; private set; }
        public double minValue { get; private set; }
        public int maxNumberOfTries { get; private set; }
        public int counter { get; private set; }

        //initializes instance variables for Run() method
        public BestPathFinder(Starfield starfield)
        {
            this.starfield = starfield;
            minValue = int.MaxValue;
            pointsList = new List<int[]>();

        }
        //initializes instance variables for RunAlternative() method
        public BestPathFinder(Starfield starfield, int maxNumberOfTries)
        {
            this.starfield = starfield;
            minValue = int.MaxValue;
            pointsList = new List<int[]>();
            this.maxNumberOfTries = maxNumberOfTries;

        }
        //adds points to the array for the Run() method to go through and find the best path
        public void AddPoints(int[] points)
        {
            pointsList.Add(points);
        }

        //sets startPoints for the RunAlternative() method to start at and find the best path
        public void setStartPoints(int[] points) {
            startPoints = points;
        }

        //finds the best path from a list of points
        public void Run()
        {
            foreach (int[] points in pointsList)
            {
                Path path = new Path(points);
                double length = path.TotalDistance(starfield);
                if (length < minValue)
                {
                    minValue = length;
                    bestPath = path;
                }
                ++counter;
            }
        }

        //finds the best path from a set of startPoints and a max number of tries
        public void RunAlternative() {
            do
            {
                var path = new Path(startPoints);
                double length = path.TotalDistance(starfield);
                if (length < minValue)
                {
                    minValue = length;
                    bestPath = path;
                }
                ++counter;
            } while (DongUtility.UtilityFunctions.NextPermutation(startPoints) && counter<maxNumberOfTries);
        }
        
    }
}
