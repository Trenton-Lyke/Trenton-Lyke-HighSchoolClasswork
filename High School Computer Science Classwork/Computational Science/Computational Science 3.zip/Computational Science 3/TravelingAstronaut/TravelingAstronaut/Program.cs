﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace TravelingAstronaut
{
    class Program
    {
        static void Main(string[] args)
        {
            const int myStudentID = 120132;
            const int nPoints = 100;


            var generator = new StarfieldGenerator(myStudentID);

            // Create the starfield
            var starfield = generator.GeneratePoints(nPoints);
            Stopwatch watch;
            int[] points;
            double minValue;
            Path bestPath;
            int counter;


            //levels 1 & 2
            //Console.WriteLine("Level 1 And 2");
            //init(nPoints, out watch, out points, out minValue, out bestPath, out counter);
            //Level1And2(starfield, points, out minValue, out bestPath, out counter, 10);
            //Display(watch, minValue, bestPath, counter);

            //Alternative method for levels 1 & 2
            //alternative is faster and scales better because it doesn't have to use a bulky array
            //Console.WriteLine("Level 1 And 2 Alternative");
            //init(nPoints, out watch, out points, out minValue, out bestPath, out counter);
            //Level1And2Alternative(starfield, points, out minValue, out bestPath, out counter, 10);
            //Display(watch, minValue, bestPath, counter);

            //level 3
            //Console.WriteLine("Level 3");
            //init(nPoints, out watch, out points, out minValue, out bestPath, out counter);
            //Level3(starfield, points, out minValue, out bestPath, out counter);
            //Display(watch, minValue, bestPath, counter);

            //level 4
            Console.WriteLine("Level 4");
            init(nPoints, out watch, out points, out minValue, out bestPath, out counter);
            Level4(starfield, points, out minValue, out bestPath, out counter);
            Display(watch, minValue, bestPath, counter);

            Console.ReadKey();
        }

        //initializes variables and restars stop watch
        private static void init(int nPoints, out Stopwatch watch, out int[] points, out double minValue, out Path bestPath, out int counter)
        {
            // Set up timer
            watch = Stopwatch.StartNew();

            // Create an array in order
            points = new int[nPoints];
            for (int i = 0; i < nPoints; ++i)
                points[i] = i;



            minValue = double.MaxValue;
            bestPath = null;
            counter = 0;
        }

        //displays the results 
        private static void Display(Stopwatch watch, double minValue, Path bestPath, int counter)
        {
            // Get time on timer
            var time = watch.ElapsedMilliseconds;

            Console.WriteLine("Minimum length: " + minValue);
            Console.WriteLine("Minimum path: " + bestPath);
            Console.WriteLine(counter + " tries");
            Console.WriteLine("Time elapsed: " + time / 1000.0 + " s");
            
        }

        //finds the best path using the methods specified by level 1 and 2
        private static void Level1And2(Starfield starfield, int[] points, out double minValue, out Path bestPath, out int counter, int numberOfThreads=10)
        {
            minValue = double.MaxValue;
            counter = 0;
            bestPath = null;
            List<Thread> threads = new List<Thread>();
            List<BestPathFinder> bestPathFinders = new List<BestPathFinder>();
            for (int i = 0; i < numberOfThreads; i++)
            {
                bestPathFinders.Add(new BestPathFinder(starfield));
            }
            // Loop over all possible choices

            int threadNumber = 0;
            do
            {
                int[] newPoints = new int[points.Length];
                for(int i = 0; i < points.Length; i++) {
                    newPoints[i] = points[i];
                }
                bestPathFinders[threadNumber].AddPoints(newPoints);
                threadNumber = (threadNumber + 1) % numberOfThreads;
            } while (DongUtility.UtilityFunctions.NextPermutation(points));

            startThreads(threads, bestPathFinders, numberOfThreads);
            joinThreads(threads);
            foreach (BestPathFinder bestPathFinder in bestPathFinders)
            {
                if (bestPathFinder.minValue < minValue)
                {
                    minValue = bestPathFinder.minValue;
                    bestPath = bestPathFinder.bestPath;
                }
                counter += bestPathFinder.counter;
            }
        }
        //factorial function
        private static int factorial(int num) {
            if (num == 1)
            {
                return 1;
            }
            else {
                return num * factorial(num - 1);
            }
        }

        //finds the best path using another version of the methods specified by level 1 and 2
        private static void Level1And2Alternative(Starfield starfield, int[] points, out double minValue, out Path bestPath, out int counter, int numberOfThreads = 10)
        {
            int totalNumberOfTries = factorial(points.Length);
            int numberOfTriesPerNormalThread = totalNumberOfTries / numberOfThreads;
            bool decrementNumberOfThreads = false;
            while (numberOfTriesPerNormalThread == 0) {
                numberOfThreads--;
                numberOfTriesPerNormalThread = totalNumberOfTries / numberOfThreads;
                decrementNumberOfThreads = true;
            }
            int additionalTriesForLastThread = totalNumberOfTries % numberOfThreads;
            bool hasAdditionalTriesForLastThread = additionalTriesForLastThread != 0;
            bool finalThreadIsOnlyForAdditionalTries = decrementNumberOfThreads && hasAdditionalTriesForLastThread;
            if (finalThreadIsOnlyForAdditionalTries) {
                numberOfThreads++;
            }
            minValue = double.MaxValue;
            counter = 0;
            bestPath = null;
            List<Thread> threads = new List<Thread>();
            List<BestPathFinder> bestPathFinders = new List<BestPathFinder>();
            for (int i = 0; i < numberOfThreads; i++)
            {
                if (i != numberOfThreads - 1)
                {
                    bestPathFinders.Add(new BestPathFinder(starfield, numberOfTriesPerNormalThread));
                }
                else {
                    if (finalThreadIsOnlyForAdditionalTries)
                    {
                        bestPathFinders.Add(new BestPathFinder(starfield, additionalTriesForLastThread));
                    }
                    else {
                        bestPathFinders.Add(new BestPathFinder(starfield, numberOfTriesPerNormalThread+ additionalTriesForLastThread));
                    }
                }
            }
            // Loop over all possible choices

            int threadNumber = 0;
            int count = 0;
            do
            {
                if (count % numberOfTriesPerNormalThread==0 ) {
                    int[] newPoints = new int[points.Length];
                    for (int i = 0; i < points.Length; i++)
                    {
                        newPoints[i] = points[i];
                    }
                    if (threadNumber<bestPathFinders.Count) {
                        bestPathFinders[threadNumber].setStartPoints(newPoints);
                    }
                    threadNumber++;
                }
                
                

                count++;

            } while (DongUtility.UtilityFunctions.NextPermutation(points));

            startThreadsAlternative(threads, bestPathFinders, numberOfThreads);
            joinThreads(threads);
            foreach (BestPathFinder bestPathFinder in bestPathFinders)
            {
                if (bestPathFinder.minValue < minValue)
                {
                    minValue = bestPathFinder.minValue;
                    bestPath = bestPathFinder.bestPath;
                }
                counter += bestPathFinder.counter;
            }
        }

        //joins all the threads
        private static void joinThreads(List<Thread> threads)
        {
            foreach (Thread thread in threads)
            {
                thread.Join();
            }
        }

        //finds the best path using the methods specified by level 3
        private static void Level3(Starfield starfield, int[] points, out double minValue, out Path bestPath, out int counter)
        {

            BestPathFinderRecursive bestPathFinderRecursive = new BestPathFinderRecursive(starfield, -1, points);
            bestPathFinderRecursive.Run();
            minValue = bestPathFinderRecursive.minValue;
            bestPath = bestPathFinderRecursive.bestPath;
            counter = bestPathFinderRecursive.counter;
            
        }

        //finds the best path using the methods specified by level 4
        private static void Level4(Starfield starfield, int[] points, out double minValue, out Path bestPath, out int counter)
        {

            BestPathFinderAlgorithm bestPathFinderRecursive = new BestPathFinderAlgorithm(starfield, points, -1, true);
            bestPathFinderRecursive.Run();
            minValue = bestPathFinderRecursive.minValue;
            bestPath = bestPathFinderRecursive.bestPath;
            counter = bestPathFinderRecursive.counter;

        }

        //starts all the threads for levels 1 and 2
        private static void startThreads(List<Thread> threads, List<BestPathFinder> bestPathFinders, int numberOfThreads)
        {
            for (int i = 0; i < numberOfThreads; i++)
            {
                threads.Add(new Thread(bestPathFinders[i].Run));
                threads[i].Name = "Thread " + i;
                threads[i].Start();
            }
        }

        //starts all the threads the alternative for levels 1 and 2
        private static void startThreadsAlternative(List<Thread> threads, List<BestPathFinder> bestPathFinders, int numberOfThreads)
        {
            for (int i = 0; i < numberOfThreads; i++)
            {
                threads.Add(new Thread(bestPathFinders[i].RunAlternative));
                threads[i].Name = "Thread " + i;
                threads[i].Start();
            }
        }
    }
}
