﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TravelingAstronaut
{
    class BestPathFinderRecursive
    {
        //instance variables
        public Random ramdomGenerator = new Random();
        public Starfield starfield { get; private set; }
        

        public int lastStaticIndex { get; private set; }
        public int[] points { get; private set; }
        public int[] dynamicPoints { get; private set; }
        public Path bestPath { get; private set; }
        public double minValue { get; private set; }
        public int counter { get; private set; }

        //initializes instance variables
        public BestPathFinderRecursive(Starfield starfield, int lastStaticIndex, int[] points) {
            this.starfield = starfield;
            this.lastStaticIndex = lastStaticIndex;
            this.points = points;
            minValue = int.MaxValue;
            bestPath = null;
            int numberOfDynamicPoints = points.Length - (lastStaticIndex + 1);
            if (numberOfDynamicPoints != 0)
            {
                dynamicPoints = new int[numberOfDynamicPoints];
                for (int i = lastStaticIndex + 1; i < points.Length; i++)
                {
                    dynamicPoints[i-(lastStaticIndex + 1)] = points[i];
                }
            }
            else {
                dynamicPoints = null;
            }

        }

        //finds the best path recursively on seperate threads
        public void Run() {
            if (dynamicPoints == null) {
                bestPath = new Path(points);
                minValue = bestPath.TotalDistance(starfield);
                counter = 1;
                Console.WriteLine(Thread.CurrentThread.Name);
            }
            else
            {
                Thread[] threads = new Thread[dynamicPoints.Length];
                BestPathFinderRecursive[] bestPathFindersRecursives = new BestPathFinderRecursive[dynamicPoints.Length];
                startThreads(threads, bestPathFindersRecursives);
                joinThreads(threads);
                foreach (BestPathFinderRecursive bestPathFinderRecursive in bestPathFindersRecursives)
                {
                    if (bestPathFinderRecursive.minValue < minValue)
                    {
                        minValue = bestPathFinderRecursive.minValue;
                        bestPath = bestPathFinderRecursive.bestPath;
                    }
                    counter += bestPathFinderRecursive.counter;
                }
            }
        }
        
        //joins all the treads on the current recursive level
        public static void joinThreads(Thread[] threads)
        {
            foreach (Thread thread in threads)
            {
                thread.Join();
            }
        }

        //starts all threads
        private void startThreads(Thread[] threads, BestPathFinderRecursive[] bestPathFindersRecursives)
        {
            for (int i = 0; i < dynamicPoints.Length; i++)
            {
                int[] newPoints = GetStaticPoints();
                newPoints[lastStaticIndex + 1] = dynamicPoints[i];
                int k = 0;
                for (int j = 0; j < dynamicPoints.Length; j++)
                {
                    if (i != j)
                    {
                        newPoints[lastStaticIndex + 2 + k] = dynamicPoints[j];
                        k++;
                    }
                }
                bestPathFindersRecursives[i] = new BestPathFinderRecursive(starfield, lastStaticIndex + 1, newPoints);
                threads[i] = new Thread(bestPathFindersRecursives[i].Run);
                threads[i].Name = "Thread " + ramdomGenerator.NextDouble();
                threads[i].Start();
            }
        }

        //gets the static points based on the last static index and returns the array
        private int[] GetStaticPoints()
        {
            int[] newPoints = new int[points.Length];
            for (int i = 0; i <= lastStaticIndex; i++)
            {
                newPoints[i] = points[i];
            }
            return newPoints;
        }
    }
}
