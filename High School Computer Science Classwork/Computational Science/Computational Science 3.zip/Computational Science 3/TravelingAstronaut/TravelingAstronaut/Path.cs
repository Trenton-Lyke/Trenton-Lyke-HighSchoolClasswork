﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Text;

namespace TravelingAstronaut
{
    /// <summary>
    /// A simple path that contains a set of indices in a fixed order
    /// </summary>
    public class Path
    {
        
        /// <summary>
        /// The points in the path, as indices to the Starfield's Points list.
        /// </summary>
        public List<int> Points { get; } = new List<int>();

        public Path()
        { }

        public Path(params int[] points)
        {
            Points.AddRange(points);
        }

        public override string ToString()
        {
            string response = "{ ";
            foreach (var point in Points)
            {
                response += (point + ", ");
            }

            // truncate final comma
            response = response.Substring(0, response.Length - 2);
            response += " }";

            return response;
        }

        /// <summary>
        /// The total length of the path
        /// </summary>
        /// <param name="starfield">Needed because the path stores only integers, not vectors</param>
        public double TotalDistance(Starfield starfield)
        {
            double total = 0;

            for (int i = 0; i < Points.Count - 1; ++i)
            {


                string key1 = "" + Points[i] + "to" + Points[i + 1];
                string key2 = "" + Points[i + 1] + "to" + Points[i];

                if (starfield.alreadyCalculatedDistance(key1))
                {
                    total += starfield.getDistanceFromDictionary(key1);
                }
                else
                {
                    double distance = Distance(Points[i], Points[i + 1], starfield);
                    starfield.addDistanceToDictionary(key1, key2, distance);
                    total += distance;
                }






            }

            return total;
        }

        /// <summary>
        /// The distance between two points, given as indices into the Starfield's list
        /// </summary>
        public double Distance(int p1, int p2, Starfield starfield)
        {
            return Vector.Distance(starfield.Points[p1], starfield.Points[p2]);
        }
    }
}
