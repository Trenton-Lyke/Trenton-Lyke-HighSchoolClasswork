﻿namespace Visualizer
{
    class Driver
    {

        static internal void Run()
        {
            ChemicalReactions.ChemicalDriver.Run();
        }



    }

}
