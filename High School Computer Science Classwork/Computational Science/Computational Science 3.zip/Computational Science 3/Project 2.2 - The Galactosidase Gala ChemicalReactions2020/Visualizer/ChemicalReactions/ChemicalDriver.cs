﻿using DongUtility;
using GraphControl;
using MotionVisualizerControl;
using System.Collections.Generic;
using System.Windows.Media;
using Thermodynamics;
using static WPFUtility.UtilityFunctions;

namespace Visualizer.ChemicalReactions
{
    class ChemicalDriver
    {
        static internal void Run()
        {
            const double containerSize = 25;

            const double deltaTime = .01;
            const double temperature = 293.17;
            const double reactionRadius = 2;

            //change to MyReacting
            var container = new MyReactingParticleContainer(containerSize, reactionRadius);

            //kg per molecule
            //level 1
            //Level1(temperature, container);

            //level 2 
            //Level2And3(temperature, container);

            //Level 3
            //Level2And3(temperature, container, 200);

            //Level 4
            //Level4(temperature, container);

            //Project
            //Project(temperature, container);

            //Project part 2
            Project2(temperature, container);

            var visualization = new ChemicalVisualization(container)
            {
                BoxColor = Colors.IndianRed
            };

            var viz = new MotionVisualizer(visualization)
            {
                TimeIncrement = deltaTime,
                TimeScale = 100,
                SlowDraw = true
            };

            Timeline.MaximumPoints = 3000;

            var chemicalGraph = new ChemicalGraph(container, visualization);
            viz.AddGraph(chemicalGraph, chemicalGraph.Functions);

            viz.AutoCamera = true;
            viz.AutoCamera = false;
            viz.Show();
        }

        //sets up container for level1
        private static void Level1(double temperature, MyReactingParticleContainer container)
        {
            const double massNH3 = 2.82789e-26;
            const double massHCl = 6.1e-26;
            const double massNH4Cl = 8.9e-26;
            Color colorNH3 = Colors.NavajoWhite;
            Color colorHCl = Colors.AntiqueWhite;
            Color colorNH4Cl = Colors.PaleGoldenrod;

            //add particle info object here for adding new particle (*make sure the name is right)
            container.Dictionary.AddParticle(new ParticleInfo("NH3", massNH3, ConvertColor(colorNH3)));
            container.Dictionary.AddParticle(new ParticleInfo("HCl", massHCl, ConvertColor(colorHCl)));
            container.Dictionary.AddParticle(new ParticleInfo("NH4Cl", massNH4Cl, ConvertColor(colorNH4Cl)));

            var ammoniaGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["NH3"]);
            var hydrochloricGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["HCl"]);

            ////add particles heare with the number of particles
            const int nAmmonia = 500;
            const int nHydrochloric = 500;
            container.AddRandomParticles(ammoniaGenerator, nAmmonia, "NH3");
            container.AddRandomParticles(hydrochloricGenerator, nHydrochloric, "HCl");
        }

        //sets up container for levels 2 and 3
        private static void Level2And3(double temperature, MyReactingParticleContainer container, int numberOfCatalyst=0)
        {
            const double massCO2 = 7.3080323e-26;
            const double massH2O = 2.9915076e-26;
            const double massHCO3 = 1.0132078e-25;
            const double massH3O = 3.1588766e-26;
            const double massCA = 5.0201416e-23;
            Color colorCO2 = Colors.Yellow;
            Color colorH2O = Colors.Blue;
            Color colorHCO3 = Colors.Purple;
            Color colorH3O = Colors.Orange;
            Color colorCA = Colors.HotPink;



            container.Dictionary.AddParticle(new ParticleInfo("CO2", massCO2, ConvertColor(colorCO2)));
            container.Dictionary.AddParticle(new ParticleInfo("H2O", massH2O, ConvertColor(colorH2O)));
            container.Dictionary.AddParticle(new ParticleInfo("HCO3", massHCO3, ConvertColor(colorHCO3)));
            container.Dictionary.AddParticle(new ParticleInfo("H3O", massH3O, ConvertColor(colorH3O)));
            container.Dictionary.AddParticle(new ParticleInfo("CA", massCA, ConvertColor(colorCA)));

            var carbonDioxideGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["CO2"]);
            var waterGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["H2O"]);
            var bicarbonateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["HCO3"]);
            var hydroniumGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["H3O"]);
            var carbonicAnhydraseGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["CA"]);


            //add particles heare with the number of particles
            const int nCarbonDioxide = 500;
            const int nWater = 1000;
            const int nBicarbonate = 0;
            const int nHydronium = 0;
            int nCarbonicAnhydrase = numberOfCatalyst;
            container.AddRandomParticles(carbonDioxideGenerator, nCarbonDioxide, "CO2");
            container.AddRandomParticles(waterGenerator, nWater, "H2O");
            container.AddRandomParticles(bicarbonateGenerator, nBicarbonate, "HCO3");
            container.AddRandomParticles(hydroniumGenerator, nHydronium, "H3O");
            container.AddRandomParticles(carbonicAnhydraseGenerator, nCarbonicAnhydrase, "CA");
        }

        //sets up container for level 4
        private static void Level4(double temperature, MyReactingParticleContainer container)
        {
            //compound masses
            //Oxaloacetate
            const double massC4H4O5 = 2.1930739e-25;
            //Acetyl-CoA
            const double massC23H38N7O17P3S = 1.3443226e-24;
            //HSCoA
            const double massC21H36N7O16P3S = 1.2745218e-24;
            //citrate
            const double massC6H8O7 = 3.190294e-25;
            //water
            const double massH2O = 2.9915076e-26;
            //cis-aconitate
            const double massC6H6O6 = 2.8911645e-25;
            //isocitrate
            const double massIC6H8O7 = 3.1902857e-25;
            //NAD
            const double massNAD = 1.1016514e-24;
            //NADH
            const double massNADH = 1.1016514e-24;
            //CO2
            const double massCO2 = 7.3080323e-26;
            //H
            const double massH = 1.6735577e-27;
            //alpha-Ketoglutaric acid
            const double massC5H6O5 = 2.4262136e-25;
            //Succinyl CoA
            const double massC25H40N7O19P3S = 1.4406837e-24;
            //GDP
            const double massGDP = 7.3595173e-25;
            //Pi
            const double massPi = 1.5770305e-25;
            //GTP
            const double massGTP = 8.6876081e-25;
            //Succinate
            const double massC4H6O4 = 1.9609305e-25;
            //FAD
            const double massFAD = 1.3044359e-24;
            //FADH2
            const double massFADH2 = 1.3044359e-24;
            //Fumerate
            const double massC4H4O4 = 1.9273877e-25;
            //Malate
            const double massC4H6O5 = 2.2265736e-25;

            //compound colors
            //Oxaloacetate
            Color colorC4H4O5 = Colors.Red;
            //Acetyl-CoA
            Color colorC23H38N7O17P3S = Colors.Blue;
            //HSCoA
            Color colorC21H36N7O16P3S = Colors.Yellow;
            //citrate
            Color colorC6H8O7 = Colors.Purple;
            //water
            Color colorH2O = Colors.Green;
            //cis-aconitate
            Color colorC6H6O6 = Colors.Orange;
            //isocitrate
            Color colorIC6H8O7 = Colors.Pink;
            //NAD
            Color colorNAD = Colors.GreenYellow;
            //NADH
            Color colorNADH = Colors.DeepSkyBlue;
            //CO2
            Color colorCO2 = Colors.LightSeaGreen;
            //H
            Color colorH = Colors.LightGray;
            //alpha-Ketoglutaric acid
            Color colorC5H6O5 = Colors.PaleVioletRed;
            //Succinyl CoA
            Color colorC25H40N7O19P3S = Colors.Aquamarine;
            //GDP
            Color colorGDP = Colors.Gold;
            //Pi
            Color colorPi = Colors.Silver;
            //GTP
            Color colorGTP = Colors.Crimson;
            //Succinate
            Color colorC4H6O4 = Colors.MintCream;
            //FAD
            Color colorFAD = Colors.Navy;
            //FADH2
            Color colorFADH2 = Colors.NavajoWhite;
            //Fumerate
            Color colorC4H4O4 = Colors.LemonChiffon;
            //Malate
            Color colorC4H6O5 = Colors.RosyBrown;

            //adds particle info to containers dictionary
            container.Dictionary.AddParticle(new ParticleInfo("C4H4O5", massC4H4O5, ConvertColor(colorC4H4O5)));
            container.Dictionary.AddParticle(new ParticleInfo("C23H38N7O17P3S", massC23H38N7O17P3S, ConvertColor(colorC23H38N7O17P3S)));
            container.Dictionary.AddParticle(new ParticleInfo("C21H36N7O16P3S", massC21H36N7O16P3S, ConvertColor(colorC21H36N7O16P3S)));
            container.Dictionary.AddParticle(new ParticleInfo("C6H8O7", massC6H8O7, ConvertColor(colorC6H8O7)));
            container.Dictionary.AddParticle(new ParticleInfo("H2O", massH2O, ConvertColor(colorH2O), Shapes.Shapes3D.Cylinder));
            container.Dictionary.AddParticle(new ParticleInfo("C6H6O6", massC6H6O6, ConvertColor(colorC6H6O6)));
            container.Dictionary.AddParticle(new ParticleInfo("IC6H8O7", massIC6H8O7, ConvertColor(colorIC6H8O7)));
            container.Dictionary.AddParticle(new ParticleInfo("NAD", massNAD, ConvertColor(colorNAD), Shapes.Shapes3D.Cube));
            container.Dictionary.AddParticle(new ParticleInfo("NADH", massNADH, ConvertColor(colorNADH)));
            container.Dictionary.AddParticle(new ParticleInfo("CO2", massCO2, ConvertColor(colorCO2)));
            container.Dictionary.AddParticle(new ParticleInfo("H", massH, ConvertColor(colorH)));
            container.Dictionary.AddParticle(new ParticleInfo("C5H6O5", massC5H6O5, ConvertColor(colorC5H6O5)));
            container.Dictionary.AddParticle(new ParticleInfo("C25H40N7O19P3S", massC25H40N7O19P3S, ConvertColor(colorC25H40N7O19P3S)));
            container.Dictionary.AddParticle(new ParticleInfo("GDP", massGDP, ConvertColor(colorGDP)));
            container.Dictionary.AddParticle(new ParticleInfo("Pi", massPi, ConvertColor(colorPi)));
            container.Dictionary.AddParticle(new ParticleInfo("GTP", massGTP, ConvertColor(colorGTP)));
            container.Dictionary.AddParticle(new ParticleInfo("C4H6O4", massC4H6O4, ConvertColor(colorC4H6O4)));
            container.Dictionary.AddParticle(new ParticleInfo("FAD", massFAD, ConvertColor(colorFAD)));
            container.Dictionary.AddParticle(new ParticleInfo("FADH2", massFADH2, ConvertColor(colorFADH2)));
            container.Dictionary.AddParticle(new ParticleInfo("C4H4O4", massC4H4O4, ConvertColor(colorC4H4O4)));
            container.Dictionary.AddParticle(new ParticleInfo("C4H6O5", massC4H6O5, ConvertColor(colorC4H6O5)));

            //creates compound generators
            var OxaloacetateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C4H4O5"]);
            var AcetylCoAGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C23H38N7O17P3S"]);
            var HSCoAGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C21H36N7O16P3S"]);
            var CitrateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C6H8O7"]);
            var WaterGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["H2O"]);
            var CisAconitateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C6H6O6"]);
            var IsocitrateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["IC6H8O7"]);
            var NADGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["NAD"]);
            var NADHGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["NADH"]);
            var CO2Generator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["CO2"]);
            var HGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["H"]);
            var AlphaKetoglutaricAcidGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C5H6O5"]);
            var SuccinylCoAGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C25H40N7O19P3S"]);
            var GDPGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["GDP"]);
            var PiGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["Pi"]);
            var GTPGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["GTP"]);
            var SuccinateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C4H6O4"]);
            var FADGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["FAD"]);
            var FADH2Generator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["FADH2"]);
            var FumerateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C4H4O4"]);
            var MalateGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["C4H6O5"]);

            //number of particles of compounds
            const int nOxaloacetate = 100;
            const int nAcetylCoA = 100;
            const int nHSCoA = 0;
            const int nCitrate = 0;
            const int nWater = 300;
            const int nCisAconitate = 0;
            const int nIsocitrate = 0;
            const int nNAD = 300;
            const int nNADH = 0;
            const int nCO2 = 0;
            const int nH = 0;
            const int nAlphaKetoglutaricAcid = 0;
            const int nSuccinylCoA = 0;
            const int nGDP = 100;
            const int nPi = 100;
            const int nGTP = 0;
            const int nSuccinate = 0;
            const int nFAD = 100;
            const int nFADH2 = 0;
            const int nFumerate = 0;
            const int nMalate = 0;

            //adds particles to container
            container.AddRandomParticles(OxaloacetateGenerator, nOxaloacetate, "C4H4O5");
            container.AddRandomParticles(AcetylCoAGenerator, nAcetylCoA, "C23H38N7O17P3S");
            container.AddRandomParticles(HSCoAGenerator, nHSCoA, "C21H36N7O16P3S");
            container.AddRandomParticles(CitrateGenerator, nCitrate, "C6H8O7");
            container.AddRandomParticles(WaterGenerator, nWater, "H2O");
            container.AddRandomParticles(CisAconitateGenerator, nCisAconitate, "C6H6O6");
            container.AddRandomParticles(IsocitrateGenerator, nIsocitrate, "IC6H8O7");
            container.AddRandomParticles(NADGenerator, nNAD, "NAD");
            container.AddRandomParticles(NADHGenerator, nNADH, "NADH");
            container.AddRandomParticles(CO2Generator, nCO2, "CO2");
            container.AddRandomParticles(HGenerator, nH, "H");
            container.AddRandomParticles(AlphaKetoglutaricAcidGenerator, nAlphaKetoglutaricAcid, "C5H6O5");
            container.AddRandomParticles(SuccinylCoAGenerator, nSuccinylCoA, "C25H40N7O19P3S");
            container.AddRandomParticles(GDPGenerator, nGDP, "GDP");
            container.AddRandomParticles(PiGenerator, nPi, "Pi");
            container.AddRandomParticles(GTPGenerator, nGTP, "GTP");
            container.AddRandomParticles(SuccinateGenerator, nSuccinate, "C4H6O4");
            container.AddRandomParticles(FADGenerator, nFAD, "FAD");
            container.AddRandomParticles(FADH2Generator, nFADH2, "FADH2");
            container.AddRandomParticles(FumerateGenerator, nFumerate, "C4H4O4");
            container.AddRandomParticles(MalateGenerator, nMalate, "C4H6O5");
        }

        private static void Project(double temperature, MyReactingParticleContainer container)
        {
            //compound masses
            //Lac operon
            const double massLAC = 2.5658649e-22;
            const double massRNAPolymerase = 7.9705873e-22;
            const double massBgal = 8.6348029e-22;
            const double massLACOperonRepressor = 2.5658649e-22;
            const double massInhibittedLAC = 5.1317298e-22;
            const double massLactose = 5.6840251e-25;
            const double massGlucose = 2.9915607e-25;
            const double massGalactose = 2.9915607e-25;
            const double massLactoseAndLACOperonRepressor = 2.5715489e-22;
            const double massCyclicAMP = 5.4665925e-25;
            const double massCAP = 3.9281711e-23;
            const double massPromoter = 3.982837e-23;
            const double massPromoterAndLAC = 2.9641486e-22;
            //const double mass_ = ;
            //const double mass_ = ;


            //compound colors
            //Lac operon
            Color colorLAC = Colors.Red;
            Color colorRNAPolymerase = Colors.Blue;
            Color colorBgal = Colors.Green;
            Color colorLACOperonRepressor = Colors.Gold;
            Color colorInhibittedLAC = Colors.Orange;
            Color colorLactose = Colors.HotPink;
            Color colorGlucose = Colors.Black;
            Color colorGalactose = Colors.Gray;
            Color colorLactoseAndLACOperonRepressor = Colors.Purple;
            Color colorCyclicAMP = Colors.Crimson;
            Color colorCAP = Colors.DarkCyan;
            Color colorPromoter = Colors.DarkGoldenrod;
            Color colorPromoterAndLAC = Colors.DarkViolet;
            //Color color_ = Colors;
            //Color color_ = Colors;


            //adds particle info to containers dictionary
            container.Dictionary.AddParticle(new ParticleInfo("LAC", massLAC, ConvertColor(colorLAC)));
            container.Dictionary.AddParticle(new ParticleInfo("RNAPolymerase", massRNAPolymerase, ConvertColor(colorRNAPolymerase)));
            container.Dictionary.AddParticle(new ParticleInfo("Bgal", massBgal, ConvertColor(colorBgal)));
            container.Dictionary.AddParticle(new ParticleInfo("LACOperonRepressor", massLACOperonRepressor, ConvertColor(colorLACOperonRepressor)));
            container.Dictionary.AddParticle(new ParticleInfo("InhibittedLAC", massInhibittedLAC, ConvertColor(colorInhibittedLAC)));
            container.Dictionary.AddParticle(new ParticleInfo("Lactose", massLactose, ConvertColor(colorLactose)));
            container.Dictionary.AddParticle(new ParticleInfo("Glucose", massGlucose, ConvertColor(colorGlucose)));
            container.Dictionary.AddParticle(new ParticleInfo("Galactose", massGalactose, ConvertColor(colorGalactose)));
            container.Dictionary.AddParticle(new ParticleInfo("LactoseAndLACOperonRepressor", massLactoseAndLACOperonRepressor, ConvertColor(colorLactoseAndLACOperonRepressor)));
            container.Dictionary.AddParticle(new ParticleInfo("CyclicAMP", massCyclicAMP, ConvertColor(colorCyclicAMP)));
            container.Dictionary.AddParticle(new ParticleInfo("CAP", massCAP, ConvertColor(colorCAP)));
            container.Dictionary.AddParticle(new ParticleInfo("Promoter", massPromoter, ConvertColor(colorPromoter)));
            container.Dictionary.AddParticle(new ParticleInfo("PromoterAndLAC", massPromoterAndLAC, ConvertColor(colorPromoterAndLAC)));
            //container.Dictionary.AddParticle(new ParticleInfo("_", mass_, ConvertColor(color_)));
            //container.Dictionary.AddParticle(new ParticleInfo("_", mass_, ConvertColor(color_)));



            //creates compound generators
            var LACGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["LAC"]);
            var RNAPolymeraseGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["RNAPolymerase"]);
            var BgalGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["Bgal"]);
            var LACOperonRepressorGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["LACOperonRepressor"]);
            var InhibittedLACGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["InhibittedLAC"]);
            var LactoseGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["Lactose"]);
            var GlucoseGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["Glucose"]);
            var GalactoseGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["Galactose"]);
            var LactoseAndLACOperonRepressorGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["LactoseAndLACOperonRepressor"]);
            var CyclicAMPGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["CyclicAMP"]);
            var CAPGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["CAP"]);
            var PromoterGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["Promoter"]);
            var PromoterAndLACGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["PromoterAndLAC"]);
            //var _Generator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["_"]);
            //var _Generator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["_"]);

            //number of particles of compounds
            const int nLAC = 200;
            const int nRNAPolymerase = 200;
            const int nBgal = 0;
            const int nLACOperonRepressor = 200;
            const int nInhibittedLAC = 0;
            const int nLactose = 200;
            const int nGlucose = 200;
            const int nGalactose = 0;
            const int nLactoseAndLACOperonRepressor = 0;
            const int nCyclicAMP = 200;
            const int nCAP = 200;
            const int nPromoter = 0;
            const int nPromoterAndLAC = 0;
            //const int n_ = 0;
            //const int n_ = 0;

            //adds particles to container
            container.AddRandomParticles(LACGenerator, nLAC, "LAC");
            container.AddRandomParticles(RNAPolymeraseGenerator, nRNAPolymerase, "RNAPolymerase");
            container.AddRandomParticles(BgalGenerator, nBgal, "Bgal");
            container.AddRandomParticles(LACOperonRepressorGenerator, nLACOperonRepressor, "LACOperonRepressor");
            container.AddRandomParticles(InhibittedLACGenerator, nInhibittedLAC, "InhibittedLAC");
            container.AddRandomParticles(LactoseGenerator, nLactose, "Lactose");
            container.AddRandomParticles(GlucoseGenerator, nGlucose, "Glucose");
            container.AddRandomParticles(GalactoseGenerator, nGalactose, "Galactose");
            container.AddRandomParticles(LactoseAndLACOperonRepressorGenerator, nLactoseAndLACOperonRepressor, "LactoseAndLACOperonRepressor");
            container.AddRandomParticles(CyclicAMPGenerator, nCyclicAMP, "CyclicAMP");
            container.AddRandomParticles(CAPGenerator, nCAP, "CAP");
            container.AddRandomParticles(PromoterGenerator, nPromoter, "Promoter");
            container.AddRandomParticles(PromoterAndLACGenerator, nPromoterAndLAC, "PromoterAndLAC");
            //container.AddRandomParticles(_Generator, n_, "_");
            //container.AddRandomParticles(_Generator, n_, "_");

        }
        //sets up container for Project part2
        private static void Project2(double temperature, MyReactingParticleContainer container)
        {
            const double massS = 1.0132078e-25;
            const double massI = 1.0132078e-25;
            const double massR = 1.0132078e-25;
            const double massD = 1.0132078e-25;
            const double massOH = 1.0132078e-25;
            const double massCH = 1.0132078e-25;
            const double massIM = 1.0132078e-25;
            Color colorS = Colors.Yellow;
            Color colorI = Colors.Blue;
            Color colorR = Colors.Purple;
            Color colorD = Colors.Orange;
            Color colorOH = Colors.Green;
            Color colorCH = Colors.Red;
            Color colorIM = Colors.DarkBlue;


            container.Dictionary.AddParticle(new ParticleInfo("S", massS, ConvertColor(colorS)));
            container.Dictionary.AddParticle(new ParticleInfo("I", massI, ConvertColor(colorI)));
            container.Dictionary.AddParticle(new ParticleInfo("IM", massIM, ConvertColor(colorIM)));
            container.Dictionary.AddParticle(new ParticleInfo("R", massR, ConvertColor(colorR)));
            container.Dictionary.AddParticle(new ParticleInfo("D", massD, ConvertColor(colorD)));
            container.Dictionary.AddParticle(new ParticleInfo("OH", massOH, ConvertColor(colorOH),Shapes.Shapes3D.Cube));
            container.Dictionary.AddParticle(new ParticleInfo("CH", massCH, ConvertColor(colorCH), Shapes.Shapes3D.Cube));

            var SGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["S"]);
            var IGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["I"]);
            var IMGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["IM"]);
            var RGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["R"]);
            var DGenerator = new BoltzmannGenerator(container, temperature, container.Dictionary.Map["D"]);
            var OHGenerator = new StaticGenerator(container);
            var CHGenerator = new StaticGenerator(container);

            //add particles heare with the number of particles
            const int nS = 700;
            const int nI = 1;
            const int nIM = 0;
            const int nR = 0;
            const int nD = 0;
            const int nOH = 10;
            const int nCH = 0;

            container.AddRandomParticles(SGenerator, nS, "S");
            container.AddRandomParticles(IGenerator, nI, "I");
            container.AddRandomParticles(IMGenerator, nIM, "IM");
            container.AddRandomParticles(RGenerator, nR, "R");
            container.AddRandomParticles(DGenerator, nD, "D");
            container.AddRandomParticles(OHGenerator, nOH, "OH");
            container.AddRandomParticles(CHGenerator, nCH, "CH");
        }
    }
}
