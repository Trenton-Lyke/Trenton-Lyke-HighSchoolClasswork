﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Thermodynamics
{
    //used to remove all white space in string
    //source: https://www.techiedelight.com/remove-whitespace-from-string-csharp/
    public static class Extensions
    {
        private static readonly Regex regex = new Regex(@"\s+");
        public static string RemoveWhiteSpaces(this string str)
        {
            return regex.Replace(str, String.Empty);
        }
    }

    //reaction class used to represent a chemical reaction
    public class Reaction
    {

        
        List<string> reactants;
        List<string> products;
        double activationEnergy;
        //sign represents if the reaction is endothermic or exothermic
        int sign;
        
        List<string> catalysts;

        bool isActivationEnergyCap;


        //parses string to make reaction and sets more information about the reaction
        public Reaction(string reaction, double activationEnergy, int sign, List<string> catalysts= null, bool isActivationEnergyCap=false)
        {
            this.isActivationEnergyCap = isActivationEnergyCap;
            this.catalysts = catalysts ?? new List<string>();
            this.sign = sign;
            this.activationEnergy = activationEnergy;
            reactants = new List<String>();
            products = new List<String>();
            
            reaction = reaction.Trim().RemoveWhiteSpaces();
            string[] compounds = reaction.Split("+");
            bool isReactant = true;
            for (int i = 0; i < compounds.Length; i++) {
                if (isReactant)
                {
                    if (compounds[i].Contains('='))
                    {
                        string[] reactantAndProduct = compounds[i].Split("=");
                        int coefficient = ExtractCoefficient(reactantAndProduct[0]);
                        if (coefficient != 1) {
                            reactantAndProduct[0] = ReplaceFirst(reactantAndProduct[0], "" + coefficient, "");
                        }
                        for (int k = 0; k < coefficient; k++)
                        {
                            reactants.Add(reactantAndProduct[0]);
                        }
                        coefficient = ExtractCoefficient(reactantAndProduct[1]);
                        if (coefficient != 1)
                        {
                            reactantAndProduct[1] = ReplaceFirst(reactantAndProduct[1], "" + coefficient, "");
                        }
                        for (int k = 0; k < coefficient; k++)
                        {
                            products.Add(reactantAndProduct[1]);
                        }
                        isReactant = false;
                    }
                    else
                    {
                        int coefficient = ExtractCoefficient(compounds[i]);
                        if (coefficient != 1)
                        {
                            compounds[i] = ReplaceFirst(compounds[i], "" + coefficient, "");
                        }
                        for (int k = 0; k < coefficient; k++)
                        {
                            reactants.Add(compounds[i]);
                        }
                    }
                }
                else {
                    int coefficient = ExtractCoefficient(compounds[i]);
                    if (coefficient != 1)
                    {
                        compounds[i] = ReplaceFirst(compounds[i], "" + coefficient, "");
                    }
                    for (int k = 0; k < coefficient; k++)
                    {
                        products.Add(compounds[i]);
                    }
                }
            }
            
        }

        
        public double getActivationEnergy(List<Particle> nearby) {
            
            foreach (Particle compound in nearby) {
                if (catalysts.Contains(compound.Info.Name)) {
                    return 0;
                }
            }
            
            return activationEnergy;
        }
        public double getReactionPosibility(List<Particle> nearby)
        {
            foreach (Particle compound in nearby)
            {
                if (catalysts.Contains(compound.Info.Name))
                {
                    return .4;
                }
            }
            return activationEnergy;
        }

        public int getSign() {
            return sign;
        }

        public bool hasActivationEnergyCap()
        {
            return isActivationEnergyCap;
        }

        //extracts coefficient of a term and returns
        public int ExtractCoefficient(String term) {
            String coefficient = "";
            for (int i = 0; i < term.Length; i++) {
                if (Char.IsDigit(term[i]))
                {
                    coefficient += term[i];
                }
                else {
                    break;
                }
            }
            if (coefficient == "") {
                return 1;
            }
            return int.Parse(coefficient);
        }

        
        public List<string> GetProductNames() {
            return products;
        }

        //returns the first indexes that the each reactant excluding the given particle is found in the given list of particle
        public List<int> GetReactantIndexes(Particle particle, List<Particle> nearby) {
            if (reactants.Contains(particle.Info.Name))
            {
                List<int> indexes = new List<int>();
                List<string> compounds = new List<string>();
                foreach (Particle nearbyParticle in nearby)
                {
                    compounds.Add(nearbyParticle.Info.Name);
                }
                bool checkParticleAlready = false;
                foreach (string reactant in reactants)
                {
                    if (reactant != particle.Info.Name || checkParticleAlready)
                    {
                        int index = compounds.IndexOf(reactant);
                        Console.WriteLine(index);
                        while (index != -1 && indexes.Contains(index))
                        {
                            index = compounds.IndexOf(reactant, index + 1);
                        }
                        if (index != -1)
                        {
                            indexes.Add(index);
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else {
                        checkParticleAlready = true;
                    }
                }
                return indexes;
            }
            else {
                return null;
            }
        }

        //return the string with the first occurence of another given string replaced with another given string
        //source: https://lonewolfonline.net/replace-first-occurrence-string/
        public string ReplaceFirst(string text, string search, string replace)
        {
            int pos = text.IndexOf(search);
            if (pos < 0)
            {
                return text;
            }
            return text.Substring(0, pos) + replace + text.Substring(pos + search.Length);
        }
    }



}
