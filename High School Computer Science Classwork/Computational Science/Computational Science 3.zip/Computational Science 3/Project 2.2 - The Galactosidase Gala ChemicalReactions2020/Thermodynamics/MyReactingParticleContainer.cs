﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Text;

namespace Thermodynamics
{
    public class MyReactingParticleContainer : ReactingParticleContainer
    {
        Random randomGenerator = new Random();
        List<Particle> removedParticles = new List<Particle>();
                public MyReactingParticleContainer(double side, double collisionRadius) :
            base(side, collisionRadius)
        {
           
            
        }

        protected override void React(Particle particle, List<Particle> nearby)
        {
            //Level 1
            //Level1(particle, nearby);

            //Level 2 and 3
            //Level2And3(particle, nearby);

            //Level 4
            //Level4(particle, nearby);

            //Project
            //Project(particle, nearby);

            //Project 2.2
            Project2(particle, nearby);

        }

        //logic for react method for level 1
        private void Level1(Particle particle, List<Particle> nearby)
        {
            foreach (Particle otherParticle in nearby)
            {
                if (particle.Info.Name != "NH4Cl" && otherParticle.Info.Name != "NH4Cl" && particle.Info.Name != otherParticle.Info.Name)
                {
                    AddParticle("NH4Cl", (particle.Position + nearby[0].Position) / 2, (particle.Momentum + nearby[0].Momentum) / (particle.Info.Mass + nearby[0].Info.Mass));
                    RemoveParticle(particle);
                    RemoveParticle(otherParticle);
                    break;
                }
            }
        }

        //logic for react method for level 2 and 3
        private void Level2And3(Particle particle, List<Particle> nearby)
        {
            String catalyst = "CA";
            Dictionary<string, List<Particle>> particles = new Dictionary<string, List<Particle>>();
            
            particles.Add(catalyst, new List<Particle>());
            double activationEnergy = 3e-20;
            foreach (Particle otherParticle in nearby)
            {
                if (otherParticle.Info.Name==catalyst) {
                    activationEnergy = 0;
                }
            }
            
            
            switch (particle.Info.Name)
            {
                case "CO2":
                    AttemptForwardReact(particle, nearby, "H2O", "H2O", "HCO3", "H3O", activationEnergy);
                    break;
                case "H2O":
                    AttemptForwardReact(particle, nearby, "H2O", "CO2", "HCO3", "H3O", activationEnergy);
                    break;
                case "HCO3":
                    AttemptReverseReact(particle, nearby, "H3O", "H2O", "H2O", "CO2", activationEnergy);
                    break;
                case "H3O":
                    AttemptReverseReact(particle, nearby, "HCO3", "H2O", "H2O", "CO2", activationEnergy);
                    break;
            }
        }

        //logic for react method for level 4
        private void Level4(Particle particle, List<Particle> nearby) {
            List<Reaction> reactions = new List<Reaction>() { new Reaction("C4H4O5+C23H38N7O17P3S+H2O=C21H36N7O16P3S+C6H8O7", 0, 0), new Reaction("C6H8O7=H2O+C6H6O6", 0, 0), new Reaction("H2O+C6H6O6=IC6H8O7", 0, 0), new Reaction("IC6H8O7+NAD=CO2+NADH+H+C5H6O5", 0, 0), new Reaction("C5H6O5+NAD+C21H36N7O16P3S=CO2+NADH+H+C25H40N7O19P3S", 0, 0), new Reaction("C25H40N7O19P3S+GDP+Pi+H2O=GTP+C21H36N7O16P3S+C4H6O4", 0, 0), new Reaction("C4H6O4+FAD=FADH2+C4H4O4", 0, 0), new Reaction("C4H4O4+H2O=C4H6O5", 0, 0), new Reaction("C4H6O5+NAD=NADH+H+C4H4O5", 0, 0) };

            foreach (Reaction aReaction in reactions)
            {
                IndividualReact(particle, nearby, aReaction);
            }
        }

        private void Project(Particle particle, List<Particle> nearby)
        {
            List<Reaction> reactions = new List<Reaction>() {   
                new Reaction("LAC+RNAPolymerase=Bgal+LAC+RNAPolymerase", 1e-20, -1),
                new Reaction("LAC+LACOperonRepressor=InhibittedLAC", 1e-20, 1),
                new Reaction("InhibittedLAC=LAC+LACOperonRepressor", 1e-20, 0),
                new Reaction("Lactose+LACOperonRepressor=LactoseAndLACOperonRepressor", 1e-20, 0),
                new Reaction("Lactose+Bgal=Glucose+Galactose+Bgal", 1e-20, 0),
                new Reaction("LactoseAndLACOperonRepressor+Bgal=Glucose+Galactose+Bgal+LACOperonRepressor", 1e-20, 0),
                new Reaction("CyclicAMP+CAP=Promoter", 1e-20, 0),
                new Reaction("Promoter+LAC=PromoterAndLAC", 1e-20, 1),
                new Reaction("Promoter+LAC=PromoterAndLAC", 1e-20, -1),
                new Reaction("PromoterAndLAC+RNAPolymerase=Bgal+PromoterAndLAC+RNAPolymerase", 0, 0),
                new Reaction("CyclicAMP+Glucose=Glucose", 1e-20, 0)
            };

            foreach (Reaction aReaction in reactions)
            {
                IndividualReact(particle, nearby, aReaction);
            }
        }
        private void Project2(Particle particle, List<Particle> nearby)
        {
            int carrying_capacity = 3;
            List<Reaction> reactions = new List<Reaction>() {
                new Reaction("S+I=I+I", .6, 0),
                //new Reaction("S+IM=IM+I", 1, 0),
                //new Reaction("R+I=I+IM", .1, 0),
                //new Reaction("R+IM=IM+IM", .1, 0),

                new Reaction("I=D", .005, 0),
                //new Reaction("IM=D", .005, 0),

            };
            for (int i = 0; i <= carrying_capacity; i++)
            {
                string reaction = "CH=OH";
                for (int j = 0; j < i; j++)
                {
                    reaction = "I+" + reaction + "+I";
                }
                for (int j = 0; j < carrying_capacity - i; j++)
                {
                    reaction = "IM+" + reaction + "+IM";
                }
                Console.Write(reaction);
                reactions.Add(new Reaction(reaction, 1, 0));

            }

            for (int i = 0; i <= carrying_capacity; i++) {
                string reaction = "CH=OH";
                for (int j = 0; j < i; j++) {
                    reaction = "R+" + reaction+ "+R";
                }
                for (int j = 0; j < carrying_capacity -i; j++)
                {
                    reaction = "D+" + reaction+ "+D";
                }
                Console.Write(reaction);
                reactions.Add(new Reaction(reaction, 1, 0));
                
            }
            reactions.Add(new Reaction("I=R", .03, 0, new List<string> { "OH" }));
            //reactions.Add(new Reaction("IM=R", .99, 0, new List<string> { "OH" }));

            foreach (Reaction aReaction in reactions)
            {
                IndividualReact(particle, nearby, aReaction, false, new List<string> { "OH","CH" });
            }
        }
        //checks and reacts based on a specific reaction for level 4
        private void IndividualReact(Particle particle, List<Particle> nearby, Reaction aReaction, bool isActivationEnergyBased = true, List<string> staticParticles = null)
        {
            
            List<int> reactantIndexes = aReaction.GetReactantIndexes(particle, nearby);
            
            List<string> productNames = aReaction.GetProductNames();

            if (reactantIndexes != null)
            {
                List<Particle> reactants = new List<Particle>();
                reactants.Add(particle);
                List<Particle> products = new List<Particle>();
                foreach (int index in reactantIndexes)
                {
                    reactants.Add(nearby[index]);
                }
                Console.Write(reactants);
                foreach (string name in productNames)
                {
                    products.Add(new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[name]));
                }
                if (isActivationEnergyBased)
                {
                    if (HasRequiredEnergy(reactants, aReaction, nearby))
                    {
                        for (int k = 0; k < nearby.Count; k++)
                        {
                            Console.Write(reactantIndexes);
                            if (!reactantIndexes.Contains(k))
                            {
                                nearby[k].Velocity += aReaction.getSign() * nearby[k].Velocity.UnitVector() * .01;
                            }
                        }
                        replaceParticles(reactants, products);
                    }
                }
                else {
                    if (willReact(aReaction, nearby))
                    {
                        replaceParticles(reactants, products, staticParticles);
                    }
                }
            }
        }

        //checks if the reactants have enough energy to react
        private bool HasRequiredEnergyOld(List<Particle> particles, double activationEnergy)
        {
            double KESum = 0;
            foreach (Particle particle in particles)
            {
                KESum += particle.KineticEnergy;
            }
            Console.WriteLine(KESum);
            if (KESum >= activationEnergy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool willReact(Reaction aReaction, List<Particle> nearby) {

            return aReaction.getReactionPosibility(nearby) >= randomGenerator.NextDouble();
            
        }

        //checks if the reactants have enough energy to react
        private bool HasRequiredEnergy(List<Particle> particles, Reaction aReaction, List<Particle> nearby)
        {
            double activationEnergy = aReaction.getActivationEnergy(nearby);
            double KESum = 0;
            foreach (Particle particle in particles)
            {
                KESum += particle.KineticEnergy;
            }
            Console.WriteLine(KESum);
            if (!aReaction.hasActivationEnergyCap())
            {
                if (KESum >= activationEnergy)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (KESum >= activationEnergy)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        //replaces reactants with products of reaction
        private void replaceParticles(List<Particle> reactants, List<Particle> products, List<string> staticParticles = null) {
            List<string> staticParticlesList = staticParticles ?? new List<string>();
            foreach (Particle reactant in reactants) {
                if (removedParticles.Contains(reactant)) {
                    return;
                }
            }
            Vector positionSum = Vector.NullVector();
            Vector momentumSum = Vector.NullVector();
            double massSum = 0;
            Console.Write(reactants);
            foreach (Particle reactant in reactants) {
                positionSum += reactant.Position;
                momentumSum += reactant.Momentum;
                RemoveParticle(reactant);
                removedParticles.Add(reactant);
            }
            foreach (Particle product in products)
            {
                massSum += product.Info.Mass;
            }

            Vector centerPosition = positionSum / reactants.Count;
            //Vector momentumPartian = momentumSum / products.Count;
            Vector velocityPartian = momentumSum / massSum;
            int lastI = products.Count - 1;
            int secondToLastI = lastI - 2;
            int thirdToLastI = lastI - 2;
            int i = 0;
            foreach (Particle product in products) {
                if (staticParticlesList.Contains(product.Info.Name)) {
                    AddParticle(product.Info.Name, centerPosition, Vector.NullVector());
                    continue;
                }
                int[] signs = new int[3];
                for (int j = 0; j < signs.Length; j++) {
                    if (randomGenerator.NextBool())
                    {
                        signs[j] = 1;
                    }
                    else {
                        signs[j] = -1;
                    }
                }

                Vector productPosition = centerPosition + new Vector(signs[0] * randomGenerator.NextDouble() * 3, signs[1] * randomGenerator.NextDouble() * 3, signs[2] * randomGenerator.NextDouble() * 3);

                if (products.Count % 2 == 1 && i != thirdToLastI && i != secondToLastI && i != lastI)
                {
                    if (i % 2 == 0)
                    {
                        AddParticle(product.Info.Name, productPosition, -velocityPartian );
                    }
                    else if (i % 2 == 1 && i != thirdToLastI && i != secondToLastI && i != lastI)
                    {
                        AddParticle(product.Info.Name, productPosition, velocityPartian + (velocityPartian * products[i-1].Info.Mass) / product.Info.Mass);
                    }
                    else if (i == thirdToLastI)
                    {
                        AddParticle(product.Info.Name, productPosition, -.5 * velocityPartian);
                    }
                    else if (i == secondToLastI)
                    {
                        AddParticle(product.Info.Name, productPosition, -.5 * velocityPartian);
                    }
                    else
                    {
                        AddParticle(product.Info.Name, productPosition,  velocityPartian + (velocityPartian * products[i - 1].Info.Mass) / product.Info.Mass + (velocityPartian * products[i - 2].Info.Mass) / product.Info.Mass);
                    }
                }
                else {
                    if (i % 2 == 0 )
                    {
                        AddParticle(product.Info.Name, productPosition, -velocityPartian);
                    }
                    else
                    {
                        AddParticle(product.Info.Name, productPosition, velocityPartian + (velocityPartian * products[i - 1].Info.Mass) / product.Info.Mass);
                    }
                    
                }

                i++;
            }
            
        }

        

        //checks and reacts based on levels 2 and 3's forward reaction
        public void AttemptForwardReact(Particle particle, List<Particle> nearby, string reactant2 , string reactant3, string product1, string product2, double activationEnergy) {
             for (int i = 0; i < nearby.Count; i++)
                {
                    if (nearby[i].Info.Name == reactant2)
                    {
                        for (int j = 0; j < nearby.Count; j++)
                        {
                            if (nearby[j].Info.Name == reactant3)
                            {
                                List<Particle> reactants = new List<Particle>() { particle, nearby[i], nearby[j] };
                                List<Particle> products = new List<Particle>() { new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product1]), new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product2]) };

                                if (i != j && HasRequiredEnergyOld(reactants, activationEnergy))
                                {
                                for (int k = 0; k < nearby.Count; k++) {
                                    if (k != i && k != j) {
                                        nearby[k].Velocity -= nearby[k].Velocity.UnitVector()*1000;
                                    }
                                }
                                    replaceParticles(reactants, products);
                                    return;
                                }
                            }
                        }
                    }
                }
            
        }

        //checks and reacts based on levels 2 and 3's reverse reaction
        public void AttemptReverseReact(Particle particle, List<Particle> nearby, string reactant2, string product1, string product2, string product3, double activationEnergy)
        {
            for (int i = 0; i < nearby.Count; i++)
            {
                if (nearby[i].Info.Name == reactant2)
                {
                    
                            List<Particle> reactants = new List<Particle>() { particle, nearby[i]};
                            List<Particle> products = new List<Particle>() { new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product1]), new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product2]), new Particle(Vector.NullVector(), Vector.NullVector(), Dictionary.Map[product3]) };

                            if ( HasRequiredEnergyOld(reactants, activationEnergy))
                            {
                                for (int k = 0; k < nearby.Count; k++)
                                {
                                    if (k != i )
                                    {
                                        nearby[k].Velocity += nearby[k].Velocity.UnitVector() * 1000;
                                    }
                                }
                                replaceParticles(reactants, products);
                                return;
                            }
                        
                }
            }

        }

    }

        
    
    
}
