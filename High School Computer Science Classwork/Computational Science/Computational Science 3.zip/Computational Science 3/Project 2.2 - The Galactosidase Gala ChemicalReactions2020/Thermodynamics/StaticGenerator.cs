﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DongUtility;

namespace Thermodynamics
{
    /// <summary>
    /// A random generator that generates particles with a flat distribution between two endpoints
    /// </summary>
    public class StaticGenerator : RandomGenerator
    {
        
        public StaticGenerator(ParticleContainer cont) :
            base(cont)
        {
 
        }

        override protected double GetSpeed(ParticleInfo info)
        {
            return 0;
        }
    }
}
