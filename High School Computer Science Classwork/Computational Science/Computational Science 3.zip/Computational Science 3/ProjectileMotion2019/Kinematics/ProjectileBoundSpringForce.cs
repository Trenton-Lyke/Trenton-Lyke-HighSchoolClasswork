﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DongUtility;

namespace Kinematics
{
    public class ProjectileBoundSpringForce : SpringForce
    {
        private Projectile other;

        public ProjectileBoundSpringForce(Projectile projectile1, Projectile projectile2, double springConstant,
            double unstretchedLength = 0) :
            base (projectile1, springConstant, unstretchedLength)
        {
            this.other = projectile2;
        }

        protected override Vector SpringPosition()
        {
            return other.Position;
        }
    }
}
