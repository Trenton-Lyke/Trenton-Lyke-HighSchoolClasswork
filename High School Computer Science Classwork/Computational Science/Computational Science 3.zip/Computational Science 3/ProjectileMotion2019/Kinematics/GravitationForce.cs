﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DongUtility;

namespace Kinematics
{
    public class GravitationForce : GlobalForce
    {
        private Vector amount;

        public GravitationForce(KinematicsEngine engine, Vector amount) :
            base(engine)
        {
            this.amount = amount;
        }

        protected override Vector GetForce(Projectile proj)
        {
            return proj.Mass * amount;
        }
    }
}
