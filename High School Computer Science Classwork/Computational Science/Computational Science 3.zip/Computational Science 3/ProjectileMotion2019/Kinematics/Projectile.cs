﻿using System;

using DongUtility;

namespace Kinematics
{
    public class Projectile
    {
        public Vector Position { get; set; }
        public Vector Velocity { get; set; }
        private Vector acceleration = Vector.NullVector();
        public Vector Acceleration { get { return acceleration; } } 
        private Vector forces = Vector.NullVector();

        private double mass;
        public double Mass
        {
            get
            {
                return mass;
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException("mass", "Mass cannot be zero or negative!");
                }
                else
                {
                    mass = value;
                }
            }
        }

        public string Name { get; }

        public Projectile(Vector position, Vector velocity, double mass, String name)
        {
            Position = position;
            Velocity = velocity;
            this.mass = mass;
            this.Name = name;
        }

        override public string ToString()
        {
            return Position + "\t" + Velocity + "\t" + Acceleration;
        }

        private void Accelerate(double timeIncrement)
        {
            Velocity += Acceleration * timeIncrement;
        }

        private void AdvancePosition(double timeIncrement)
        {
            Position += Velocity * timeIncrement;
        }

        public void AddForce(Vector force)
        {
            forces += force;
        }

        public void Update(double timeIncrement)
        {
            SetAccel();
            Accelerate(timeIncrement);
            AdvancePosition(timeIncrement);
            forces = Vector.NullVector();
        }

        private void SetAccel()
        {
            acceleration = forces / mass;
        }

        public double KineticEnergy()
        {
            double speed = Velocity.Magnitude;
            return .5 * mass * speed * speed;
        }
    }
}
