﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DongUtility;

namespace Kinematics
{
    abstract public class ParticleForce : Force
    {
        private Projectile particle;

        public ParticleForce(Projectile particle)
        {
            this.particle = particle;
        }

        protected Projectile GetParticle()
        {
            return particle;
        }

        abstract protected Vector GetForce();

        public override void AddForce()
        {
            particle.AddForce(GetForce());
        }
    }
}
