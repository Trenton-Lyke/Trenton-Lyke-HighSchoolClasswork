﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Kinematics
{
    public class KinematicsEngine
    {
        public double Time { get; set; } = 0;
        public IList<Projectile> Projectiles { get; } = new List<Projectile>();
        private StreamWriter ps;
        private IList<Force> forces = new List<Force>();

        public KinematicsEngine(StreamWriter ps)
        {
            this.ps = ps;
        }

        public void Run(double timeIncrement, int nIncrements)
        {
            Run(timeIncrement, nIncrements, true);
        }

        public void Run(double timeIncrement, int nIncrements, bool print)
        {
            if (print)
            {
                ps.WriteLine(Header());
            }

            for (int i = 0; i < nIncrements; ++i)
            {
                Increment(timeIncrement);
                if (print)
                {
                    ps.WriteLine(ToString());
                }

            }
        }

        public void AddProjectile(Projectile projectile)
        {
            if (Projectiles.Contains(projectile))
            {
                throw new InvalidOperationException("Attempted to add Projectile that already exists!");
            }
            else
            {
                Projectiles.Add(projectile);
            }
        }

        public void AddForce(Force force)
        {
            forces.Add(force);
        }

        override public string ToString()
        {
            string response = "";
            //		response = "kludge:\t" + (projectiles.get(0).getPosition().magnitude() - projectiles.get(1).getPosition().magnitude());
            foreach (Projectile projectile in Projectiles)
            {
                response += "\t" + Time + "\t" + projectile;
            }
            return response;
        }

        public string Header()
        {
            string response = "";
            foreach (Projectile projectile in Projectiles)
            {
                response += projectile.Name;
                response += "\ttime\tx\ty\tz\tMag\tvx\tvy\tvz\tSpeed\tax\tay\taz\t|a|";
            }
            return response;
        }

        public void Increment(double timeIncrement)
        {
            Time += timeIncrement;
            foreach (Force force in forces)
            {
                force.AddForce();
            }
            foreach (Projectile projectile in Projectiles)
            {
                projectile.Update(timeIncrement);
            }
        }

    }
}
