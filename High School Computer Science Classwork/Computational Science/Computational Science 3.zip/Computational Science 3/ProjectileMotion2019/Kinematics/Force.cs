﻿using DongUtility;

namespace Kinematics
{
    abstract public class Force
    {
        abstract public void AddForce();
    }
}
