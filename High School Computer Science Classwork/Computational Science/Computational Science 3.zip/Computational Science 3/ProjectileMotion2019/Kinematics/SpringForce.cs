﻿using DongUtility;

namespace Kinematics
{
    abstract public class SpringForce : ParticleForce
    {
        private double springConstant;
        private double unstretchedLength;
        protected abstract Vector SpringPosition();

        public SpringForce(Projectile projectile, double springConstant, double unstretchedLength = 0) :
            base(projectile)
        {
            this.springConstant = springConstant;
            this.unstretchedLength = unstretchedLength;
        }

        protected override Vector GetForce()
        {
            Vector difference = GetParticle().Position - SpringPosition();
            double magnitude = springConstant * (unstretchedLength - difference.Magnitude);
            return magnitude * difference.UnitVector();
        }
    }
}