﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DongUtility;

namespace Kinematics
{
    abstract public class GlobalForce : Force
    {
        private IList<Projectile> projectiles;

        public GlobalForce(KinematicsEngine engine)
        {
            projectiles = engine.Projectiles;
        }

        protected IList<Projectile> getProjectiles()
        {
            return projectiles;
        }

        abstract protected Vector GetForce(Projectile proj);

        public override void AddForce()
        {
            foreach (Projectile proj in projectiles)
            {
                proj.AddForce(GetForce(proj));
            }
        }
    }
}
