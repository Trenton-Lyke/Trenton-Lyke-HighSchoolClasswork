﻿using System.Collections.Generic;
using DongUtility;

namespace Kinematics
{
    public class AirResistanceForce : GlobalForce
    {
        private double coefficient;

        public AirResistanceForce(KinematicsEngine engine, double coefficient) :
            base(engine)
        {
            this.coefficient = coefficient;
        }

        override protected Vector GetForce(Projectile proj)
        {
            double speed = proj.Velocity.Magnitude;
            return proj.Velocity.UnitVector() * (-coefficient * speed * speed);
        }

    }
}
