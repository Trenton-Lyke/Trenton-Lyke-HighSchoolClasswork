﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectileMotion;
using Visualizer.Kinematics;
using VisualizerControl;

namespace Visualizer
{
    class EngineAdapter : Kinematics.IEngine
    {
        private World world;

        public EngineAdapter(World world) {
            this.world = world;
        }

        

        double Kinematics.IEngine.Time => world.Time;

        List<IProjectile> Kinematics.IEngine.Projectiles => Projectiles();

        public List<IProjectile> Projectiles()
        {
            List<IProjectile> IProjectiles = new List<IProjectile>();
            foreach (Projectile projectile in world.projectilesOnSprings) {
                IProjectiles.Add(new ProjectileAdapter(projectile));
            }
            return IProjectiles;
        }


        bool Kinematics.IEngine.Tick(double newTime)
        {
            world.Tick(newTime - world.Time);
            return world.Time <= 100;
        }
    }
}
