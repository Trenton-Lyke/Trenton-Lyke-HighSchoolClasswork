﻿//using DongUtility;
using ProjectileMotion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using VisualizerControl.Shapes;
using Utility;
namespace Visualizer.Kinematics
{
    static internal class KinematicsDriver
    {
        static internal void RunKinematics()
        {
            //level1();
            //level2();
            //level3();
            //challenge();
        }
        private static void level1()
        {
            //creates projectiles and springs and puts them into their corresponding lists
            Projectile projectile1 = new Projectile(new Vector(0, 0, 0), new Vector(10 * Math.Cos(Math.PI / 4), 0, 10 * Math.Cos(Math.PI / 4)), new Vector(0, 0, 0), 0, 5);

            Spring spring1 = new Spring(new Vector(0, 0, 0), new Vector(0, 0, 0), 0);

            List<Projectile> projectiles = new List<Projectile>();
            projectiles.Add(projectile1);


            List<Spring> springs = new List<Spring>();
            springs.Add(spring1);


            Vector gravitationalAcceleration = new Vector(0, 0, -9.8);


            //Create an engine, for example:
            World engine = new World(0, gravitationalAcceleration, springs, projectiles);


            // Once you have created an adapter class for engine, you can create an instance
            var adapter = new EngineAdapter(engine);

            Sphere3D.NSegments = 40;

            // Create a visualization
            var visualization = new KinematicsVisualization(adapter);



            // Create the full visualizer
            var fullViz = new FullVisualizer(visualization);
            fullViz.BackgroundFile = "stars.jpg";




            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Position), "Time (s)", "Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Velocity), "Time (s)", "Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Acceleration), "Time (s)", "Acceleration (m/s^2)");

            fullViz.Graphs.AddSingleGraph("Speed", () => engine.Time, (() => engine.Projectiles[0].Velocity.Magnitude), Colors.Teal, "Time (s)", "Speed (m/s)");




            // Now run the visualizer
            fullViz.Show();
        }
        private static void level2()
        {
            //creates projectiles and springs and puts them into their corresponding lists
            Projectile projectile1 = new Projectile(new Vector(0, 0, 0), new Vector(10 * Math.Cos(Math.PI / 4), 0, 10 * Math.Cos(Math.PI / 4)), new Vector(0, 0, 0), .3, 5);

            Spring spring1 = new Spring(new Vector(0, 0, 0), new Vector(0,0,0), 0);

            List<Projectile> projectiles = new List<Projectile>();
            projectiles.Add(projectile1);


            List<Spring> springs = new List<Spring>();
            springs.Add(spring1);


            Vector gravitationalAcceleration = new Vector(0, 0, -9.8);

            //Create an engine, for example:
            World engine = new World(0, gravitationalAcceleration, springs, projectiles);


            // Once you have created an adapter class for engine, you can create an instance
            var adapter = new EngineAdapter(engine);

            Sphere3D.NSegments = 40;

            // Create a visualization
            var visualization = new KinematicsVisualization(adapter);

            

            // Create the full visualizer
            var fullViz = new FullVisualizer(visualization);
            fullViz.BackgroundFile = "stars.jpg";




            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Position), "Time (s)", "Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Velocity), "Time (s)", "Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Acceleration), "Time (s)", "Acceleration (m/s^2)");

            fullViz.Graphs.AddSingleGraph("Speed", () => engine.Time, (() => engine.Projectiles[0].Velocity.Magnitude), Colors.Teal, "Time (s)", "Speed (m/s)");




            // Now run the visualizer
            fullViz.Show();
        }
        private static void level3()
        {
            //creates projectiles and springs and puts them into their corresponding lists
            Projectile projectile1 = new Projectile(new Vector(1, 1, 1), new Vector(-2, 1, 3), new Vector(0, 0, 0), .3, 5);
            
            Spring spring1 = new Spring(new Vector(0, 0, 0), new Vector(1 / Math.Sqrt(3), 1 / Math.Sqrt(3), 1 / Math.Sqrt(3)), 2);
            
            List<Projectile> projectiles = new List<Projectile>();
            projectiles.Add(projectile1);
            

            List<Spring> springs = new List<Spring>();
            springs.Add(spring1);
            

            Vector gravitationalAcceleration = new Vector(0, 0, -9.8);

            //Create an engine, for example:
            World engine = new World(0, gravitationalAcceleration, springs, projectiles);

            
            // Once you have created an adapter class for engine, you can create an instance
            var adapter = new EngineAdapter(engine);

            Sphere3D.NSegments = 40;

            // Create a visualization
            var visualization = new KinematicsVisualization(adapter);

            // Use these to add connectors, which you can use to visualize springs
            visualization.ConnectorRadiusScale = .1;
            visualization.AddAnchoredConnector(0, new Vector3D(0, 0, 0), Colors.Gray);
            

            // Create the full visualizer
            var fullViz = new FullVisualizer(visualization);
            fullViz.BackgroundFile = "stars.jpg";




            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Position), "Time (s)", "Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Velocity), "Time (s)", "Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D(engine.Projectiles[0].Acceleration), "Time (s)", "Acceleration (m/s^2)");

            fullViz.Graphs.AddSingleGraph("Speed", () => engine.Time, (() => engine.Projectiles[0].Velocity.Magnitude), Colors.Teal, "Time (s)", "Speed (m/s)");




            // Now run the visualizer
            fullViz.Show();
        }
        private static void challenge() {
            //creates projectiles and springs and puts them into their corresponding lists
            Projectile projectile1 = new Projectile(new Vector(1, 1, 1), new Vector(-2, 1, 3), new Vector(0, 0, 0), .3, 5);
            Projectile projectile2 = new Projectile(new Vector(2, 2, 2), new Vector(1, -3, 2), new Vector(0, 0, 0), .3, 3);
            Spring spring1 = new Spring(new Vector(0, 0, 0), new Vector(1 / Math.Sqrt(3), 1 / Math.Sqrt(3), 1 / Math.Sqrt(3)), 10);
            Spring spring2 = new Spring(new Vector(1, 1, 1), new Vector(1 / Math.Sqrt(3), 1 / Math.Sqrt(3), 1 / Math.Sqrt(3)), 10);

            List<Projectile> projectiles = new List<Projectile>();
            projectiles.Add(projectile1);
            projectiles.Add(projectile2);

            List<Spring> springs = new List<Spring>();
            springs.Add(spring1);
            springs.Add(spring2);

            Vector gravitationalAcceleration = new Vector(0, 0, -9.8);

            //Create an engine, for example:
            World engine = new World(0, gravitationalAcceleration, springs, projectiles);

           
            // Once you have created an adapter class for engine, you can create an instance
            var adapter = new EngineAdapter(engine);

            Sphere3D.NSegments = 40;

            // Create a visualization
            var visualization = new KinematicsVisualization(adapter);

            // Use these to add connectors, which you can use to visualize springs
            visualization.ConnectorRadiusScale = .1;
            visualization.AddAnchoredConnector(0, new Vector3D(0, 0, 0), Colors.Gray);
            if (engine.Projectiles.Count() > 1)
            {
                visualization.AddTwoParticleConnector(0, 1, Colors.Gray);
            }

            // Create the full visualizer
            var fullViz = new FullVisualizer(visualization);
            fullViz.BackgroundFile = "stars.jpg";




            // Add graphs
            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertToVector3D((engine.Projectiles[0].Position * engine.Projectiles[0].Mass + engine.Projectiles[1].Position * engine.Projectiles[1].Mass) / (engine.Projectiles[0].Mass + engine.Projectiles[1].Mass)), "Time (s)", "Position (m)");
            fullViz.Add3DGraph("Velocity", () => engine.Time, () => ConvertToVector3D((engine.Projectiles[0].Velocity * engine.Projectiles[0].Mass + engine.Projectiles[1].Velocity * engine.Projectiles[1].Mass) / (engine.Projectiles[0].Mass + engine.Projectiles[1].Mass)), "Time (s)", "Velocity (m/s)");
            fullViz.Add3DGraph("Acceleration", () => engine.Time, () => ConvertToVector3D((engine.Projectiles[0].Acceleration * engine.Projectiles[0].Mass + engine.Projectiles[1].Acceleration * engine.Projectiles[1].Mass) / (engine.Projectiles[0].Mass + engine.Projectiles[1].Mass)), "Time (s)", "Acceleration (m/s^2)");

            fullViz.Graphs.AddSingleGraph("Distance From Each Other", () => engine.Time, (() => (engine.Projectiles[0].Position - engine.Projectiles[1].Position).Magnitude),
                Colors.Teal, "Time (s)", "Distance (m)");



            // Now run the visualizer
            fullViz.Show();
        }
        private static Vector3D ConvertToVector3D(Vector position)
        {
            return new Vector3D(position.X, position.Y, position.Z);
        }
    }
}
