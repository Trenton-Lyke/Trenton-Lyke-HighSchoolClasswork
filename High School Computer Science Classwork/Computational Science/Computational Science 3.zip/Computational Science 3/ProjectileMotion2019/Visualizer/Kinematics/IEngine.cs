﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visualizer.Kinematics
{
    interface IEngine
    {
        bool Tick(double newTime);

        List<IProjectile> Projectiles { get; }

        double Time { get; }
    }
}
