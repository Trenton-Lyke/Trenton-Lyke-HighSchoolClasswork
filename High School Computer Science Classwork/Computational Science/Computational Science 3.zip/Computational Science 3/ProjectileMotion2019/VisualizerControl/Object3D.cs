﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using VisualizerControl.Shapes;

namespace VisualizerControl
{
    /// <summary>
    /// A Class containing geometry, material, and transform - everything you need to draw in 3D
    /// </summary>
    public class Object3D
    {
        private readonly Shape3D shape;

        /// <summary>
        /// The geometry of the object
        /// </summary>
        public GeometryModel3D GeoModel { get; private set; }

        private TranslateTransform3D translation = new TranslateTransform3D();
        private ScaleTransform3D scale = new ScaleTransform3D();
        private AxisAngleRotation3D thetaRotation = new AxisAngleRotation3D();
        private AxisAngleRotation3D phiRotation = new AxisAngleRotation3D(new Vector3D(0, 0, 1), 0);
        private readonly RotateTransform3D rotation;

        static private Dictionary<Color, Brush> brushes = new Dictionary<Color, Brush>();
        static private Dictionary<Color, DiffuseMaterial> diffMaterials = new Dictionary<Color, DiffuseMaterial>();
        static private Dictionary<Color, SpecularMaterial> specMaterials = new Dictionary<Color, SpecularMaterial>();

        /// <param name="shape">The shape (geometry) of the object</param>
        /// <param name="material">The material of the object</param>
        public Object3D(Shape3D shape, Material material)
        {
            this.shape = shape;
            rotation = new RotateTransform3D(phiRotation);
            rotation = new RotateTransform3D(thetaRotation);

            // Create transformation
            var transGroup = new Transform3DGroup();
            transGroup.Children.Add(scale);
            transGroup.Children.Add(rotation);
            transGroup.Children.Add(translation);

            // Create geometry model
            GeoModel = new GeometryModel3D(shape.Mesh, material)
            {
                Transform = transGroup
            };
        }

        /// <summary>
        /// The object's current position
        /// </summary>
        public Vector3D Position
        {
            get
            {
                return new Vector3D(translation.OffsetX, translation.OffsetY, translation.OffsetZ);
            }
            set
            {
                translation.OffsetX = value.X;
                translation.OffsetY = value.Y;
                translation.OffsetZ = value.Z;
            }
        }

        /// <summary>
        /// The object's current scale, as a vector
        /// Each component represents the scale (relative to 1) of that axis.
        /// Most often all components are the same, but it is not a requirement.
        /// </summary>
        public Vector3D Scale
        {
            get
            {
                return new Vector3D(scale.ScaleX, scale.ScaleY, scale.ScaleZ);
            }
            set
            {
                scale.ScaleX = value.X;
                scale.ScaleY = value.Y;
                scale.ScaleZ = value.Z;
            }
        }

        /// <summary>
        /// Sets the scale to a given factor, scaled evenly in all directions
        /// </summary>
        public void ScaleEvenly(double scale)
        {
            Scale = new Vector3D(scale, scale, scale);
        }

        /// <summary>
        /// The rotation of the object, right-handed around the z axis, in radians
        /// (phi in physics, theta in math)
        /// </summary>
        public double AzimuthalAngle
        {
            get
            {
                return phiRotation.Angle;
            }
            set
            {
                phiRotation.Angle = UtilityFunctions.RadiansToDegrees(value);
                thetaRotation.Axis = new Vector3D(-Math.Sin(value), Math.Cos(value), 0);
            }
        }

        /// <summary>
        /// The angle of declination from the positive z axis, in radians
        /// (theta in physics, phi in math)
        /// </summary>
        public double PolarAngle
        {
            get
            {
                return thetaRotation.Angle;
            }
            set
            {
                thetaRotation.Angle = UtilityFunctions.RadiansToDegrees(value);
            }
        }

        /// <summary>
        /// A constructor to simplify input for solid colors
        /// </summary>
        /// <param name="specular">By default the material is diffuse, but this creates a specular material instead</param>
        public Object3D(Shape3D shape, Color color, bool specular = false) :
            this(shape, GetMaterial(color, specular))
        {
        }

        /// <summary>
        /// Changes the color (or specularity) of the object
        /// </summary>
        /// <param name="specular">Determines whether the material is specular or diffuse</param>
        protected void ChangeColor(Color color, bool specular = false)
        {
            var material = GetMaterial(color, specular);
            GeoModel.Material = material;
        }

        private const double specularCoefficient = 1;

        /// <summary>
        /// Creates a new material if one does not exist, or otherwise returns it from a dictionary
        /// </summary>
        static private Material GetMaterial(Color color, bool specular = false)
        {
            if (!brushes.ContainsKey(color))
            {
                var newBrush = new SolidColorBrush(color);
                newBrush.Freeze();
                brushes[color] = newBrush;
            }
            var brush = brushes[color];

            if (specular)
            {
                if (!specMaterials.ContainsKey(color))
                {
                    var newMaterial = new SpecularMaterial(brush, specularCoefficient);
                    newMaterial.Freeze();
                    specMaterials[color] = newMaterial;
                }
                return specMaterials[color];
            }
            else
            {
                if (!diffMaterials.ContainsKey(color))
                {
                    var newMaterial = new DiffuseMaterial(brush);
                    newMaterial.Freeze();
                    diffMaterials[color] = newMaterial;
                }
                return diffMaterials[color];
            }
        }
    }
}
