﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace VisualizerControl.Shapes
{
    abstract public class Shape3D
    {
        internal MeshGeometry3D Mesh { get; private set; }

        private static Dictionary<string, MeshGeometry3D> meshes = new Dictionary<string, MeshGeometry3D>();

        public Shape3D(string shapeName, bool freezeMesh = true)
        {
            if (meshes.ContainsKey(shapeName))
            {
                Mesh = meshes[shapeName];
            }
            else
            {
                MakeMesh();
                if (freezeMesh)
                {
                    Mesh.Freeze();
                }
                meshes[shapeName] = Mesh;
            }
        }

        public class Vertex
        {
            internal Vertex(Point3D position, Vector3D normal, Point textureCoordinate)
            {
                Position = position;
                Normal = normal;
                TextureCoordinate = textureCoordinate;
            }

            public Point3D Position { get; set; }
            public Vector3D Normal { get; set; }
            public Point TextureCoordinate { get; set; }
        }

        private void MakeMesh()
        {
            Mesh = new MeshGeometry3D();

            var vertices = MakeVertices();

            Mesh.Positions = new Point3DCollection(vertices.Count);
            Mesh.Normals = new Vector3DCollection(vertices.Count);
            Mesh.TextureCoordinates = new PointCollection(vertices.Count);
            Mesh.TriangleIndices = MakeTriangles();

            foreach (var vertex in vertices)
            {
                Mesh.Positions.Add(vertex.Position);
                Mesh.Normals.Add(vertex.Normal);
                Mesh.TextureCoordinates.Add(vertex.TextureCoordinate);
            }
        }

        abstract protected List<Vertex> MakeVertices();
        abstract protected Int32Collection MakeTriangles();
    }
}
