﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;
using System.Windows;
using System.Windows.Controls;

namespace VisualizerControl
{
    /// <summary>
    /// Interaction logic for MotionVisualizer.xaml
    /// </summary>
    public partial class MotionVisualizer : UserControl
    {
        private Visualizer visualizer;
        private double time = 0;
        private double timeIncrement = .01; // in seconds
        private double timeScale = 1;
        private bool autoCamera = false;

        private Stopwatch timer = new Stopwatch();
        private IEngine engine;

        private BufferBlock<PackagedCommands> turnBuffer = new BufferBlock<PackagedCommands>();
        private Task engineTask;
        private Task visualizerTask;

        public string BackgroundFile
        {
            set
            {
                visualizer.BackgroundFile = value;
            }
        }

        public MotionVisualizer(IEngine engine)
        {
            InitializeComponent();

            this.engine = engine;

            visualizer = new Visualizer();
            VisualizerSpot.Content = visualizer;

            // Do initial setup
            engine.Initialization().ProcessAll(visualizer);
        }

        public void AddControl(UIElement control)
        {
            ButtonBar.Children.Add(control);
        }

        public bool Display { get; set; } = true;

        public bool IsRunning
        {
            get
            {
                return timer.IsRunning;
            }
            set
            {
                if (value)
                    timer.Start();
                else
                    timer.Stop();
            }
        }

        private void Start_Button_Click(object sender, RoutedEventArgs e)
        {
            if (IsRunning)
            {
                Start_Button.Content = "Resume";
                IsRunning = false;
            }
            else
            {
                Start_Button.Content = "Pause";
                IsRunning = true;

                if (engineTask == null && visualizerTask == null)
                {
                    StartAll();
                }
            }
        }

        private bool doneDrawing = true;

        private class PackagedCommands
        {
            public PackagedCommands(VisualizerCommandSet commands, double time)
            {
                Commands = commands;
                Time = time;
            }

            public VisualizerCommandSet Commands { get; set; }
            public double Time { get; set; }
        }

        private void RunEngine()
        {
            while (engine.Continue)
            {
                if (IsRunning)
                {
                    // This is probably not the best way to do it
                    while (!doneDrawing)
                    { }
                    double newTime = engine.Time + timeIncrement;
                    var package = new PackagedCommands(engine.Tick(newTime), newTime);
                    turnBuffer.Post(package);
                    doneDrawing = false;
                }
            }

            turnBuffer.Complete();
        }

        private async Task UpdateVisualAsync()
        {
            while (await turnBuffer.OutputAvailableAsync())
            {
                var turn = turnBuffer.Receive();
                if (Display)
                {
                    turn.Commands.ProcessAll(visualizer);
                    visualizer.InvalidateVisual();
                }
                time = turn.Time;
                TimeValue.Text = Math.Round(time, 5).ToString();
                if (autoCamera)
                    visualizer.AdjustCamera();

                OnUpdateTriggered(new EventArgs());

                var timeDiff = turn.Time - timer.Elapsed.TotalSeconds * timeScale;
                if (timeDiff > 0)
                {
                    // This delays it so the clocks will line up
                    await Task.Delay((int)(timeDiff * 1000)); // Convert to milliseconds
                }

                doneDrawing = true;
            }
        }

        private void StartAll()
        {
            visualizerTask = UpdateVisualAsync();
            engineTask = Task.Run(() => RunEngine());
        }

        public event EventHandler UpdateTriggered;

        protected virtual void OnUpdateTriggered(EventArgs e)
        {
            UpdateTriggered?.Invoke(this, e);
        }

        private void TimeIncrementSlider_TextChanged(object sender, TextChangedEventArgs e)
        {
            ChangeSlider(TimeIncrementSlider, ref timeIncrement);
        }

        private void ChangeSlider(TextBox textBox, ref double result)
        {
            if (double.TryParse(textBox.Text, out double newNum))
                result = newNum;
        }

        private void AutoCameraCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (AutoCameraCheck.IsChecked != null)
            {
                autoCamera = (bool)AutoCameraCheck.IsChecked;
                if (!timer.IsRunning && autoCamera)
                    visualizer.AdjustCamera();
            }
        }

        private void TimeScaleSlider_TextChanged(object sender, TextChangedEventArgs e)
        {
            ChangeSlider(TimeScaleSlider, ref timeScale);
        }

        private void DisplayCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (DisplayCheck.IsChecked != null)
            {
                Display = (bool)DisplayCheck.IsChecked;
            }
        }
    }
}
