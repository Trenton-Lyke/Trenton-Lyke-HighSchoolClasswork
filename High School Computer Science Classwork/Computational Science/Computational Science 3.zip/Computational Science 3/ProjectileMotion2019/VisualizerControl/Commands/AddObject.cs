﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualizerControl.Commands
{
    /// <summary>
    /// A command to add an object to the visualizer.
    /// This is added by index; it is the user's job to keep track of the indices.
    /// </summary>
    public class AddObject : IVisualizerCommand
    {
        private readonly Object3D obj;
        private readonly int index;

        /// <param name="obj">The Object3D to add</param>
        /// <param name="index">An assigned index, to be used for subsequent commands.  Must be unique.</param>
        public AddObject(Object3D obj, int index)
        {
            this.obj = obj;
            this.index = index;
        }

        public void Do(Visualizer viz)
        {
            viz.AddParticle(obj, index);
        }
    }
}
