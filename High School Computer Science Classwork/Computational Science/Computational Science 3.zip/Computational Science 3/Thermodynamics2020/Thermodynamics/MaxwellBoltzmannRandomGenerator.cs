﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DongUtility;

namespace Thermodynamics
{
    /// <summary>
    /// A random generator that generates particles with a Maxwell-Boltzmann between two endpoints
    /// </summary>
    public class MaxwellBoltzmannRandomGenerator : RandomGenerator
    {
        const double kb = 1.38e-23;
        private readonly double min;
        private readonly double max;

        /// <param name="min">The minimum possible speed</param>
        /// <param name="max">The maximum possible speed</param>
        public MaxwellBoltzmannRandomGenerator(ParticleContainer cont, double min, double max) :
            base(cont)
        {
            this.min = min;
            this.max = max;
        }

        /// <summary>
        /// Gets the speed of a particle based on the Maxwell-Boltzmann distribution
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        override protected double GetSpeed(ParticleInfo info)
        {
            
            double mass = info.Mass;
            const double Temperature = 293.15;
            double avgKE = (double)3 / 2 * kb * Temperature;
            double avgVel = Math.Sqrt(2 * avgKE / mass);



            
            double velocity = 0;
            bool speedFound = false;
            do
            {

                double randomSpeed = RandomGen.NextDouble(0, 3 * avgVel);
                if (GetProbability(mass, randomSpeed, Temperature) > RandomGen.NextDouble())
                {
                    speedFound = true;
                    return randomSpeed;
                }


            } while (!speedFound);
            return velocity;
            

        }
        //Jank Method
        //override protected double GetSpeed(ParticleInfo info)
        //{
            
        //    double mass = info.Mass;
        //    const double Temperature = 293.15;
        //    double avgKE = (double)3 / 2 * kb * Temperature;
        //    double avgVel = Math.Sqrt(2 * avgKE / mass);



            
        //    double velocity = 0;
        //    for (int i = 0; i < 4; i++)
        //    {
        //        double tempVelocity = RandomGen.NextDouble(0, 3* avgVel);
        //        if (GetProbability(mass, tempVelocity, Temperature) >= GetProbability(mass, velocity, Temperature))
        //        {
        //            velocity = tempVelocity;
        //        }


        //    }
        //    return velocity;
        //    //return (new Vector(GetRandomVelocityComponent(kb, Temperature, mass, RandomGen), GetRandomVelocityComponent(kb, Temperature, mass, RandomGen), GetRandomVelocityComponent(kb, Temperature, mass, RandomGen))).Magnitude;


        //} 
        
        //public double GetRandomVelocityComponent(double kb, double Temperature, double mass, Random RandomGen) {
        //    return Math.Sqrt(kb * Temperature / mass) * RandomGen.NextDouble();
        //}
        /// <summary>
        /// Gets the probability of the speed in the Maxwell-Boltzmann distribution
        /// </summary>
        public double GetProbability(double mass, double velocity, double Temperature) {
            return 4 * Math.PI * Math.Pow((mass / (2 * Math.PI * kb * Temperature)), 1.5) * velocity * velocity * Math.Pow(Math.E, -mass * velocity * velocity / (2 * kb * Temperature));

        }
    }
}

