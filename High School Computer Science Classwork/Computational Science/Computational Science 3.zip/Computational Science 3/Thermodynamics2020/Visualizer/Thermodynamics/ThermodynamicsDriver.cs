﻿using DongUtility;
using MotionVisualizerControl;
using System;
using System.Windows.Media;
using Thermodynamics;
using static WPFUtility.UtilityFunctions;

namespace Visualizer.Thermodynamics
{
    class ThermodynamicsDriver
    {
        static internal void Run()
        {
            //values that allowed for reasonable temperature
            const double containerSize = 50;
            const double minSpeed = 0;
            const double maxSpeed = 30;
            const double mass = 4e-23;
            Color color = Colors.Lavender;
            const int nParticles = 1000;
            const double deltaTime = .01;
            const string name = "Molecule";

            var cont = new ParticleContainer(containerSize, containerSize, containerSize);
            var info = new ParticleInfo(name, mass, ConvertColor(color));
            var generator = new MaxwellBoltzmannRandomGenerator(cont, minSpeed, maxSpeed);

            cont.Dictionary.AddParticle(info);

            cont.AddRandomParticles(generator, name, nParticles);

            var visualization = new ThermodynamicsVisualization(cont)
            {
                BoxColor = Colors.IndianRed
            };

            var viz = new MotionVisualizer(visualization)
            {
                TimeIncrement = deltaTime,
                TimeScale = 1
            };

            const int histogramBins = 50;
            
            viz.AddSingleGraph("Temperature", Colors.CornflowerBlue, () => visualization.Time, () => GetTemperature(cont), "Time (s)", "Temperature (K)");

            viz.AddHist(histogramBins, Colors.BlueViolet, () => cont.GetParticlePropertyList((Particle part) => part.Velocity.Magnitude), "Speed (m/s)");
            //viz.AddText("Temperature (K)", Colors.CadetBlue, () => GetTemperature(cont));
            viz.AddSingleGraph("Pressure (N/m^2)", Colors.CornflowerBlue, () => visualization.Time, () => GetPressure(cont), "Time (s)", "Pressure (N/m^2)");
            viz.AddSingleGraph("Volume vs. Temperature", Colors.CornflowerBlue, () => getVolume(cont), () => GetTemperature(cont), "Volume (m^3)", "Temperature (K)");

            viz.AddText("Pressure (N/m^2)", Colors.CadetBlue, () => GetPressure(cont));




            viz.AutoCamera = true;
            viz.AutoCamera = false;
            viz.Show();
        }
        /// <summary>
        /// Gets the temperature of the container
        /// </summary>
        public static double GetTemperature(ParticleContainer cont)
        {
            double kineticEnergySum = 0;
            foreach (Particle particle in cont.Particles)
            {
                kineticEnergySum += particle.KineticEnergy;
            }
            double avgKineticEnergy = kineticEnergySum / cont.Particles.Count;
            double BoltzmannConstant = 1.38 * Math.Pow(10,-23);
            double temperature = (double)2 / 3 * avgKineticEnergy / BoltzmannConstant;
            return temperature;
        }

        /// <summary>
        /// Gets the presssure of the container
        /// </summary>
        public static double GetPressure(ParticleContainer cont)
        {
            double containerSize = cont.Size.X;
            Vector force = new Vector(0,0,0);
            foreach (Particle particle in cont.Particles)
            {
                
                force += particle.Force;
            }
            double pressure = (force / (containerSize * containerSize)).Magnitude;
            

            return pressure;
        }
        public static double getVolume(ParticleContainer cont) {
            return cont.Size.X* cont.Size.Y* cont.Size.Z;
        }
    }
}
