﻿namespace Visualizer
{
    class Driver
    {

        static internal void Run()
        {
            //Kinematics.KinematicsDriver.RunKinematics();
            //FiniteElement.FiniteElementDriver.RunFiniteElement();
            //MarbleMadness.MarbleMadnessDriver.RunMarbleMadness();
            Thermodynamics.ThermodynamicsDriver.Run();
        }



    }

}
