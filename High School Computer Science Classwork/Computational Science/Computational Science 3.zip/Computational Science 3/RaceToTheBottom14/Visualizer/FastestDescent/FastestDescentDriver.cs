﻿using DongUtility;
using MotionVisualizerControl;
using PhysicsUtility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;
using static WPFUtility.UtilityFunctions;

namespace Visualizer.FastestDescent
{
    class FastestDescentDriver
    {
        static internal void RunFastestDescent()
        {
            double[] parameters = new double[] { 0, 0, .1 };
            // You will want to do your optimization here,
            // calling RunOnce() many times
            double time = RunOnce(parameters);

            // If you don't want to display your optimized parameters here,
            // comment this line out.

            VisualizeFastestDescent(parameters);
        }

        static private double RunOnce(params double[] parameters)
        {
            var engine = SetupEngine(parameters);
            const double timeStep = .01;
            const double maxTime = 1000;
            while (engine.Tick(engine.Time + timeStep))
            {
                if (engine.Time > maxTime)
                    return double.MaxValue;
            }
            return engine.Time;
        }

        static private Engine SetupEngine(params double[] parameters)
        {
            const double initial = -10;
            const double final = 0;
            // Initial position is set by the path, so it doesn't need to be set now
            var projectile = new Projectile(Vector.NullVector(), Vector.NullVector(), 1); // The mass does not matter
            var path = new Simple2DQuadratic(initial, final, parameters);
            return new Engine(projectile, path);
        }

        static internal void VisualizeFastestDescent(params double[] parameters)
        {
            var engine = SetupEngine(parameters);

            var visualization = new DescentVisualization(engine)
            {
                PathThickness = .5,
                PathColor = Colors.IndianRed,
                ProjectileSize = 1,
                ProjectileColor = Colors.NavajoWhite
            };

            var fullViz = new MotionVisualizer(visualization);
            //fullViz.BackgroundFile = "stars.jpg";

            fullViz.Add3DGraph("Position", () => engine.Time, () => ConvertVector(engine.Projectile.Position), "Time (s)", "Position (m)");
            fullViz.AddText("Time", Colors.MidnightBlue, () => (Math.Round(engine.Time, 3)).ToString() + " s");

            fullViz.SlowDraw = true;
            fullViz.TimeIncrement = .01;

            fullViz.Show();
        }

        //private static void AddSurfacesToVisualizer(YOURNAMEMarbleMachine surfaces, KinematicsVisualization visualization)
        //{
        //    foreach (var surface in surfaces.Surfaces)
        //        foreach (var triangle in surface.Triangles)
        //        {
        //            visualization.AddTriangle(triangle);
        //        }
        //}

        //private static void AddSurfaces(MarbleMachine surfaces, KinematicsEngine engine)
        //{
        //    var surfaceForce = new SurfaceForce(engine);
        //    foreach (var surface in surfaces.Surfaces)
        //    {
        //        surfaceForce.AddSurface(surface);
        //    }
        //    engine.AddForce(surfaceForce);
        //}

        //static private Vector3D ConvertToVector3D(Vector vec)
        //{
        //    return new Vector3D(vec.X, vec.Y, vec.Z);
        //}

        //static private void AddParticleStructure(ParticleStructure ps, KinematicsEngine engine)
        //{
        //    // Add projectiles
        //    foreach (var projectile in ps.Projectiles)
        //    {
        //        engine.AddProjectile(projectile);
        //    }

        //    // Add connectors
        //    foreach (var connector in ps.Connectors)
        //    {
        //        // Remember to connect it both ways
        //        engine.AddForce(new FiniteElementConnectorForce(connector.Projectile1, connector.Projectile2, connector.SpringConstant, connector.UnstretchedLength));
        //        engine.AddForce(new FiniteElementConnectorForce(connector.Projectile2, connector.Projectile1, connector.SpringConstant, connector.UnstretchedLength));
        //    }
        //}

        //static private void AddConnectorsToVisualizer(ParticleStructure ps, KinematicsVisualization viz)
        //{
        //    foreach (var connector in ps.Connectors)
        //    {
        //        var indices = ps.GetIndexOfProjectiles(connector);
        //        viz.AddTwoParticleConnector(indices.Item1, indices.Item2, ConnectorColor);
        //    }
        //}
    }
}
