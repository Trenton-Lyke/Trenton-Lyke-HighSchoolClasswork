﻿using DecisionTree;
using DongUtility;
using Driver;
using PhysicsUtility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Media;
using Visualizer.FastestDescent;
using static Visualizer.RaceToTheBottom.Engine;
using Path = DongUtility.Path;

namespace Visualizer.RaceToTheBottom
{
    public class YOURNAMEPath : MultiPath
    {
        private const string filePath = @"C:\Computational Science Data\";

        public YOURNAMEPath(int fieldOfView = 2, double minAngle = Math.PI / 45)
        {
            Vector initialPosition = new Vector(0, 0, 101); // You can change the x and y values
                                                            // to be anything you want
                                                            // z has to be 101
            var file = File.OpenText(filePath + "Lyke & Matthews - Project - Level3 Forest (40 Trees) Indexes.txt");

            //sets up data points
            var ds = DataSet.ReadDataSet(filePath + "project3Data.dat");
            var pointList = new List<Vector>();
            foreach (var dataPoint in ds.Points)
            {
                Vector position = new Vector(dataPoint.Variables[0], dataPoint.Variables[1], dataPoint.Variables[2]);
                pointList.Add(position);
            }
            
            
            //creates list of signal points
            List<Vector> signalPointList = new List<Vector>();
            using (file)
            {
                while (!file.EndOfStream)
                {
                    var line = file.ReadLine();
                    if (line.Length == 0)
                        continue;

                    int index = int.Parse(line);

                    signalPointList.Add(pointList[index]);
                }
            }

            //sorts points by Z component of position - added in this class
            signalPointList = MergeSort.mergeSort(signalPointList.ToArray()).OfType<Vector>().ToList();
            
            //length of signal point list - changed manually when list is updated
            int signalPointListLength = signalPointList.Count();

            //minimum depression angle between two adjacent signal points in list
            //double minAngle = Math.PI/45;

            //removes signalPoints based on distance from each other(part of the get angle method) and depression angle
            for (int i = 0; i < signalPointListLength-1; i++)
            {
                double angle = getAngle(signalPointList, ref signalPointListLength, i);
                while (i + 1 < signalPointListLength && angle < minAngle)
                {
                    signalPointList.RemoveAt(i + 1);
                    signalPointListLength = signalPointList.Count();
                    angle = getAngle(signalPointList, ref signalPointListLength, i, fieldOfView);
                }

            }

            //creates path between signal points
            Vector previousPosition = new Vector(signalPointList[0].X, signalPointList[0].Y, 101);
            for (int i = 0; i < signalPointList.Count(); i++)
            {
                var segment = new SimpleLinearPath(previousPosition, signalPointList[i]);
                AddPath(segment);
                previousPosition = signalPointList[i];
            }
            
        }

        //returns the angle between the signal point at index i and the optimal signal point in its field of view (all points between the 
        //signal at index i and the optimal signal point are removed from the list)
        private static double getAngle(List<Vector> signalPointList, ref int signalPointListLength, int i, int fieldOfView=2)
        {
            //caps the field of view if needed
            if (i + fieldOfView > signalPointListLength - 1)
            {
                fieldOfView = (signalPointListLength - 1) - i;
            }

            //finds the optimal point in field of view based on distance
            double smallestMagnitude = double.MaxValue;
            int bestK = 1;
            for (int k = 1; k < fieldOfView; k++)
            {
                Vector distVector = new Vector(Math.Abs(signalPointList[i].X - signalPointList[i + k].X), Math.Abs(signalPointList[i].Y - signalPointList[i + k].Y), Math.Abs(signalPointList[i].Z - signalPointList[i + k].Z));
                if (smallestMagnitude > distVector.Magnitude)
                {
                    smallestMagnitude = distVector.Magnitude;
                    bestK = k;
                }
            }

            //all points between the 
            //signal at index i and the optimal signal point are removed from the list
            for (int k = bestK - 1; k > 0; k--)
            {
                signalPointList.RemoveAt(i + k);
                signalPointListLength = signalPointList.Count();
            }

            //returns the angle between the two signal points
            if (i + 1 < signalPointList.Count())
            {
                Vector bestDistVector = new Vector(Math.Abs(signalPointList[i].X - signalPointList[i + 1].X), Math.Abs(signalPointList[i].Y - signalPointList[i + 1].Y), Math.Abs(signalPointList[i].Z - signalPointList[i + 1].Z));
                double adjacent = Math.Sqrt(bestDistVector.X * bestDistVector.X + bestDistVector.Y * bestDistVector.Y);
                double opposite = bestDistVector.Z;
                double angle = Math.Abs(Math.Atan(opposite / adjacent));
                return angle;
            }
            //returns 0 if there are no more signal points
            else {
                return 0;
            }
        }
      
    }
}
