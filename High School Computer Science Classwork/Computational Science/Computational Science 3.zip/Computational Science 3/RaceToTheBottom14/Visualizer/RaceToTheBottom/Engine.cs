﻿using DongUtility;
using PhysicsUtility;
using static DongUtility.UtilityFunctions;
using System;
using System.Collections.Generic;
using System.Text;
using DecisionTree;
using System.Windows.Media;
using System.IO;
using Path = DongUtility.Path;

namespace Visualizer.RaceToTheBottom
{
    class Engine
    {
        public double Time { get; private set; } = 0;
        


        public class ProjectileAndPath
        {
            public Projectile Projectile { get; }
            public Path Path { get; }
            public double CurrentParameter { get; set; }
            public Vector PreviousPosition { get; set; }
            public Color ProjectileColor { get; }
            public Color PathColor { get; }
            public bool Done { get; set; } = false;
            public int Score { get; set; } = 0;
            public ProjectileAndPath(Projectile projectile, Path path, Color projectileColor, Color pathColor)
            {
                Projectile = projectile;
                Path = path;
                ProjectileColor = projectileColor;
                PathColor = pathColor;
                CurrentParameter = path.InitialParameter;
                PreviousPosition = Projectile.Position;
            }
        }

        public class Point
        {
            public Vector Position { get; }
            public Color Color { get; }
            public bool IsSignal { get; set; } = false;
            public Point(Vector position, Color color)
            {
                Position = position;
                Color = color;
            }
        }

        public List<ProjectileAndPath> Projectiles { get; } = new List<ProjectileAndPath>();
        public List<Point> Points { get; } = new List<Point>();
        public HashSet<Point> RemovedPoints { get; } = new HashSet<Point>();

        public Vector GravitationalFieldStrength { get; set; } = new Vector(0, 0, -9.8);

        public Engine(string filename)
        {
            var dataset = DataSet.ReadDataSet(filename);
            foreach (var dataPoint in dataset.Points)
            {
                Vector position = new Vector(dataPoint.Variables[0], dataPoint.Variables[1], dataPoint.Variables[2]);
                Color color = Color.FromRgb((byte)dataPoint.Variables[3], (byte)dataPoint.Variables[4], (byte)dataPoint.Variables[5]);
                var point = new Point(position, color);
                Points.Add(point);
            }
        }
        

            public void AddSignalList(string filename)
        {
            using var file = File.OpenText(filename);

            while (!file.EndOfStream)
            {
                var line = file.ReadLine();
                if (int.TryParse(line, out int index))
                {
                    if (index >= Points.Count)
                        throw new FileFormatException("Index number too large!");

                    Points[index].IsSignal = true;
                }
                else if (line != null && line.Length > 0)
                {
                    throw new FileFormatException("Error in signal file!");
                }

            }
        }

        public void AddProjectile(Projectile projectile, Path path, Color projectileColor, Color pathColor)
        {
            projectile.Position = path.GetPosition(path.InitialParameter);
            var pAndP = new ProjectileAndPath(projectile, path, projectileColor, pathColor);
            Projectiles.Add(pAndP);
        }

        private const double MinimumDistance = .01;
        private const double MinimumDistanceSquared = MinimumDistance * MinimumDistance;

        public bool Tick(double newTime)
        {
            bool stillGoing = false;
            foreach (var pandp in Projectiles)
            {
                if (pandp.Done)
                    continue;

                stillGoing = true;
                pandp.PreviousPosition = pandp.Projectile.Position;
                bool result = UpdateProjectile(pandp, newTime);

                if (!result)
                    pandp.Done = true;
            }

            RemovedPoints.Clear();

            // Award points
            foreach (var pandp in Projectiles)
            {
                if (pandp.Done)
                    continue;

                Score(pandp);
            }

            // Removed points that were touched
            foreach (var point in RemovedPoints)
            {
                Points.Remove(point);
            }

            Time = newTime;
            return stillGoing;
        }

        /// <summary>
        /// Calculates the score for a ProjectileAndPath object, based on current and past positions
        /// </summary>
        private void Score(ProjectileAndPath pnp)
        {
            Vector direction = pnp.Projectile.Position - pnp.PreviousPosition;
            double distance = direction.Magnitude;
            direction /= distance;

            var alreadyHit = new HashSet<Point>();

            for (double increase = 0; increase < distance; increase += MinimumDistance / 2)
            {
                Vector iPosition = pnp.PreviousPosition + direction * increase;

                foreach (var point in Points)
                {
                    double distance2 = Vector.Distance2(point.Position, iPosition);
                    if (distance2 <= MinimumDistanceSquared && !alreadyHit.Contains(point))
                    {
                        pnp.Score += point.IsSignal ? 1 : -1;
                        RemovedPoints.Add(point);
                        alreadyHit.Add(point);
                    }
                }
            }
        }

        private bool UpdateProjectile(ProjectileAndPath pnp, double newTime)
        {
            var projectile = pnp.Projectile;
            var path = pnp.Path;

            double parameter = pnp.CurrentParameter;

            const double tolerance = 1e-9;

            if (parameter >= path.FinalParameter || Math.Abs(parameter - path.FinalParameter) < tolerance)
                return false;

            Vector tangentDirection = TangentDirection(parameter, path);
            ConstrainPositionAndVelocity(parameter, tangentDirection, projectile, path);
            Vector acceleration = CalculateAcceleration(tangentDirection);

            projectile.AddForce(projectile.Mass * acceleration);
            projectile.Update(newTime - Time);

            pnp.CurrentParameter = UpdateParameter(pnp);

            return true;
        }

        private double UpdateParameter(ProjectileAndPath pnp)
        {
            const double initialChange = .01;

            Vector previousPosition = pnp.Path.GetPosition(pnp.CurrentParameter);
            double previousDistance2 = Vector.Distance2(pnp.Projectile.Position, previousPosition);

            // Estimate the size of the parameter change
            Vector estimatedPosition = pnp.Path.GetPosition(pnp.CurrentParameter + initialChange);
            double estimatedDistance2 = Vector.Distance2(estimatedPosition, pnp.Projectile.Position);
            double parameterChange = initialChange * Math.Sqrt(previousDistance2 / estimatedDistance2) / 10;

            double parameter = pnp.CurrentParameter;
            while (true)
            {
                Vector newPosition = pnp.Path.GetPosition(parameter + parameterChange);
                double newDistance2 = Vector.Distance2(newPosition, previousPosition);
                if (newDistance2 > previousDistance2)
                {
                    break;
                }

                parameter += parameterChange;
                previousDistance2 = newDistance2;
            }

            return parameter;
        }

        //private double GetParameterFromPosition(Vector position, Path path)
        //{
        //    const double factor = 10;
        //    const double tolerance = 1e-6;
        //    double spacing = (path.FinalParameter - path.InitialParameter) / factor;

        //    double initialValue = path.InitialParameter;
        //    double finalValue = path.FinalParameter;

        //    double finalParam = 0;
        //    while (spacing > tolerance)
        //    {
        //        finalParam = FindMinimum(position, spacing, initialValue, finalValue, path);
        //        initialValue = finalParam - spacing;
        //        finalValue = finalParam + spacing;
        //        // Keep these in bounds
        //        if (initialValue < path.InitialParameter)
        //            initialValue = path.InitialParameter;
        //        if (finalValue > path.FinalParameter)
        //            finalValue = path.FinalParameter;
        //        spacing /= factor;
        //    }

        //    return finalParam;
        //}

        private double FindMinimum(Vector position, double spacing, double initialValue, double finalValue,
            DongUtility.Path path)
        {
            double minimumDistance = double.MaxValue;
            double bestParameter = double.MaxValue;

            for (double iparm = initialValue; iparm <= finalValue; iparm += spacing)
            {
                Vector positionTry = path.GetPosition(iparm);
                double distance2 = Vector.Distance2(positionTry, position);
                if (distance2 < minimumDistance)
                {
                    minimumDistance = distance2;
                    bestParameter = iparm;
                }
            }

            return bestParameter;
        }

        private Vector TangentDirection(double param, Path path)
        {
            Vector currentPosition = path.GetPosition(param);
            Vector nextPosition = path.GetPosition(param + path.MinimumStep);
            return nextPosition - currentPosition;
        }

        private void ConstrainPositionAndVelocity(double parameter, Vector tangentDirection,
            Projectile projectile, Path path)
        {
            projectile.Position = path.GetPosition(parameter);
            projectile.Velocity = projectile.Velocity.ProjectOnto(tangentDirection);
        }

        private Vector CalculateAcceleration(Vector tangentDirection)
        {
            return GravitationalFieldStrength.ProjectOnto(tangentDirection);
        }
    }
}
