﻿using DongUtility;
using MotionVisualizerControl;
using PhysicsUtility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Media;
using Visualizer.FastestDescent;
using static WPFUtility.UtilityFunctions;
using Path = DongUtility.Path;

namespace Visualizer.RaceToTheBottom

{
    class RaceToTheBottomDriver
    {
        private const string filePath = @"C:\Computational Science Data\";
        static internal void Run()
        {
            double[] parameters = new double[] { 0, 0, .1 };
            // You will want to do your optimization here,
            // calling RunOnce() many times
            //double time = RunOnce(parameters);

            // If you don't want to display your optimized parameters here,
            // comment this line out.

            VisualizeFastestDescent(parameters);
        }

        static private double RunOnce(params double[] parameters)
        {
            var engine = SetupEngine(parameters);
            const double timeStep = .01;
            const double maxTime = 1000;
            while (engine.Tick(engine.Time + timeStep))
            {
                if (engine.Time > maxTime)
                    return double.MaxValue;
            }
            return engine.Time;
        }

        static private Engine SetupEngine(params double[] parameters)
        {        
            var projectile = new Projectile(Vector.NullVector(), Vector.NullVector(), 1); // The mass does not matter

            var engine = new Engine(filePath + "project3Data.dat");
            engine.AddSignalList(filePath + "Lyke & Matthews - Project - Level3 Forest (40 Trees) Indexes.txt");

            var particlePath = new YOURNAMEPath();
            //engine.AddProjectile(projectile, particlePath, Colors.IndianRed, Colors.NavajoWhite);
            engine.AddProjectile(new Projectile(Vector.NullVector(), Vector.NullVector(), 1), new YOURNAMEPath(0,0), Colors.Yellow, Colors.Green);
            engine.AddProjectile(new Projectile(Vector.NullVector(), Vector.NullVector(), 1), new YOURNAMEPath(), Colors.IndianRed, Colors.NavajoWhite);
            engine.AddProjectile(new Projectile(Vector.NullVector(), Vector.NullVector(), 1), new YOURNAMEPath(40), Colors.Blue, Colors.Pink);
            return engine;
        }

        static internal void VisualizeFastestDescent(params double[] parameters)
        {
            var engine = SetupEngine(parameters);

            var visualization = new RaceToTheBottomVisualization(engine)
            {
                PathThickness = .5,
                ProjectileSize = 1,
            };

            var fullViz = new MotionVisualizer(visualization);
            //fullViz.BackgroundFile = "stars.jpg";

            fullViz.AddText("Score0", Colors.MediumOrchid, () => engine.Projectiles[0].Score.ToString());
            fullViz.AddText("Score1", Colors.MediumOrchid, () => engine.Projectiles[1].Score.ToString());
            fullViz.AddText("Score2", Colors.MediumOrchid, () => engine.Projectiles[2].Score.ToString());
            fullViz.AddText("Time", Colors.MidnightBlue, () => (Math.Round(engine.Time, 3)).ToString() + " s");

            fullViz.SlowDraw = true;
            fullViz.TimeIncrement = .01;
            fullViz.AutoCamera = true;
            fullViz.AutoCamera = false;
            fullViz.Show();
        }

        //private static void AddSurfacesToVisualizer(YOURNAMEMarbleMachine surfaces, KinematicsVisualization visualization)
        //{
        //    foreach (var surface in surfaces.Surfaces)
        //        foreach (var triangle in surface.Triangles)
        //        {
        //            visualization.AddTriangle(triangle);
        //        }
        //}

        //private static void AddSurfaces(MarbleMachine surfaces, KinematicsEngine engine)
        //{
        //    var surfaceForce = new SurfaceForce(engine);
        //    foreach (var surface in surfaces.Surfaces)
        //    {
        //        surfaceForce.AddSurface(surface);
        //    }
        //    engine.AddForce(surfaceForce);
        //}

        //static private Vector3D ConvertToVector3D(Vector vec)
        //{
        //    return new Vector3D(vec.X, vec.Y, vec.Z);
        //}

        //static private void AddParticleStructure(ParticleStructure ps, KinematicsEngine engine)
        //{
        //    // Add projectiles
        //    foreach (var projectile in ps.Projectiles)
        //    {
        //        engine.AddProjectile(projectile);
        //    }

        //    // Add connectors
        //    foreach (var connector in ps.Connectors)
        //    {
        //        // Remember to connect it both ways
        //        engine.AddForce(new FiniteElementConnectorForce(connector.Projectile1, connector.Projectile2, connector.SpringConstant, connector.UnstretchedLength));
        //        engine.AddForce(new FiniteElementConnectorForce(connector.Projectile2, connector.Projectile1, connector.SpringConstant, connector.UnstretchedLength));
        //    }
        //}

        //static private void AddConnectorsToVisualizer(ParticleStructure ps, KinematicsVisualization viz)
        //{
        //    foreach (var connector in ps.Connectors)
        //    {
        //        var indices = ps.GetIndexOfProjectiles(connector);
        //        viz.AddTwoParticleConnector(indices.Item1, indices.Item2, ConnectorColor);
        //    }
        //}
    }
}
