﻿using DongUtility;
using System;
using System.Collections.Generic;
using System.Text;
using Visualizer.RaceToTheBottom;
using static DongUtility.UtilityFunctions;

namespace Visualizer.FastestDescent
{
    class Simple3DQuadratic : SimplePath
    {
        private double baseParameters;
        public override double InitialParameter => 0;

        public override double FinalParameter => 1;

        public Vector point1;

        public Vector point2;

        public double parameterDistance;
        public double[][] parameters = new double[2][];
        public Simple3DQuadratic(Vector point1, Vector point2, double[] aValues):
            base(point1, point2)
        {
            this.point1 = point1;
            this.point2 = point2;
            this.baseParameters = baseParameters;
            parameterDistance = Math.Abs(point1.X - point2.X);
            parameters[0] = getCoefficients(aValues[0], point1.X, point2.X, point1.Y, point2.Y);
            parameters[1] = getCoefficients(aValues[1], point1.X, point2.X, point1.Z, point2.Z);

        }
       

        //a function where the y nad y a quadratically related to t in a 3d space
        protected override Vector Function(double parameter)
        {
            double modifiedParameter = Point1.X + parameterDistance * parameter;
            double y = parameters[0][0] + parameters[0][1] * modifiedParameter + parameters[0][2] * Square(modifiedParameter);
            double z = parameters[1][0] + parameters[1][1] * modifiedParameter + parameters[1][2] * Square(modifiedParameter);
            return new Vector(modifiedParameter, y, z);
        }

        public double[] getCoefficients(double a, double input1, double input2, double output1, double output2) {
            double b = (output2 - a * input2 * input2 - output1 + a * input1 * input1) / (input2 - input1);
            double c = output1 - a * input1 * input1 - input1*((output2 - a * input2 * input2 - output1 + a * input1 * input1) / (input2 - input1));
            return new double[] { c, b, a };
            
        }
        
    }
}
