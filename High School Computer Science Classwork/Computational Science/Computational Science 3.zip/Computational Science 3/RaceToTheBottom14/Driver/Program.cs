﻿using System;

namespace Driver
{
    class Program
    {
        static void Main(string[] args)
        {
            //var generator = new YOURNAMESGenerator();

            //// Create one signal event
            //var sigEvent = generator.MakePoint(true);

            //// Create one background event
            //var backEvent = generator.MakePoint(false);

            //// Create a small dataset
            //var set = generator.MakeDataSet(100, .5);
            
        }
    }
}
