﻿using PointGenerator;
using System;
using DongUtility;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Driver
{
    class YOURNAMESGenerator : Generator
    {
        protected override PointGenerator.Point CreatePoint(bool signal)
        {
            if (signal)
            {
                double x = Random.NextDouble(0, 100);
                double y = Random.NextDouble(0, 100);
                double z = Random.NextDouble(0, 100);

                int r = Random.Next(0, Constants.MaxByte + 1);
                int g = Random.Next(0, Constants.MaxByte + 1);
                int b = Random.Next(0, Constants.MaxByte + 1);

                return new PointGenerator.Point(new Vector(x, y, z), Color.FromArgb(r, g, b));
            }
            else
            {
                double x = Random.NextDouble(0, 100);
                double y = Random.NextDouble(0, 100);
                double z = Random.NextDouble(0, 100);

                int r = Random.Next(0, Constants.MaxByte + 1);
                int g = Random.Next(0, Constants.MaxByte + 1);
                int b = Random.Next(0, Constants.MaxByte + 1);

                return new PointGenerator.Point(new Vector(x, y, z), Color.FromArgb(r, g, b));
            }
        }
    }
}
