﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DongUtility
{
    public static class Shapes
    {
        public enum Shapes3D { Sphere, Cube, Cylinder };
    }
}
