﻿using Arena;
using HungerGames.Animals;
using HungerGames.Turns;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HungerGames.Interface
{
    abstract public class LynxIntelligence : AnimalIntelligence
    {
    }
}
