﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DongUtility;
using HungerGames.Animals;
using HungerGamesCore.Interface;

namespace HungerGames.Interface
{
    public class ChooserDefault : LocationChooserTemplateIntermediate<HareIntelligenceDefault, LynxIntelligenceDefault>
    {
        private static readonly string path = @"C:\Computational Science Data\";
        private Vector2D[] harePostionArray = new Vector2D[100];
        private int lastUsedHairIndex = 0;
        
        protected override Vector2D UserDefinedChooseLocation(VisibleArena arena, bool hare, int organismNumber)
        {
            // Fill in your decision algorithm here.
            // The organismNumber variable counts from 0 to the total number of organisms.  This can be useful for
            // spreading your organisms out a bit

            if (hare)
            {

                harePostionArray[organismNumber] = RandomLocation(arena,hare);

                return harePostionArray[organismNumber];
            }
            else
            {
                int i = lastUsedHairIndex+1;
                for (; i < harePostionArray.Length; i++) {
                    Vector2D lynxPosition = harePostionArray[i] + (new Vector2D(.5, .5));
                    bool isValidPoint = arena.TestPoint(lynxPosition);
                    if(isValidPoint) {
                        lastUsedHairIndex = i;
                        return lynxPosition;
                    }
                }
                lastUsedHairIndex=i;
                return RandomLocation(arena,hare);

            }
        }
    }
    public class ChooserDefault2 : LocationChooserTemplateIntermediate<HareIntelligenceDefault2, LynxIntelligenceDefault2>//<HareIntelligenceTrentonFinalBest2, LynxIntelligenceTrentonFinalOld>
    {
        private static readonly string path = @"C:\Computational Science Data\";
        private Vector2D[] harePostionArray = new Vector2D[100];
        private int lastUsedHairIndex = 0;

        protected override Vector2D UserDefinedChooseLocation(VisibleArena arena, bool hare, int organismNumber)
        {
            // Fill in your decision algorithm here.
            // The organismNumber variable counts from 0 to the total number of organisms.  This can be useful for
            // spreading your organisms out a bit

            if (hare)
            {

                harePostionArray[organismNumber] = RandomLocation(arena, hare);

                return harePostionArray[organismNumber];
            }
            else
            {
                int i = lastUsedHairIndex + 1;
                for (; i < harePostionArray.Length; i++)
                {
                    Vector2D lynxPosition = harePostionArray[i] + (new Vector2D(.5, .5));
                    bool isValidPoint = arena.TestPoint(lynxPosition);
                    if (isValidPoint)
                    {
                        lastUsedHairIndex = i;
                        return lynxPosition;
                    }
                }
                lastUsedHairIndex = i;
                return RandomLocation(arena, hare);

            }
        }
    }
    public class ChooserDefault3 : LocationChooserTemplateIntermediate<HareIntelligenceDefault3, LynxIntelligenceDefault3>
    {
        private static readonly string path = @"C:\Computational Science Data\";
        private Vector2D[] harePostionArray = new Vector2D[100];
        private int lastUsedHairIndex = 0;

        protected override Vector2D UserDefinedChooseLocation(VisibleArena arena, bool hare, int organismNumber)
        {
            // Fill in your decision algorithm here.
            // The organismNumber variable counts from 0 to the total number of organisms.  This can be useful for
            // spreading your organisms out a bit

            if (hare)
            {

                harePostionArray[organismNumber] = RandomLocation(arena, hare);

                return harePostionArray[organismNumber];
            }
            else
            {
                int i = lastUsedHairIndex + 1;
                for (; i < harePostionArray.Length; i++)
                {
                    Vector2D lynxPosition = harePostionArray[i] + (new Vector2D(.5, .5));
                    bool isValidPoint = arena.TestPoint(lynxPosition);
                    if (isValidPoint)
                    {
                        lastUsedHairIndex = i;
                        return lynxPosition;
                    }
                }
                lastUsedHairIndex = i;
                return RandomLocation(arena, hare);

            }
        }
    }
    public class ChooserDefault4 : LocationChooserTemplateIntermediate<HareIntelligenceDefault4, LynxIntelligenceDefault4>
    {
        private static readonly string path = @"C:\Computational Science Data\";
        private Vector2D[] harePostionArray = new Vector2D[100];
        private int lastUsedHairIndex = 0;

        protected override Vector2D UserDefinedChooseLocation(VisibleArena arena, bool hare, int organismNumber)
        {
            // Fill in your decision algorithm here.
            // The organismNumber variable counts from 0 to the total number of organisms.  This can be useful for
            // spreading your organisms out a bit

            if (hare)
            {

                harePostionArray[organismNumber] = RandomLocation(arena, hare);

                return harePostionArray[organismNumber];
            }
            else
            {
                int i = lastUsedHairIndex + 1;
                for (; i < harePostionArray.Length; i++)
                {
                    Vector2D lynxPosition = harePostionArray[i] + (new Vector2D(.5, .5));
                    bool isValidPoint = arena.TestPoint(lynxPosition);
                    if (isValidPoint)
                    {
                        lastUsedHairIndex = i;
                        return lynxPosition;
                    }
                }
                lastUsedHairIndex = i;
                return RandomLocation(arena, hare);

            }
        }
    }
    public class ChooserDefault5 : LocationChooserTemplateIntermediate<HareIntelligenceDefault5, LynxIntelligenceDefault5>
    {
        private static readonly string path = @"C:\Computational Science Data\";
        private Vector2D[] harePostionArray = new Vector2D[100];
        private int lastUsedHairIndex = 0;

        protected override Vector2D UserDefinedChooseLocation(VisibleArena arena, bool hare, int organismNumber)
        {
            // Fill in your decision algorithm here.
            // The organismNumber variable counts from 0 to the total number of organisms.  This can be useful for
            // spreading your organisms out a bit

            
                return RandomLocation(arena, hare);

            
        }
    }
}
