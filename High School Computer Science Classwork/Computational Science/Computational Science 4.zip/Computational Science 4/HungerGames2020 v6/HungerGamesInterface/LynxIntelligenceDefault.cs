﻿using Arena;
using DongUtility;
using HungerGamesCore.Interface;
using HungerGamesCore.Terrain;
using HungerGamesInterface;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace HungerGames.Interface
{
    public class LynxIntelligenceDefault : LynxIntelligence
    {
        public override Color Color { get { return Color.Thistle; } }
        public override string Name { get { return "Default Lynx"; } }
        public override string BitmapFilename { get { return "lynx.png"; } }
        public TrentonLykePerceptron Perceptron { get; set; } = new TrentonLykePerceptron(36, new int[] { 6}, 2);
        private Vector2D previousPosition;
        private int turnNumber = 0;
        private int myHareSpecies;
        public override Turn ChooseTurn()
        {
            List<VisibleObstacle> obstacles = GetOrderedObsticles();
            //if (turnNumber == 0)
            //{
            //    IEnumerable<VisibleAnimal> sortedAnimals = GetAnimalsSorted();
            //    foreach (VisibleAnimal animal in sortedAnimals)
            //    {
            //        Vector2D val = Position - animal.Position;
            //        Console.WriteLine(val);
            //        if (!animal.IsLynx && animal.Velocity == Vector2D.NullVector() && Position - animal.Position == new Vector2D(.5, .5))
            //        {
            //            myHareSpecies = animal.Species;

            //            break;
            //        }
            //    }
            //    previousPosition = Position;
            //    turnNumber++;
            //    return ChangeVelocity(Vector2D.PolarVector(0, 0));
            //}
            //var animals = GetAnimalsSorted().ToList();
            //if (animals.Count > 0)
            //{
            //    foreach (var ani in animals)
            //    {
            //        if (!ani.IsLynx)
            //        {
            //            Vector2D direction = ani.Position - Position;
            //            return ChangeVelocity(direction.UnitVector() * 4);
            //        }
            //    }
            //}

            //return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
            double standardDeviation = 100;
            var animals = GetAnimalsSorted().ToList();
            if (previousPosition == Position)
            {
                Perceptron.RandomWeightsAbsolute(standardDeviation);
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && ani.Species!=myHareSpecies)
                    {
                        previousPosition = Position;
                        var acceleration = Vector2D.PolarVector(15, Random.NextDouble(0, 2 * Math.PI));
                        return ChangeVelocity(acceleration);
                    }
                }
            }
            
            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && ani.Species != myHareSpecies)
                    {

                        previousPosition = Position;
                        Vector2D displacementVector = ani.Position - Position;
                        Vector2D accelerationVector = RunPerceptron(ani,obstacles[0]).UnitVector() * 15;
                        if (Math.Sign(accelerationVector.X) == Math.Sign(displacementVector.X) && Math.Sign(accelerationVector.Y) == Math.Sign(displacementVector.Y))
                            {
                                return ChangeVelocity(-Velocity + accelerationVector);
                            }
                            else
                            {
                                Perceptron.RandomWeightsAbsolute(standardDeviation);

                            }
                        
                        return ChangeVelocity(-Velocity+RunPerceptron(ani, obstacles[0]));
                    }
                }
            }
            previousPosition = Position;
            return ChangeVelocity(Vector2D.PolarVector(10, Random.NextDouble(0, 2 * Math.PI)));
         
        }

        //gets the acceleration based on the perceptron
        private Vector2D RunPerceptron(VisibleAnimal Other, VisibleObstacle obstacle)
        {
            Perceptron.Reset();

            Perceptron.AddInput(0, (Other.Position.X - Position.X));
            Perceptron.AddInput(1, (Other.Position.Y - Position.Y));

            Perceptron.AddInput(2, Other.Velocity.X);




            Perceptron.AddInput(3, Other.Velocity.Y);

            Perceptron.AddInput(4, Other.Velocity.Y - Velocity.Y);
            Perceptron.AddInput(5, Other.Velocity.X - Velocity.X);
            Perceptron.AddInput(6, (obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0);
            Perceptron.AddInput(7, (obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1);
            Perceptron.AddInput(8, (ArenaWidth - Position.X));
            Perceptron.AddInput(9, (ArenaHeight - Position.Y));
            Perceptron.AddInput(10, (Position.Y));
            Perceptron.AddInput(11, (Position.Y));
            Perceptron.AddInput(12, (ArenaWidth - Other.Position.X));
            Perceptron.AddInput(13, (ArenaHeight - Other.Position.Y));
            Perceptron.AddInput(14, (Other.Position.Y));
            Perceptron.AddInput(15, (Other.Position.Y));
            Perceptron.AddInput(16, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) *(obstacle.Position.X - Position.X));
            Perceptron.AddInput(17, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) *(obstacle.Position.Y - Position.Y));
            Perceptron.AddInput(18, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) *(obstacle.Position.X - Other.Position.X));
            Perceptron.AddInput(19, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) *(obstacle.Position.Y - Other.Position.Y));
            Perceptron.AddInput(20, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.X - Position.X));
            Perceptron.AddInput(21, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.Y - Position.Y));
            Perceptron.AddInput(22, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.X - Other.Position.X));
            Perceptron.AddInput(23, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.Y - Other.Position.Y));
            Perceptron.AddInput(24, Stamina);
            Perceptron.AddInput(25, isOnEdge(Position) ? 1 : 0);
            Perceptron.AddInput(26, isOnEdge(Position) ? 0 : 1);
            Perceptron.AddInput(27, isInObstacle(obstacle) ? 1 : 0);
            Perceptron.AddInput(28, isInObstacle(obstacle) ? 0 : 1);
            Perceptron.AddInput(29, isInObstacle(obstacle) ? 0 : 1);
            Perceptron.AddInput(30, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (obstacle.Position - Position).InPolar().Y);
            Perceptron.AddInput(31, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (Other.Position - Position).InPolar().Y);
            Perceptron.AddInput(32, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * ((obstacle.Position - Position).InPolar().Y- (Other.Position-Position).InPolar().Y));
            Perceptron.AddInput(33, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position - Position).InPolar().Y);
            Perceptron.AddInput(34, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (Other.Position - Position).InPolar().Y);
            Perceptron.AddInput(35, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * ((obstacle.Position - Position).InPolar().Y - (Other.Position - Position).InPolar().Y));

            Perceptron.Run();

            double x = Perceptron.GetOutput(0);
            double y = Perceptron.GetOutput(1);

            Vector2D accelerationVector = new Vector2D(x, y);
            return accelerationVector;


        }
        private List<VisibleObstacle> GetOrderedObsticles()
        {
            return GetObstacles<Obstacle>().OrderBy(o => Vector2D.Distance2(o.Position, Position)).ToList();


        }
        bool isInObstacle(VisibleObstacle obstacle)
        {
            DongUtility.Rectangle obstacleRectange = obstacle.Size;
            return (obstacleRectange.MaxY > Position.Y && obstacleRectange.MaxX > Position.X && obstacleRectange.MinY < Position.Y && obstacleRectange.MinX < Position.X);
        }
        private bool isOnEdge(VisibleAnimal animal)
        {
            Vector2D aniPos = animal.Position;
            return isOnEdge(aniPos);
        }
        private bool isOnEdge(Vector2D aniPos)
        {

            return aniPos.X >= 0 && aniPos.X <= .5 || aniPos.Y >= 0 && aniPos.Y <= .5 || aniPos.X <= ArenaWidth && aniPos.X >= ArenaWidth - .5 || aniPos.Y <= ArenaHeight && aniPos.Y >= ArenaHeight - .5;
        }
    }
    public class LynxIntelligenceDefault2 : LynxIntelligence
    {
        public override Color Color { get { return Color.HotPink; } }
        public override string Name { get { return "Default2 Lynx"; } }
        public override string BitmapFilename { get { return "lynx2.jpg"; } }

        private Vector2D previousPosition;
        private int turnNumber = 0;
        //change back later
        private int myHareSpecies=0;
        public override Turn ChooseTurn()
        {
            if (turnNumber == 0)
            {
                IEnumerable<VisibleAnimal> sortedAnimals = GetAnimalsSorted();
                foreach (VisibleAnimal animal in sortedAnimals)
                {
                    Vector2D val = Position - animal.Position;
                    Console.WriteLine(val);
                    if (!animal.IsLynx && animal.Velocity == Vector2D.NullVector() && Position - animal.Position == new Vector2D(.5, .5))
                    {
                        myHareSpecies = animal.Species;

                        break;
                    }
                }
                previousPosition = Position;
                turnNumber++;
                return ChangeVelocity(Vector2D.PolarVector(0, 0));
            }
            if (previousPosition == Position)
            {
                Vector2D newVelocity = -Velocity.UnitVector() * 4;
                double y = newVelocity.Y != 0 ? newVelocity.Y : Random.NextDouble() * 4 - 2;
                double x = newVelocity.X != 0 ? newVelocity.X : Random.NextDouble() * 4 - 2;
                previousPosition = Position;
                turnNumber++;
                return ChangeVelocity(Vector2D.PolarVector(15, Math.Atan2(y, x)));
            }
            var animals = GetAnimalsSorted().ToList();
            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && ani.Species!=myHareSpecies)
                    {
                        Vector2D direction = ani.Position - Position;
                        return ChangeVelocity(direction.UnitVector() * 12);
                    }
                }
            }

            return ChangeVelocity(Vector2D.PolarVector(10, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
    public class LynxIntelligenceDefault3 : LynxIntelligence
    {
        public override Color Color { get { return Color.Orange; } }
        public override string Name { get { return "Default3 Lynx"; } }
        public override string BitmapFilename { get { return "lynx3.jpg"; } }

        private Vector2D previousPosition;
        private int turnNumber = 0;
        private int myHareSpecies;
        public override Turn ChooseTurn()
        {
            //if (turnNumber == 0)
            //{
            //    IEnumerable<VisibleAnimal> sortedAnimals = GetAnimalsSorted();
            //    foreach (VisibleAnimal animal in sortedAnimals)
            //    {
            //        Vector2D val = Position - animal.Position;
            //        Console.WriteLine(val);
            //        if (!animal.IsLynx && animal.Velocity == Vector2D.NullVector() && Position - animal.Position == new Vector2D(.5, .5))
            //        {
            //            myHareSpecies = animal.Species;

            //            break;
            //        }
            //    }
            //    previousPosition = Position;
            //    turnNumber++;
            //    return ChangeVelocity(Vector2D.PolarVector(0, 0));
            //}
            if (previousPosition == Position)
            {
                Vector2D newVelocity = -Velocity.UnitVector() * 4;
                double y = newVelocity.Y != 0 ? newVelocity.Y : Random.NextDouble() * 4 - 2;
                double x = newVelocity.X != 0 ? newVelocity.X : Random.NextDouble() * 4 - 2;
                previousPosition = Position;
                turnNumber++;
                return ChangeVelocity(Vector2D.PolarVector(12, Math.Atan2(y, x)));
            }
            var animals = GetAnimalsSorted().ToList();
            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && ani.Species != myHareSpecies)
                    {
                        Vector2D direction = ani.Position - Position;
                        return ChangeVelocity(direction.UnitVector() * 12);
                    }
                }
            }

            return ChangeVelocity(Vector2D.PolarVector(12, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
    public class LynxIntelligenceDefault4 : LynxIntelligence
    {
        public override Color Color { get { return Color.Cyan; } }
        public override string Name { get { return "Default Lynx4"; } }
        public override string BitmapFilename { get { return "lynx4.jpg"; } }
        public TrentonLykePerceptron Perceptron { get; set; } = new TrentonLykePerceptron(6, new int[] { 4,3 }, 2);
        private Vector2D previousPosition;
        private int turnNumber = 0;
        private int myHareSpecies;
        public override Turn ChooseTurn()
        {
            //if (turnNumber == 0)
            //{
            //    IEnumerable<VisibleAnimal> sortedAnimals = GetAnimalsSorted();
            //    foreach (VisibleAnimal animal in sortedAnimals)
            //    {
            //        Vector2D val = Position - animal.Position;
            //        Console.WriteLine(val);
            //        if (!animal.IsLynx && animal.Velocity == Vector2D.NullVector() && Position - animal.Position == new Vector2D(.5, .5))
            //        {
            //            myHareSpecies = animal.Species;

            //            break;
            //        }
            //    }
            //    previousPosition = Position;
            //    turnNumber++;
            //    return ChangeVelocity(Vector2D.PolarVector(0, 0));
            //}
            //var animals = GetAnimalsSorted().ToList();
            //if (animals.Count > 0)
            //{
            //    foreach (var ani in animals)
            //    {
            //        if (!ani.IsLynx)
            //        {
            //            Vector2D direction = ani.Position - Position;
            //            return ChangeVelocity(direction.UnitVector() * 4);
            //        }
            //    }
            //}

            //return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
            double standardDeviation = 100;
            var animals = GetAnimalsSorted().ToList();
            if (previousPosition == Position)
            {
                Perceptron.RandomWeightsAbsolute(standardDeviation);
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && ani.Species != myHareSpecies)
                    {
                        previousPosition = Position;
                        return ChangeVelocity(Vector2D.PolarVector(15, Random.NextDouble(0, 2 * Math.PI)));
                    }
                }
            }

            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx)
                    {

                        previousPosition = Position;
                        Vector2D displacementVector = ani.Position - Position;
                        Vector2D accelerationVector = RunPerceptron(ani).UnitVector() * 15;
                        if (Math.Sign(accelerationVector.X) == Math.Sign(displacementVector.X) && Math.Sign(accelerationVector.Y) == Math.Sign(displacementVector.Y))
                        {
                            return ChangeVelocity(accelerationVector);
                        }
                        else
                        {
                            Perceptron.RandomWeightsAbsolute(standardDeviation);
                            return ChangeVelocity(RunPerceptron(ani).UnitVector() * 15);
                        }
                    }
                }
            }
            previousPosition = Position;
            return ChangeVelocity(Vector2D.PolarVector(15, Random.NextDouble(0, 2 * Math.PI)));

        }

        //gets the acceleration based on the perceptron
        private Vector2D RunPerceptron(VisibleAnimal Other)
        {
            Perceptron.Reset();

            Perceptron.AddInput(0, (Other.Position.X - Position.X));
            Perceptron.AddInput(1, (Other.Position.Y - Position.Y));

            Perceptron.AddInput(2, Other.Velocity.X);




            Perceptron.AddInput(3, Other.Velocity.Y);

            Perceptron.AddInput(4, Other.Velocity.Y - Velocity.Y);
            Perceptron.AddInput(5, Other.Velocity.X - Velocity.X);


            Perceptron.Run();

            double x = Perceptron.GetOutput(0);
            double y = Perceptron.GetOutput(1);

            Vector2D accelerationVector = new Vector2D(x, y);
            return accelerationVector;


        }
    }
    public class LynxIntelligenceDefault5 : LynxIntelligence
    {
        public override Color Color { get { return Color.Beige; } }
        public override string Name { get { return "Default5 Lynx"; } }
        public override string BitmapFilename { get { return "lynx5.jpg"; } }

        
        public override Turn ChooseTurn()
        {
            
            
            var animals = GetAnimalsSorted().ToList();
            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx)
                    {
                        Vector2D direction = ani.Position - Position;
                        return ChangeVelocity(direction.UnitVector() * 20);
                    }
                }
            }

            return ChangeVelocity(Vector2D.PolarVector(10, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
}
