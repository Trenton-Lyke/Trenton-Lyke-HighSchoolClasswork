﻿using Arena;
using DongUtility;
using HungerGamesCore.Interface;
using HungerGamesCore.Terrain;
using HungerGamesInterface;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace HungerGames.Interface
{
    public class HareIntelligenceDefault : HareIntelligence
    {
        public override Color Color { get { return Color.Yellow; } }
        public override string Name { get { return "Default Hare"; } }
        public override string BitmapFilename { get { return "rabbit.jpg"; } }

        public TrentonLykePerceptron Perceptron { get; set; } = new TrentonLykePerceptron(36, new int[] { 6 }, 2);
        private Vector2D previousPosition;
        private int turnNumber = 0;
        private int myHareSpecies;
        
        public override Turn ChooseTurn()
        {
            List<VisibleObstacle> obstacles = GetOrderedObsticles();
            //if (turnNumber == 0)
            //{
                
            //    previousPosition = Position;
            //    turnNumber++;
            //    return ChangeVelocity(Vector2D.PolarVector(0, 0));
            //}
            //var animals = GetAnimalsSorted().ToList();
            //if (animals.Count > 0)
            //{
            //    foreach (var ani in animals)
            //    {
            //        if (!ani.IsLynx)
            //        {
            //            Vector2D direction = ani.Position - Position;
            //            return ChangeVelocity(direction.UnitVector() * 4);
            //        }
            //    }
            //}

            //return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
            double standardDeviation = 100;
            var animals = GetAnimalsSorted().ToList();
            if (previousPosition == Position)
            {
                Perceptron.RandomWeightsAbsolute(standardDeviation);
                foreach (var ani in animals)
                {
                    if (ani.IsLynx )
                    {
                        previousPosition = Position;
                        return ChangeVelocity(RunPerceptron(ani, obstacles[0]).UnitVector()*7);
                    }
                }
            }

            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (ani.IsLynx)
                    {

                        previousPosition = Position;
                        
                            Vector2D displacementVector = ani.Position - Position;
                            Vector2D accelerationVector = RunPerceptron(ani, obstacles[0]).UnitVector() * 8;
                            if (Math.Sign(accelerationVector.X) == Math.Sign(displacementVector.X) || Math.Sign(accelerationVector.Y) == Math.Sign(displacementVector.Y))
                            {
                                Perceptron.RandomWeightsAbsolute(standardDeviation);
                                

                            }
                            else
                            {
                                return ChangeVelocity(-Velocity+accelerationVector);
                            }

                        
                        return ChangeVelocity(-Velocity+RunPerceptron(ani, obstacles[0]));
                    }
                }
            }
            previousPosition = Position;
            return ChangeVelocity(Vector2D.PolarVector(8, Random.NextDouble(0, 2 * Math.PI)));

        }

        //gets the acceleration based on the perceptron
        private Vector2D RunPerceptron(VisibleAnimal Other, VisibleObstacle obstacle)
        {
            Perceptron.Reset();

            Perceptron.AddInput(0, ( Position.X- Other.Position.X));
            Perceptron.AddInput(1, ( Position.Y- Other.Position.X));

            Perceptron.AddInput(2, Other.Velocity.X);




            Perceptron.AddInput(3, Other.Velocity.Y);

            Perceptron.AddInput(4, Velocity.Y-Other.Velocity.Y  );
            Perceptron.AddInput(5, Velocity.X-Other.Velocity.X );
            Perceptron.AddInput(6, (obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1:0);
            Perceptron.AddInput(7, (obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1);
            Perceptron.AddInput(8, (ArenaWidth - Position.X));
            Perceptron.AddInput(9, (ArenaHeight - Position.Y));
            Perceptron.AddInput(10, (Position.Y));
            Perceptron.AddInput(11, (Position.Y));
            Perceptron.AddInput(12, (ArenaWidth - Other.Position.X));
            Perceptron.AddInput(13, (ArenaHeight - Other.Position.Y));
            Perceptron.AddInput(14, (Other.Position.Y));
            Perceptron.AddInput(15, (Other.Position.Y));
            Perceptron.AddInput(16, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (obstacle.Position.X - Position.X));
            Perceptron.AddInput(17, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (obstacle.Position.Y - Position.Y));
            Perceptron.AddInput(18, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (obstacle.Position.X - Other.Position.X));
            Perceptron.AddInput(19, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (obstacle.Position.Y - Other.Position.Y));
            Perceptron.AddInput(20, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.X - Position.X));
            Perceptron.AddInput(21, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.Y - Position.Y));
            Perceptron.AddInput(22, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.X - Other.Position.X));
            Perceptron.AddInput(23, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position.Y - Other.Position.Y));
            Perceptron.AddInput(24, Stamina);
            Perceptron.AddInput(25, isOnEdge(Position) ? 1 : 0);
            Perceptron.AddInput(26, isOnEdge(Position) ? 0 : 1);
            Perceptron.AddInput(27, isInObstacle(obstacle) ? 1 : 0);
            Perceptron.AddInput(28, isInObstacle(obstacle) ? 0 : 1);
            Perceptron.AddInput(29, isInObstacle(obstacle) ? 0 : 1);
            Perceptron.AddInput(30, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (obstacle.Position - Position).InPolar().Y);
            Perceptron.AddInput(31, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * (Other.Position - Position).InPolar().Y);
            Perceptron.AddInput(32, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 1 : 0) * ((obstacle.Position - Position).InPolar().Y - (Other.Position - Position).InPolar().Y));
            Perceptron.AddInput(33, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (obstacle.Position - Position).InPolar().Y);
            Perceptron.AddInput(34, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * (Other.Position - Position).InPolar().Y);
            Perceptron.AddInput(35, ((obstacle.ObstacleType == ObstacleType.Water || obstacle.ObstacleType == ObstacleType.Tree) ? 0 : 1) * ((obstacle.Position - Position).InPolar().Y - (Other.Position - Position).InPolar().Y));


            Perceptron.Run();

            double x = Perceptron.GetOutput(0);
            double y = Perceptron.GetOutput(1);

            Vector2D accelerationVector = new Vector2D(x, y);
            return accelerationVector;


        }
        private List<VisibleObstacle> GetOrderedObsticles()
        {
            return GetObstacles<Obstacle>().OrderBy(o => Vector2D.Distance2(o.Position, Position)).ToList();


        }
        bool isInObstacle(VisibleObstacle obstacle)
        {
            DongUtility.Rectangle obstacleRectange = obstacle.Size;
            return (obstacleRectange.MaxY > Position.Y && obstacleRectange.MaxX > Position.X && obstacleRectange.MinY < Position.Y && obstacleRectange.MinX < Position.X);
        }
        private bool isOnEdge(VisibleAnimal animal)
        {
            Vector2D aniPos = animal.Position;
            return isOnEdge(aniPos);
        }
        private bool isOnEdge(Vector2D aniPos)
        {

            return aniPos.X >= 0 && aniPos.X <= .5 || aniPos.Y >= 0 && aniPos.Y <= .5 || aniPos.X <= ArenaWidth && aniPos.X >= ArenaWidth - .5 || aniPos.Y <= ArenaHeight && aniPos.Y >= ArenaHeight - .5;
        }

    }
    public class HareIntelligenceDefault2 : HareIntelligence
    {
        public override Color Color { get { return Color.Green; } }
        public override string Name { get { return "Default2 Hare"; } }
        public override string BitmapFilename { get { return "rabbit2.jpg"; } }
        private int myLynxSpecies;
        private int turnNumber = 0;
        private Vector2D previousPosition;
        public override Turn ChooseTurn()
        {
            
            const double distanceLimit2 = 25;
            const double distanceLimitLynx2 = 25;
            var animals = GetAnimalsSorted().ToList();

            if (previousPosition == Position)
            {
                foreach (var ani in animals)
                {
                    Vector2D direction = (Position - ani.Position).UnitVector();
                    if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                    {

                        Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 8;
                        Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 8;
                        previousPosition = Position;
                        if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude))
                        {
                            return ChangeVelocity(accelerationVectorClockwise);
                        }
                        else
                        {
                            return ChangeVelocity(accelerationVectorCounterClockwise);
                        }
                    }
                    if (ani.IsLynx && Math.Abs((ani.Velocity.UnitVector().X - direction.X)) < (ani.Size.Width + Size.Width) && Math.Abs((ani.Velocity.UnitVector().Y - direction.Y)) < (ani.Size.Height + Size.Height))
                    {

                        previousPosition = Position;
                        return ChangeVelocity(direction * 12);
                    }
                }
            }
                foreach (var ani in animals)
            {
                if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimit2)
                {
                    Vector2D direction = ani.Position - Position;
                    return ChangeVelocity(-direction * 12);
                }
            }

            return ChangeVelocity(Vector2D.PolarVector(7, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
    public class HareIntelligenceDefault3 : HareIntelligence
    {
        public override Color Color { get { return Color.Purple; } }
        public override string Name { get { return "Default3 Hare"; } }
        public override string BitmapFilename { get { return "rabbit3.jpg"; } }
        private int myLynxSpecies;
        private int turnNumber = 0;
        private Vector2D previousPosition;
        public override Turn ChooseTurn()
        {
            const double distanceLimit2 = 25;
            const double distanceLimitLynx2 = 25;
            var animals = GetAnimalsSorted().ToList();
            if (previousPosition == Position)
            {
                foreach (var ani in animals)
                {
                    Vector2D direction = (Position - ani.Position).UnitVector();
                    if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                    {

                        Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 8;
                        Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 8;
                        previousPosition = Position;
                        if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude))
                        {
                            return ChangeVelocity(accelerationVectorClockwise);
                        }
                        else
                        {
                            return ChangeVelocity(accelerationVectorCounterClockwise);
                        }
                    }
                    if (ani.IsLynx && Math.Abs((ani.Velocity.UnitVector().X - direction.X)) < (ani.Size.Width + Size.Width) && Math.Abs((ani.Velocity.UnitVector().Y - direction.Y)) < (ani.Size.Height + Size.Height))
                    {

                        previousPosition = Position;
                        return ChangeVelocity(direction * 12);
                    }
                }
            }
            foreach (var ani in animals)
            {
                if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimit2)
                {
                    Vector2D direction = ani.Position - Position;
                    return ChangeVelocity(-direction * 12);
                }
            }
            foreach (var ani in animals)
            {
                if (!ani.IsLynx && /*!IsSameSpecies(ani) &&*/ Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                {
                    Vector2D direction = (Position - ani.Position).UnitVector();
                    Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 8;
                    Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 8;
                    previousPosition = Position;
                    if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude))
                    {
                        return ChangeVelocity(accelerationVectorClockwise);
                    }
                    else
                    {
                        return ChangeVelocity(accelerationVectorCounterClockwise);
                    }


                }
            }
            return ChangeVelocity(Vector2D.PolarVector(8, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
    public class HareIntelligenceDefault4 : HareIntelligence
    {
        public override Color Color { get { return Color.Bisque; } }
        public override string Name { get { return "Default4 Hare"; } }
        public override string BitmapFilename { get { return "rabbit4.jpg"; } }
        private int myLynxSpecies;
        private int turnNumber = 0;
        private Vector2D previousPosition;
        public override Turn ChooseTurn()
        {
            const double distanceLimit2 = 25;
            const double distanceLimitLynx2 = 25;
            var animals = GetAnimalsSorted().ToList();
            if (previousPosition == Position)
            {
                foreach (var ani in animals)
                {
                    Vector2D direction = (Position - ani.Position).UnitVector();
                    if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                    {

                        Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 8;
                        Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 8;
                        previousPosition = Position;
                        if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude))
                        {
                            return ChangeVelocity(accelerationVectorClockwise);
                        }
                        else
                        {
                            return ChangeVelocity(accelerationVectorCounterClockwise);
                        }
                    }
                    if (ani.IsLynx && Math.Abs((ani.Velocity.UnitVector().X - direction.X)) < (ani.Size.Width + Size.Width) && Math.Abs((ani.Velocity.UnitVector().Y - direction.Y)) < (ani.Size.Height + Size.Height))
                    {

                        previousPosition = Position;
                        return ChangeVelocity(direction * 12);
                    }
                }
            }
            foreach (var ani in animals)
            {
                if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimit2)
                {
                    Vector2D direction = ani.Position - Position;
                    return ChangeVelocity(-direction * 12);
                }
            }
            foreach (var ani in animals)
            {
                if (!ani.IsLynx && /*!IsSameSpecies(ani) &&*/ Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                {
                    Vector2D direction = (Position - ani.Position).UnitVector();
                    Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 8;
                    Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 8;
                    previousPosition = Position;
                    if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude))
                    {
                        return ChangeVelocity(accelerationVectorClockwise);
                    }
                    else
                    {
                        return ChangeVelocity(accelerationVectorCounterClockwise);
                    }


                }
            }
            return ChangeVelocity(Vector2D.PolarVector(8, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
    public class HareIntelligenceDefault5 : HareIntelligence
    {
        public override Color Color { get { return Color.Silver; } }
        public override string Name { get { return "Default5 Hare"; } }
        public override string BitmapFilename { get { return "rabbit5.jpg"; } }

        public TrentonLykePerceptron Perceptron { get; set; } = new TrentonLykePerceptron(6, new int[] { 3 }, 2);
        private Vector2D previousPosition;
        private int turnNumber = 0;
        private int myHareSpecies;
        public override Turn ChooseTurn()
        {
            
            //var animals = GetAnimalsSorted().ToList();
            //if (animals.Count > 0)
            //{
            //    foreach (var ani in animals)
            //    {
            //        if (!ani.IsLynx)
            //        {
            //            Vector2D direction = ani.Position - Position;
            //            return ChangeVelocity(direction.UnitVector() * 4);
            //        }
            //    }
            //}

            //return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
            double standardDeviation = 100;
            var animals = GetAnimalsSorted().ToList();
            if (previousPosition == Position)
            {
                Perceptron.RandomWeightsAbsolute(standardDeviation);
                foreach (var ani in animals)
                {
                    if (ani.IsLynx)
                    {
                        previousPosition = Position;
                        return ChangeVelocity(RunPerceptron(ani));
                    }
                }
            }

            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (ani.IsLynx)
                    {

                        previousPosition = Position;
                        Vector2D displacementVector = ani.Position - Position;
                        Vector2D accelerationVector = RunPerceptron(ani).UnitVector() * 9;
                        if (Math.Sign(accelerationVector.X) == Math.Sign(displacementVector.X) || Math.Sign(accelerationVector.Y) == Math.Sign(displacementVector.Y))
                        {
                            Perceptron.RandomWeightsAbsolute(standardDeviation);
                            return ChangeVelocity(RunPerceptron(ani).UnitVector() * 9);

                        }
                        else
                        {
                            return ChangeVelocity(accelerationVector);
                        }
                    }
                }
            }
            previousPosition = Position;
            return ChangeVelocity(Vector2D.PolarVector(7, Random.NextDouble(0, 2 * Math.PI)));

        }

        //gets the acceleration based on the perceptron
        private Vector2D RunPerceptron(VisibleAnimal Other)
        {
            Perceptron.Reset();

            Perceptron.AddInput(0, (Position.X - Other.Position.X));
            Perceptron.AddInput(1, (Position.Y - Other.Position.X));

            Perceptron.AddInput(2, Other.Velocity.X);




            Perceptron.AddInput(3, Other.Velocity.Y);

            Perceptron.AddInput(4, Velocity.Y - Other.Velocity.Y);
            Perceptron.AddInput(5, Velocity.X - Other.Velocity.X);


            Perceptron.Run();

            double x = Perceptron.GetOutput(0);
            double y = Perceptron.GetOutput(1);

            Vector2D accelerationVector = new Vector2D(x, y);
            return accelerationVector;


        }
    }
    public class HareIntelligenceDefault6 : HareIntelligence
    {
        public override Color Color { get { return Color.HotPink; } }
        public override string Name { get { return "Default2 Hare"; } }
        public override string BitmapFilename { get { return "rabbit.jpg"; } }

        public override Turn ChooseTurn()
        {
            const double distanceLimit2 = 25;

            var animals = GetAnimalsSorted().ToList();
            foreach (var ani in animals)
            {
                if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimit2)
                {
                    Vector2D direction = ani.Position - Position;
                    return ChangeVelocity(-direction * 5);
                }
            }

            return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
    public class HareIntelligenceDefault7 : HareIntelligence
    {
        public override Color Color { get { return Color.HotPink; } }
        public override string Name { get { return "Default Hare"; } }
        public override string BitmapFilename { get { return "rabbit.jpg"; } }

        public override Turn ChooseTurn()
        {
            const double distanceLimit2 = 25;

            var animals = GetAnimalsSorted().ToList();
            foreach (var ani in animals)
            {
                if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimit2)
                {
                    Vector2D direction = ani.Position - Position;
                    return ChangeVelocity(-direction * 5);
                }
            }

            return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
        }
    }
}
