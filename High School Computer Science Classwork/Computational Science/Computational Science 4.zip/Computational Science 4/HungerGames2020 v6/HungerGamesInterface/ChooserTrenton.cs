﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Arena;
using DongUtility;
using HungerGames.Animals;
using HungerGames.Interface;
using HungerGamesCore.Interface;
using HungerGamesCore.Terrain;

namespace HungerGames
{
    public class ChooserTrenton : LocationChooserTemplateIntermediate<HareIntelligenceTrentonFinalBest, LynxIntelligenceTrentonFinalBest>
    {
        private static readonly string path = @"C:\Computational Science Data\";
        private Vector2D[] harePostionArray = new Vector2D[100];
        private List<Rectangle> hidingSpots = new List<Rectangle>();
        private int lastUsedHairIndex = 19;
        private int lastUsedHidingSpotIndex = -1;
        private double minInToWall = .2;
        private double maxOutToWall = .5;
        private double edgeOffset = .1;
        private double lynxSideLength = .5;
        private double hareSideLength = .2;
        private int lastShrubListIndex = -1;
        protected override Vector2D UserDefinedChooseLocation(VisibleArena arena, bool hare, int organismNumber)
        {

            // Fill in your decision algorithm here.
            // The organismNumber variable counts from 0 to the total number of organisms.  This can be useful for
            // spreading your organisms out a bit
            if (hare && organismNumber == 0) {
                var trees = arena.GetObstacles<Tree>().ToList();
                var waterBodies = arena.GetObstacles<Water>().ToList();
                foreach (VisibleObstacle tree in trees) {
                    if (tree.Size.MinX>minInToWall&& tree.Size.MinX < maxOutToWall) {

                        Vector2D possiblePosition = new Vector2D(edgeOffset, ((double)(tree.Size.MinY + tree.Size.MaxY)) / 2);
                        Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);
                        if (arena.TestArea(possibleRectagle)) {
                            hidingSpots.Add(possibleRectagle);
                        }
                    }
                    if (tree.Size.MinX < arena.Width-minInToWall && tree.Size.MinX > arena.Width- maxOutToWall)
                    {

                        Vector2D possiblePosition = new Vector2D(arena.Width- edgeOffset, ((double)(tree.Size.MinY + tree.Size.MaxY)) / 2);
                        Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);

                        if (arena.TestArea(possibleRectagle))
                        {
                            hidingSpots.Add(possibleRectagle);
                        }
                    }
                    if (tree.Size.MinY > minInToWall && tree.Size.MinY < maxOutToWall)
                    {

                        Vector2D possiblePosition = new Vector2D(edgeOffset, ((double)(tree.Size.MinX + tree.Size.MaxX)) / 2);
                        Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);
                        if (arena.TestArea(possibleRectagle))
                        {
                            hidingSpots.Add(possibleRectagle);
                        }
                    }
                    if (tree.Size.MinY < arena.Width - minInToWall && tree.Size.MinY > arena.Width - maxOutToWall)
                    {

                        Vector2D possiblePosition = new Vector2D(arena.Width - edgeOffset, ((double)(tree.Size.MinX + tree.Size.MaxX)) / 2);
                        Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);
                        if (arena.TestArea(possibleRectagle))
                        {
                            hidingSpots.Add(possibleRectagle);
                        }
                    }
                }
                foreach (VisibleObstacle waterBody in waterBodies)
                {
                    if (waterBody.Size.MinX > minInToWall && waterBody.Size.MinX < maxOutToWall)
                    {
                        double placementStep = (waterBody.Size.MaxY - waterBody.Size.MinY) / minInToWall;
                        for (double component = waterBody.Size.MinY+edgeOffset; component < waterBody.Size.MaxY; component += placementStep)
                        {
                            Vector2D possiblePosition = new Vector2D(edgeOffset, component);
                            Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);
                            if (arena.TestArea(possibleRectagle))
                            {
                                hidingSpots.Add(possibleRectagle);
                            }
                        }
                    }
                    if (waterBody.Size.MinX < arena.Width - minInToWall && waterBody.Size.MinX > arena.Width - maxOutToWall)
                    { 
                        double placementStep = (waterBody.Size.MaxY - waterBody.Size.MinY) / minInToWall;
                        for (double component = waterBody.Size.MinY + edgeOffset; component < waterBody.Size.MaxY; component += placementStep)
                        {
                            Vector2D possiblePosition = new Vector2D(arena.Width - edgeOffset, component);
                            Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);
                            if (arena.TestArea(possibleRectagle))
                            {
                                hidingSpots.Add(possibleRectagle);
                            }
                        }
                    }
                    if (waterBody.Size.MinY > minInToWall && waterBody.Size.MinY < maxOutToWall)
                    {

                        double placementStep = (waterBody.Size.MaxX - waterBody.Size.MinX) / minInToWall;
                        for (double component = waterBody.Size.MinX + edgeOffset; component < waterBody.Size.MaxX; component += placementStep)
                        {
                            Vector2D possiblePosition = new Vector2D(edgeOffset, component);
                            Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);
                            if (arena.TestArea(possibleRectagle))
                            {
                                hidingSpots.Add(possibleRectagle);
                            }
                        }
                    }
                    if (waterBody.Size.MinY < arena.Width - minInToWall && waterBody.Size.MinY > arena.Width - maxOutToWall)
                    {

                        double placementStep = (waterBody.Size.MaxX - waterBody.Size.MinX) / minInToWall;
                        for (double component = waterBody.Size.MinX + edgeOffset; component < waterBody.Size.MaxX; component += placementStep)
                        {
                            Vector2D possiblePosition = new Vector2D(arena.Width - edgeOffset, component);
                            Rectangle possibleRectagle = new Rectangle(possiblePosition, hareSideLength, hareSideLength);
                            if (arena.TestArea(possibleRectagle))
                            {
                                hidingSpots.Add(possibleRectagle);
                            }
                        }
                    }
                }
            }
            if (hare)
            {
                int i = lastUsedHidingSpotIndex + 1;
                for (; i < hidingSpots.Count(); i++) {
                    if (arena.TestArea(hidingSpots[i]))
                    {
                        harePostionArray[organismNumber] = hidingSpots[i].Center;
                        lastUsedHidingSpotIndex = i;
                        lastUsedHairIndex = organismNumber;
                        return harePostionArray[organismNumber];
                    }
                    
                }
                lastUsedHidingSpotIndex = i;
                
                harePostionArray[organismNumber]=RandomLocation(arena, hare);

                return harePostionArray[organismNumber];
            }
            else
            {
                int i = lastUsedHairIndex+1;
                for (; i < harePostionArray.Length; i++) {
                    Vector2D lynxPosition = harePostionArray[i] + (new Vector2D(.5, .5));
                    Rectangle lynxRectangle = new Rectangle(lynxPosition, lynxSideLength,lynxSideLength);
                    bool isValidPoint = arena.TestArea(lynxRectangle);
                    if(isValidPoint) {
                        lastUsedHairIndex = i;
                        return lynxPosition;
                    }
                }
                lastUsedHairIndex=i;
                return RandomLocation(arena,hare);

            }
        }
    }
}
