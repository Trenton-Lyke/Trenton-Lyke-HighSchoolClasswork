﻿using Arena;
using DongUtility;
using HungerGames.Interface;
using HungerGamesCore.Interface;
using HungerGamesCore.Terrain;
using HungerGamesCore.Turns;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace HungerGames
{
    public class HareIntelligenceTrentonFinalBest : HareIntelligence
    {
        public override Color Color { get { return Color.DarkSlateBlue; } }
        public override string Name { get { return "Innocent Children"; } }
        public override string BitmapFilename { get { return "apple.png"; } }
        private int myLynxSpecies;
        private int turnNumber = 0;
        private Vector2D previousPosition;
        private bool triedPerpindicularCounterClockwise = false;
        private bool triedPerpindicularRightClockwise = false;
        private bool attemptingToHide = false;
        private VisibleObstacle hidingObstacle;
        private bool isHidden = false;
        public override Turn ChooseTurn()
        {
            var animals = GetAnimalsSorted().ToList();
            List<VisibleObstacle> obstacles = GetOrderedObsticles();

            const double distanceLimitLynx2 = 49;
            const double distanceLimitLynxHidden2 = 16;
            const double distanceLimitHare2 = 25;
            double minOutToWall = .5;
            double minInToWall = .2;
            double minSideDist = .1;
            double minBackDist = 0;
            double minStartSideDist = .35;
            if (turnNumber == 0)
            {
                IEnumerable<VisibleAnimal> sortedAnimals = GetAnimalsSorted();
                foreach (VisibleAnimal animal in sortedAnimals)
                {
                    Vector2D val = Position - animal.Position;
                    Console.WriteLine(val);
                    if (animal.IsLynx && animal.Velocity == Vector2D.NullVector() && animal.Position - Position == new Vector2D(.5, .5))
                    {
                        myLynxSpecies = animal.Species;

                        break;
                    }
                }
                turnNumber++;
                triedPerpindicularCounterClockwise = false;
                triedPerpindicularRightClockwise = false;

                return ChangeVelocity(Vector2D.PolarVector(0, 0));
            }
            if (isHidden) {
                previousPosition = Position;
                turnNumber++;
                return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
            }
            if (attemptingToHide) {
                if (hidingObstacle.ObstacleType==ObstacleType.Water) {
                    Console.Write("hi");
                }
                if (hidingObstacle.Size.MinX > minInToWall && hidingObstacle.Size.MinX <= minOutToWall)
                {
                    bool taken = false;
                    if (hidingObstacle.ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.X < hidingObstacle.Position.X && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(hidingObstacle.Position, Position)&& Vector2D.Distance2(ani.Position, hidingObstacle.Position)< Vector2D.Distance2(hidingObstacle.Position, Position))
                            {
                                taken = true;
                                attemptingToHide = false;
                            }
                        }
                    }
                    if (!taken)
                    {
                        previousPosition = Position;
                        turnNumber++;
                        attemptingToHide = true;
                        if ( Size.MinY < hidingObstacle.Size.MaxY + minStartSideDist && Size.MaxY > hidingObstacle.Size.MinY - minStartSideDist && hidingObstacle.Size.MinX - minBackDist < Size.MaxX) {
                            if ( hidingObstacle.Size.MaxY + minStartSideDist > ArenaHeight) {
                                return ChangeVelocity(new Vector2D(-Velocity.X, -3));
                            }
                            else {
                                return ChangeVelocity(new Vector2D(-Velocity.X, 3));
                            }
                        }
                        else if (hidingObstacle.Size.MinX - minBackDist < Size.MaxX)
                        {
                            return ChangeVelocity(new Vector2D(-10, -Velocity.Y));
                        }
                        else if (Math.Abs(hidingObstacle.Position.Y - Position.Y) > minSideDist)
                        {
                            double val = Math.Abs(hidingObstacle.Position.Y - Position.Y);
                            return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y + Math.Sign(hidingObstacle.Position.Y - Position.Y)));
                        }
                        else {
                            isHidden = true;
                            attemptingToHide = false;
                            return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                        }

                    }
                }
                else if (hidingObstacle.Size.MaxX < ArenaWidth - minInToWall && hidingObstacle.Size.MaxX >= ArenaWidth - minOutToWall)
                {
                    bool taken = false;
                    if (hidingObstacle.ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.X > hidingObstacle.Position.X && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(hidingObstacle.Position, Position)&& Vector2D.Distance2(ani.Position, hidingObstacle.Position)< Vector2D.Distance2(hidingObstacle.Position, Position))
                            {
                                taken = true;
                                attemptingToHide = false;
                            }
                        }
                    }
                    if (!taken)
                    {
                        previousPosition = Position;
                        turnNumber++;
                        attemptingToHide = true;
                        if ( Size.MinY < hidingObstacle.Size.MaxY + minStartSideDist && Size.MaxY > hidingObstacle.Size.MinY - minStartSideDist && hidingObstacle.Size.MaxX + minBackDist > Size.MinX)
                        {
                            if (hidingObstacle.Size.MaxY + minStartSideDist > ArenaHeight)
                            {
                                return ChangeVelocity(new Vector2D(-Velocity.X, -3));
                            }
                            else
                            {
                                return ChangeVelocity(new Vector2D(-Velocity.X, 3));
                            }
                        }
                        else if (hidingObstacle.Size.MaxX + minBackDist > Size.MinX)
                        {
                            return ChangeVelocity(new Vector2D(10, -Velocity.Y));
                        }
                        else if (Math.Abs(hidingObstacle.Position.Y - Position.Y) > minSideDist)
                        {
                            double val = Math.Abs(hidingObstacle.Position.Y - Position.Y);
                            return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y+Math.Sign(hidingObstacle.Position.Y - Position.Y)));
                        }
                        else
                        {
                            isHidden = true;
                            attemptingToHide = false;
                            return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                        }
                    }
                }
                else if (hidingObstacle.Size.MinY > minInToWall && hidingObstacle.Size.MinY <= minOutToWall)
                {
                    bool taken = false;
                    if (hidingObstacle.ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.Y < hidingObstacle.Position.Y && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(hidingObstacle.Position, Position)&& Vector2D.Distance2(ani.Position, hidingObstacle.Position)< Vector2D.Distance2(hidingObstacle.Position, Position))
                            {
                                taken = true;
                                attemptingToHide = false;
                            }
                        }
                    }
                    if (!taken)
                    {
                        previousPosition = Position;
                        turnNumber++;
                        attemptingToHide = true;
                        if (Size.MinX < hidingObstacle.Size.MaxX + minStartSideDist && Size.MaxX > hidingObstacle.Size.MinX - minStartSideDist && hidingObstacle.Size.MinY - minBackDist < Size.MaxY)
                        {
                            if (hidingObstacle.Size.MaxX + minStartSideDist > ArenaWidth)
                            {
                                return ChangeVelocity(new Vector2D(-3,-Velocity.Y));
                            }
                            else
                            {
                                return ChangeVelocity(new Vector2D(3,-Velocity.Y));
                            }
                        }
                        else if (hidingObstacle.Size.MinY - minBackDist < Size.MaxY)
                        {
                            return ChangeVelocity(new Vector2D(-Velocity.X,-10));
                        }
                        else if (Math.Abs(hidingObstacle.Position.X - Position.X) > minSideDist)
                        {
                            double val = Math.Abs(hidingObstacle.Position.X - Position.X);
                            return ChangeVelocity(new Vector2D(-Velocity.X+Math.Sign(hidingObstacle.Position.X - Position.X),-Velocity.Y));
                        }
                        else
                        {
                            isHidden = true;
                            attemptingToHide = false;
                            return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                        }
                    }
                }
                else if ( hidingObstacle.Size.MaxY <= ArenaHeight - minInToWall && hidingObstacle.Size.MaxY >= ArenaHeight - minOutToWall)
                {
                    bool taken = false;
                    if (hidingObstacle.ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.Y > hidingObstacle.Position.Y && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(hidingObstacle.Position, Position)&& Vector2D.Distance2(ani.Position, hidingObstacle.Position)< Vector2D.Distance2(hidingObstacle.Position, Position))
                            {
                                taken = true;
                                attemptingToHide = false;
                            }
                        }
                    }
                    if (!taken)
                    {
                        previousPosition = Position;
                        turnNumber++;
                        attemptingToHide = true;
                        if (Size.MinX < hidingObstacle.Size.MaxX + minStartSideDist && Size.MaxX > hidingObstacle.Size.MinX - minStartSideDist && hidingObstacle.Size.MaxY + minBackDist > Size.MinY)
                        {
                            if (hidingObstacle.Size.MaxX + minStartSideDist > ArenaWidth)
                            {
                                return ChangeVelocity(new Vector2D(-3, -Velocity.Y));
                            }
                            else
                            {
                                return ChangeVelocity(new Vector2D(3, -Velocity.Y));
                            }
                        }
                        else if (hidingObstacle.Size.MaxY + minBackDist > Size.MinY)
                        {
                            return ChangeVelocity(new Vector2D(-Velocity.X,10));
                        }
                        else if (Math.Abs(hidingObstacle.Position.X - Position.X) > minSideDist)
                        {
                            double val = Math.Abs(hidingObstacle.Position.X - Position.X);
                            double val2 = 5 * Math.Sign(hidingObstacle.Position.X - Position.X);
                            return ChangeVelocity(new Vector2D( -Velocity.X+Math.Sign(hidingObstacle.Position.X - Position.X), -Velocity.Y));
                        }
                        else
                        {
                            isHidden = true;
                            attemptingToHide = false;
                            return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                        }
                    }
                }
            }
            else if (!isHidden && (obstacles[0].ObstacleType == ObstacleType.Tree || obstacles[0].ObstacleType == ObstacleType.Water))
            {
                hidingObstacle= obstacles[0];
                if (isOnEdge(Position)) {
                    Console.Write("hi");
                }
                if ( hidingObstacle.Size.MinX > minInToWall && hidingObstacle.Size.MinX <= minOutToWall)
                {
                    bool taken = false;
                    if (obstacles[0].ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.X < obstacles[0].Position.X && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(obstacles[0].Position, Position)&& Vector2D.Distance2(ani.Position, obstacles[0].Position)< Vector2D.Distance2(obstacles[0].Position, Position))
                            {
                                taken = true;
                            }
                        }
                    }
                    if (!taken)
                    {
                        attemptingToHide = true;
                        hidingObstacle = obstacles[0];
                        return ChangeVelocity(new Vector2D(-1, -Velocity.Y));
                    }
                }
                else if (hidingObstacle.Size.MaxX < ArenaWidth - minInToWall && hidingObstacle.Size.MaxX >= ArenaWidth - minOutToWall)
                {
                    bool taken = false;
                    if (obstacles[0].ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.X > obstacles[0].Position.X && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(obstacles[0].Position, Position)&& Vector2D.Distance2(ani.Position, obstacles[0].Position)< Vector2D.Distance2(obstacles[0].Position, Position))
                            {
                                taken = true;
                            }
                        }
                        if (!taken)
                        {
                            attemptingToHide = true;
                            hidingObstacle = obstacles[0];
                            return ChangeVelocity(new Vector2D(1, -Velocity.Y));
                        }
                    }
                }
                else if (hidingObstacle.Size.MinY > minInToWall && hidingObstacle.Size.MinY <= minOutToWall)
                {
                    bool taken = false;
                    if (obstacles[0].ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.Y < obstacles[0].Position.Y && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(obstacles[0].Position, Position)&& Vector2D.Distance2(ani.Position, obstacles[0].Position)< Vector2D.Distance2(obstacles[0].Position, Position))
                            {
                                taken = true;
                            }
                        }
                    }
                    if (!taken)
                    {
                        attemptingToHide = true;
                        hidingObstacle = obstacles[0];
                        return ChangeVelocity(new Vector2D(-Velocity.X, -1));
                    }
                }
                else if ( hidingObstacle.Size.MaxY < ArenaHeight - minInToWall && hidingObstacle.Size.MaxY >= ArenaHeight - minOutToWall)
                {
                    bool taken = false;
                    if (obstacles[0].ObstacleType != ObstacleType.Water)
                    {
                        foreach (VisibleAnimal ani in animals)
                        {
                            if (ani.Position.Y > obstacles[0].Position.Y && Vector2D.Distance2(ani.Position, Position) < Vector2D.Distance2(obstacles[0].Position, Position)&& Vector2D.Distance2(ani.Position, obstacles[0].Position)< Vector2D.Distance2(obstacles[0].Position, Position))
                            {
                                taken = true;
                            }
                        }
                    }
                    if (!taken)
                    {
                        attemptingToHide = true;
                        hidingObstacle = obstacles[0];
                        return ChangeVelocity(new Vector2D(-Velocity.X, 1));
                    }
                }

            }
            if (previousPosition == Position)
            {

                if (obstacles[0].ObstacleType == ObstacleType.Tree || obstacles[0].ObstacleType == ObstacleType.Water)
                {
                    if (Size.MinX < minInToWall && obstacles[0].Size.MinX - Size.MaxX >= 0 && obstacles[0].Size.MinX - Size.MaxX <= minBackDist && Math.Abs(obstacles[0].Position.Y - Position.Y) <= minSideDist)
                    {
                        previousPosition = Position;
                        return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                    }
                    else if (Size.MinY < minInToWall && obstacles[0].Size.MinY - Size.MaxY >= 0 && obstacles[0].Size.MinY - Size.MaxY <= minBackDist && Math.Abs(obstacles[0].Position.X - Position.X) <= minSideDist)
                    {
                        previousPosition = Position;
                        return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                    }
                    else if (Size.MaxX > ArenaWidth- minInToWall && obstacles[0].Size.MaxX - Size.MinX <= 0 && obstacles[0].Size.MaxX - Size.MinX >= -minBackDist && Math.Abs(obstacles[0].Position.Y - Position.Y) <= minSideDist)
                    {
                        previousPosition = Position;
                        return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                    }
                    else if (Size.MaxY > ArenaHeight - minInToWall && obstacles[0].Size.MaxY - Size.MinY <= 0 && obstacles[0].Size.MaxY - Size.MinY >= -minBackDist && Math.Abs(obstacles[0].Position.Y - Position.Y) <= minSideDist)
                    {
                        previousPosition = Position;
                        return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                    }
                }
                else if (isInObstacle(obstacles[0]))
                {
                    foreach (var ani in animals)
                    {
                        if (Vector2D.Distance2(Position, ani.Position) < distanceLimitLynxHidden2)
                        {
                            Vector2D direction = (Position - ani.Position).UnitVector();
                            Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 7;
                            Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 7;


                            previousPosition = Position;
                            if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude) && !triedPerpindicularRightClockwise)
                            {
                                triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                                return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                            }
                            else if (!triedPerpindicularCounterClockwise)
                            {
                                triedPerpindicularRightClockwise = false; triedPerpindicularCounterClockwise = true;
                                return ChangeVelocity(-Velocity + accelerationVectorCounterClockwise);
                            }
                            else
                            {
                                triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                                return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                            }
                        }
                    }
                    triedPerpindicularCounterClockwise = false;
                    triedPerpindicularRightClockwise = false;
                    previousPosition = Position;
                    return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                }
                foreach (var ani in animals)
                {
                    Vector2D direction = (Position - ani.Position).UnitVector();
                    if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2 || ani.IsLynx && Math.Abs((ani.Velocity.UnitVector().X - direction.X)) < (ani.Size.Width + Size.Width) && Math.Abs((ani.Velocity.UnitVector().Y - direction.Y)) < (ani.Size.Height + Size.Height) && !triedPerpindicularRightClockwise)
                    {

                        Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 7;
                        Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 7;


                        previousPosition = Position;
                        if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude) && !triedPerpindicularRightClockwise)
                        {
                            triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                        }
                        else if (!triedPerpindicularCounterClockwise)
                        {
                            triedPerpindicularRightClockwise = false; triedPerpindicularCounterClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorCounterClockwise);
                        }
                        else
                        {
                            triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                        }

                    }
                    if (ani.IsLynx && Math.Abs((ani.Velocity.UnitVector().X - direction.X)) < (ani.Size.Width + Size.Width) && Math.Abs((ani.Velocity.UnitVector().Y - direction.Y)) < (ani.Size.Height + Size.Height))
                    {
                        triedPerpindicularCounterClockwise = false;
                        triedPerpindicularRightClockwise = false;
                        previousPosition = Position;
                        return ChangeVelocity(-Velocity + direction * 10);
                    }
                }
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && /*!IsSameSpecies(ani) &&*/ Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                    {
                        Vector2D direction = (Position - ani.Position).UnitVector();
                        Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 7;
                        Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 7;
                        previousPosition = Position;


                        if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude))
                        {
                            triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                        }
                        else
                        {
                            triedPerpindicularRightClockwise = false; triedPerpindicularCounterClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorCounterClockwise);
                        }


                    }
                }
                Vector2D newVelocity = -Velocity.UnitVector() * 5;
                double y = newVelocity.Y != 0 ? newVelocity.Y : Math.Sqrt((Random.Next(-5,5)) );
                double x = newVelocity.X != 0 ? newVelocity.X : Math.Sqrt((Random.Next(-5,5)) );
                previousPosition = Position;
                turnNumber++;
                triedPerpindicularCounterClockwise = false;
                triedPerpindicularRightClockwise = false;
                return ChangeVelocity(-Velocity + Vector2D.PolarVector(5, Math.Atan2(y, x)));
            }

            if (obstacles[0].ObstacleType == ObstacleType.Tree || obstacles[0].ObstacleType == ObstacleType.Water)
            {
                if (Position.X < minOutToWall-minBackDist && obstacles[0].Position.X - Position.X >= 0 && obstacles[0].Position.X - Position.X <= minBackDist && Math.Abs(obstacles[0].Position.Y - Position.Y) <= minSideDist)
                {
                    previousPosition = Position;
                    return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                }
                else if (Position.Y < minOutToWall - minBackDist && obstacles[0].Position.Y - Position.Y >= 0 && obstacles[0].Position.Y - Position.Y <= minBackDist && Math.Abs(obstacles[0].Position.X - Position.X) <= minSideDist)
                {
                    previousPosition = Position;
                    return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                }
                else if (Position.X > ArenaWidth- (minOutToWall - minBackDist) && obstacles[0].Position.X - Position.X <= 0 && obstacles[0].Position.X - Position.X >= -minBackDist && Math.Abs(obstacles[0].Position.Y - Position.Y) <= minSideDist)
                {
                    previousPosition = Position;
                    return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                }
                else if (Position.Y > ArenaHeight-(minOutToWall - minBackDist) && obstacles[0].Position.Y - Position.Y <= 0 && obstacles[0].Position.Y - Position.Y >= -minBackDist && Math.Abs(obstacles[0].Position.Y - Position.Y) <= minSideDist)
                {
                    previousPosition = Position;
                    return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
                }
            }
            else if (isInObstacle(obstacles[0]))
            {
                foreach (var ani in animals)
                {
                    if (Vector2D.Distance2(Position, ani.Position) < distanceLimitLynxHidden2)
                    {
                        Vector2D direction = (Position - ani.Position).UnitVector();
                        Vector2D accelerationVectorClockwise = (new Vector2D(direction.Y, -direction.X)) * 7;
                        Vector2D accelerationVectorCounterClockwise = (new Vector2D(-direction.Y, direction.X)) * 7;


                        previousPosition = Position;
                        if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude) && !triedPerpindicularRightClockwise)
                        {
                            triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                        }
                        else if (!triedPerpindicularCounterClockwise)
                        {
                            triedPerpindicularRightClockwise = false; triedPerpindicularCounterClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorCounterClockwise);
                        }
                        else
                        {
                            triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                            return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                        }
                    }
                }
                previousPosition = Position;
                return ChangeVelocity(new Vector2D(-Velocity.X, -Velocity.Y));
            }


            foreach (var ani in animals)
            {
                Vector2D direction = (Position - ani.Position).UnitVector();
                if (ani.IsLynx && Math.Abs((ani.Velocity.UnitVector().X - direction.X)) < (ani.Size.Width + Size.Width) && Math.Abs((ani.Velocity.UnitVector().Y - direction.Y)) < (ani.Size.Height + Size.Height))
                {
                    Vector2D accelerationVectorClockwise = (new Vector2D(ani.Velocity.UnitVector().Y, -ani.Velocity.UnitVector().X)) * 7;
                    Vector2D accelerationVectorCounterClockwise = (new Vector2D(-ani.Velocity.UnitVector().Y, ani.Velocity.UnitVector().X)) * 7;
                    previousPosition = Position;
                    turnNumber++;


                    if (Math.Abs((ani.Position - (Position + accelerationVectorClockwise)).Magnitude) > Math.Abs((ani.Position - (Position + accelerationVectorCounterClockwise)).Magnitude))
                    {
                        triedPerpindicularCounterClockwise = false; triedPerpindicularRightClockwise = true;
                        return ChangeVelocity(-Velocity + accelerationVectorClockwise);
                    }
                    else
                    {
                        triedPerpindicularRightClockwise = false; triedPerpindicularCounterClockwise = true;
                        return ChangeVelocity(-Velocity + accelerationVectorCounterClockwise);
                    }
                }

                if (ani.IsLynx && Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                {
                    triedPerpindicularCounterClockwise = false;
                    triedPerpindicularRightClockwise = false;
                    previousPosition = Position;
                    return ChangeVelocity(-Velocity+direction * 12);

                }
            }
            foreach (var ani in animals)
            {
                if (!ani.IsLynx && /*!IsSameSpecies(ani) &&*/Vector2D.Distance2(Position, ani.Position) < distanceLimitLynx2)
                {
                    Vector2D direction = (Position - ani.Position).UnitVector();
                    previousPosition = Position;
                    triedPerpindicularCounterClockwise = false;
                    triedPerpindicularRightClockwise = false;
                    return ChangeVelocity(-Velocity+direction * 12);

                }
            }
            triedPerpindicularCounterClockwise = false;
            triedPerpindicularRightClockwise = false;
            previousPosition = Position;
            return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
        }

        private List<VisibleObstacle> GetOrderedObsticles()
        {
            return GetObstacles<Obstacle>().OrderBy(o => Vector2D.Distance2(o.Position, Position)).ToList();


        }
        bool isInObstacle(VisibleObstacle obstacle)
        {
            DongUtility.Rectangle obstacleRectange = obstacle.Size;
            return (obstacleRectange.MaxY > Position.Y && obstacleRectange.MaxX > Position.X && obstacleRectange.MinY < Position.Y && obstacleRectange.MinX < Position.X);
        }
        private bool isOnEdge(VisibleAnimal animal)
        {
            Vector2D aniPos = animal.Position;
            return isOnEdge(aniPos);
        }
        private bool isOnEdge(Vector2D aniPos)
        {
            
            return aniPos.X >= 0 && aniPos.X <= .5 || aniPos.Y >= 0 && aniPos.Y <= .5 || aniPos.X <= ArenaWidth && aniPos.X >= ArenaWidth-.5 || aniPos.Y <= ArenaHeight && aniPos.Y >= ArenaHeight-.5;
        }
    }
}
