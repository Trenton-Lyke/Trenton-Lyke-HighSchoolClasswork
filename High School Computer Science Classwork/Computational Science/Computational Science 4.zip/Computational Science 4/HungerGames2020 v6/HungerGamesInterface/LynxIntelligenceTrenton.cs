﻿using Arena;
using DongUtility;
using HungerGames.Animals;
using HungerGamesCore.Animals;
using HungerGamesCore.Interface;
using HungerGamesCore.Terrain;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HungerGames.Interface
{
   

    public class LynxIntelligenceTrentonFinalBest : LynxIntelligence
    {
        public override Color Color { get { return Color.DarkSlateBlue; } }
        public override string Name { get { return "The losers"; } }
        public override string BitmapFilename { get { return "banana.png"; } }
        private int myHareSpecies;
        private Vector2D previousPosition;
        private int turnNumber = 0;
        private int tryEndTurnNumber = 0;
        private int tryProgression = 0;
        private string tryType;
        private int lineDriveTurnLength = 20;
        private VisibleAnimal victimOfTry;
        private int turnsStuck = 0;
        private bool isLynx1;

        public override Turn ChooseTurn()
        {
            if (turnNumber==0) {
                isLynx1=Random.NextBool();
            }
            if (isLynx1)
            {
                return Lynx2ChooseTurn();
            }
            else
            {
                return Lynx1ChooseTurn();
            }

        }

        private Turn Lynx2ChooseTurn()
        {
            int maxAnimalSearch = 5;
            var obstacles = GetOrderedObsticles();
            var animals = GetAnimalsSorted().ToList();
            if (turnNumber == 0)
            {
                IEnumerable<VisibleAnimal> sortedAnimals = GetAnimalsSorted();
                foreach (VisibleAnimal animal in sortedAnimals)
                {
                    Vector2D val = Position - animal.Position;
                    Console.WriteLine(val);
                    if (!animal.IsLynx && animal.Velocity == Vector2D.NullVector() && Position - animal.Position == new Vector2D(.5, .5))
                    {
                        myHareSpecies = animal.Species;

                        break;
                    }
                }
                previousPosition = Position;
                turnNumber++;
                return ChangeVelocity(Vector2D.PolarVector(0, 0));
            }
            if (previousPosition == Position)
            {
                bool goRandom = true;
                bool animalOnEdge = false;
                VisibleAnimal animalOnEdgeNow=null;
                for (int i = 0; i < maxAnimalSearch; i++)
                {
                    if (!animals[i].IsLynx && animals[i].Species != myHareSpecies && isOnEdge(animals[i]))
                    {
                        animalOnEdge = true;
                        animalOnEdgeNow = animals[i];
                        break;
                    }
                }
                bool AttackBlocked = false;
                if (victimOfTry != null && animalOnEdge && tryType != null) {
                    double angleToAnimalOnEdge = (animalOnEdgeNow.Position - Position).InPolar().Y;
                    if (animals[0].IsLynx && Vector2D.Distance2(animalOnEdgeNow.Position,Position)> Vector2D.Distance2(animals[0].Position, Position)) {
                        double angleToLynx = (animals[0].Position - Position).InPolar().Y;
                        if (Math.Abs(angleToAnimalOnEdge- angleToLynx)<Math.PI/4) {
                            goRandom = true;
                        }
                    }
                    if ((obstacles[0].ObstacleType==ObstacleType.Water || obstacles[0].ObstacleType == ObstacleType.Tree) && Vector2D.Distance2(animalOnEdgeNow.Position, Position) > Vector2D.Distance2(obstacles[0].Position, Position))
                    {
                        double angleToObstacle = (obstacles[0].Position - Position).InPolar().Y;
                        if (Math.Abs(angleToAnimalOnEdge - angleToObstacle) < Math.PI / 4)
                        {
                            goRandom = true;
                        }
                    }

                }
                if (victimOfTry != null && animalOnEdge && tryType != null && ((obstacles[0].ObstacleType == ObstacleType.Tree || obstacles[0].ObstacleType == ObstacleType.Water) && Vector2D.Distance2(obstacles[0].Position, Position) < 2 || isAtCorner() || Vector2D.Distance2(Position, animals[0].Position) < 2))
                {
                    tryType = "Q";
                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                    tryProgression = 0;
                    victimOfTry = animals[0];
                }
                else
                {
                    for (int i = 0; i < maxAnimalSearch; i++)
                    {
                        if (!animals[i].IsLynx && animals[i].Species != myHareSpecies)
                        {
                            if (animals[i].Position.X < .5)
                            {
                                goRandom = false;
                                if (animals[i].Position.Y - Position.Y > 0)
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD+X0";
                                    break;
                                }
                                else
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD-X0";
                                    break;
                                }

                            }
                            else if (animals[i].Position.X > ArenaWidth-.5)
                            {
                                goRandom = false;
                                if (animals[i].Position.Y - Position.Y > 0)
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD+X30";
                                    break;
                                }
                                else
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD-X30";
                                    break;
                                }

                            }
                            else if (animals[i].Position.Y < .5)
                            {
                                goRandom = false;
                                if (animals[i].Position.X - Position.X > 0)
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD+Y0";
                                    break;
                                }
                                else
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD-Y0";
                                    break;
                                }

                            }
                            else if (animals[i].Position.Y > ArenaHeight-.5)
                            {
                                goRandom = false;
                                if (animals[i].Position.X - Position.X > 0)
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD+Y30";
                                    break;
                                }
                                else
                                {
                                    victimOfTry = animals[i];
                                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                    tryProgression = 0;
                                    tryType = "LD-Y30";
                                    break;
                                }

                            }
                        }
                    }
                }
                turnsStuck++;
                if (goRandom || turnsStuck > 2 || isAtCorner())
                {
                    Vector2D newVelocity = -Velocity.UnitVector() * 4;
                    double y = newVelocity.Y != 0 ? newVelocity.Y : Random.NextDouble() * 4 - 2;
                    double x = newVelocity.X != 0 ? newVelocity.X : Random.NextDouble() * 4 - 2;
                    previousPosition = Position;
                    turnNumber++;
                    if (tryType != null)
                    {
                        tryType = "Q";
                        tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                        tryProgression = 0;
                        victimOfTry = animals[0];
                    }
                    return ChangeVelocity(-Velocity + Vector2D.PolarVector(5, Math.Atan2(y, x)));



                }
            }
            else
            {
                turnsStuck = 0;
            }

            bool isAnimalOnEdge = false;
            for (int i = 0; i < maxAnimalSearch; i++)
            {
                if (!animals[i].IsLynx && animals[i].Species != myHareSpecies && isOnEdge(animals[i]))
                {
                    isAnimalOnEdge = true;
                    break;
                }
            }
            if (victimOfTry != null && isAnimalOnEdge && tryType != null && tryEndTurnNumber >= turnNumber && Stamina > 20)
            {
                turnNumber++;
                switch (tryType)
                {
                    case "LD-X0":
                        if (Position.X > 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(-18, 0));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, -18));
                        }
                        break;
                    case "LD-X30":
                        if (Position.X < ArenaWidth - 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(18, 0));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, -18));
                        }
                        break;
                    case "LD+X0":
                        if (Position.X > 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(-18, 0));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, 18));
                        }
                        break;
                    case "LD+X30":
                        if (Position.X < ArenaWidth - 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(18, 0));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, 18));
                        }
                        break;
                    case "LD-Y0":
                        if (Position.Y > 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, -18));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(-18, 0));
                        }
                        break;
                    case "LD-Y30":
                        if (Position.Y < ArenaHeight - 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, 18));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(-18, 0));
                        }
                        break;
                    case "LD+Y0":
                        if (Position.Y > 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, -18));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(18, 0));
                        }
                        break;
                    case "LD+Y30":
                        if (Position.Y < ArenaHeight - 1)
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(0, 18));
                        }
                        else
                        {
                            return ChangeVelocity(-Velocity + new Vector2D(18, 0));
                        }
                        break;
                    case "Q":
                        Vector2D direction = victimOfTry.Position - Position;
                        ChangeVelocity(-Velocity + -18 * direction.UnitVector());
                        break;
                    default:
                        Console.Write("Invalid Try Type");
                        tryType = null;
                        tryEndTurnNumber = 0;
                        tryProgression = 0;
                        victimOfTry = null;
                        break;
                }
                turnNumber++;
                previousPosition = Position;
            }
            else
            {
                tryType = null;
                tryProgression = 0;
                victimOfTry = null;
                tryEndTurnNumber = 0;
            }

            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && ani.Species != myHareSpecies)
                    {
                        int numberOfCloserAllies = 0;
                        foreach (var other in animals)
                        {
                            if (other.IsLynx && IsSameSpecies(other) && Vector2D.Distance2(other.Position, (ani.Position + ani.Velocity * .01)) < Vector2D.Distance2(Position, (ani.Position + ani.Velocity * .01)) && Vector2D.Distance2(Position, (ani.Position + ani.Velocity * .01)) > Vector2D.Distance2(other.Position, Position))
                            {
                                numberOfCloserAllies++;
                            }
                        }
                        if (numberOfCloserAllies < 2)
                        {
                            Vector2D direction = (ani.Position + ani.Velocity * .01) - Position;
                            previousPosition = Position;
                            turnNumber++;
                            bool leftObstacle = false;
                            bool rightObstacle = false;
                            Vector2D polarAnimalDirection = direction.UnitVector().InPolar();
                            double minObstacleAngle = Math.PI / 4;
                            double angleOffset = Math.PI / 3;
                            foreach (VisibleObstacle obstacle in obstacles)
                            {

                                Vector2D polarObstacleDirection = (obstacle.Position - Position).UnitVector().InPolar();
                                if ((obstacle.ObstacleType == ObstacleType.Tree || obstacle.ObstacleType == ObstacleType.Water) && Vector2D.Distance2(obstacle.Position, Position) < Vector2D.Distance2((ani.Position + ani.Velocity * .01), Position))
                                {
                                    if (Math.Abs(polarAnimalDirection.Y - polarObstacleDirection.Y) < minObstacleAngle && polarAnimalDirection.Y - polarObstacleDirection.Y > 0)
                                    {
                                        rightObstacle = true;
                                    }
                                    else if (Math.Abs(polarAnimalDirection.Y - polarObstacleDirection.Y) < minObstacleAngle && polarAnimalDirection.Y - polarObstacleDirection.Y < 0)
                                    {
                                        leftObstacle = true;
                                    }

                                }
                            }

                            if (leftObstacle && leftObstacle)
                            {
                                Vector2D rightOffsetResult = (Vector2D.PolarVector(1, polarAnimalDirection.Y - angleOffset) + Position);
                                Vector2D leftOffsetResult = (Vector2D.PolarVector(1, polarAnimalDirection.Y + angleOffset) + Position);
                                Vector2D closestPoint = Vector2D.NullVector();
                                double closestDistance = double.MaxValue;
                                Vector2D[] cornerList = { new Vector2D(0, 0), new Vector2D(0, ArenaHeight), new Vector2D(ArenaWidth, 0), new Vector2D(ArenaWidth, ArenaHeight) };
                                foreach (Vector2D corner in cornerList)
                                {
                                    double aDistance = Vector2D.Distance2(corner, Position);
                                    if (closestDistance > aDistance)
                                    {
                                        closestPoint = corner;
                                        closestDistance = aDistance;
                                    }
                                }
                                if (Vector2D.Distance2(closestPoint, rightOffsetResult) > Vector2D.Distance2(closestPoint, leftOffsetResult))
                                {
                                    return ChangeVelocity(-Velocity + 10 * Vector2D.PolarVector(1, polarAnimalDirection.Y - angleOffset));
                                }
                                else
                                {
                                    return ChangeVelocity(-Velocity + 10 * Vector2D.PolarVector(1, polarAnimalDirection.Y + angleOffset));
                                }
                            }
                            else if (leftObstacle)
                            {
                                return ChangeVelocity(-Velocity + 10 * Vector2D.PolarVector(1, polarAnimalDirection.Y - angleOffset));
                            }
                            else if (rightObstacle)
                            {
                                return ChangeVelocity(-Velocity + 10 * Vector2D.PolarVector(1, polarAnimalDirection.Y + angleOffset));
                            }
                            else
                            {
                                return ChangeVelocity(-Velocity + direction.UnitVector() * 15);
                            }
                        }
                    }
                }
            }
            turnNumber++;
            previousPosition = Position;
            return ChangeVelocity(Vector2D.PolarVector(10, Random.NextDouble(0, 2 * Math.PI)));
        }

        private Turn Lynx1ChooseTurn()
        {
            var obstacles = GetOrderedObsticles();
            var animals = GetAnimalsSorted().ToList();
            if (turnNumber == 0)
            {
                IEnumerable<VisibleAnimal> sortedAnimals = GetAnimalsSorted();
                foreach (VisibleAnimal animal in sortedAnimals)
                {
                    Vector2D val = Position - animal.Position;
                    Console.WriteLine(val);
                    if (!animal.IsLynx && animal.Velocity == Vector2D.NullVector() && Position - animal.Position == new Vector2D(.5, .5))
                    {
                        myHareSpecies = animal.Species;

                        break;
                    }
                }
                previousPosition = Position;
                turnNumber++;
                return ChangeVelocity(Vector2D.PolarVector(0, 0));
            }
            if (previousPosition == Position)
            {
                if (victimOfTry != null && isOnEdge(animals[0]) && tryType != null)
                {
                    tryType = "Q";
                    tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                    tryProgression = 0;
                    victimOfTry = animals[0];
                }
                else
                {
                    if (!animals[0].IsLynx && animals[0].Species != myHareSpecies)
                    {
                        if (animals[0].Position.X < .5)
                        {
                            if (animals[0].Position.Y - Position.Y > 0)
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD+X0";
                            }
                            else
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD-X0";
                            }
                        }
                        else if (animals[0].Position.X > ArenaWidth-.5)
                        {
                            if (animals[0].Position.Y - Position.Y > 0)
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD+X30";
                            }
                            else
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD-X30";
                            }
                        }
                        else if (animals[0].Position.Y < .5)
                        {
                            if (animals[0].Position.X - Position.X > 0)
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD+Y0";
                            }
                            else
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD-Y0";
                            }
                        }
                        else if (animals[0].Position.Y > ArenaHeight-.5)
                        {
                            if (animals[0].Position.X - Position.X > 0)
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD+Y30";
                            }
                            else
                            {
                                victimOfTry = animals[0];
                                tryEndTurnNumber = turnNumber + 1 + lineDriveTurnLength;
                                tryProgression = 0;
                                tryType = "LD-Y30";
                            }
                        }
                    }
                }
                Vector2D newVelocity = -Velocity.UnitVector() * 4;
                double y = newVelocity.Y != 0 ? newVelocity.Y : Random.NextDouble() * 4 - 2;
                double x = newVelocity.X != 0 ? newVelocity.X : Random.NextDouble() * 4 - 2;
                previousPosition = Position;
                turnNumber++;
                return ChangeVelocity(Vector2D.PolarVector(1, Math.Atan2(y, x)));
            }

            if (victimOfTry != null && isOnEdge(animals[0]) && tryType != null && tryEndTurnNumber >= turnNumber)
            {
                turnNumber++;
                switch (tryType)
                {
                    case "LD-X0":
                        if (Position.X > 1)
                        {
                            return ChangeVelocity(new Vector2D(-4, 0));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(-Velocity.X, -4));
                        }
                        break;
                    case "LD-X30":
                        if (Position.X < ArenaWidth - 1)
                        {
                            return ChangeVelocity(new Vector2D(4, 0));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(-Velocity.X, -4));
                        }
                        break;
                    case "LD+X0":
                        if (Position.X > 1)
                        {
                            return ChangeVelocity(new Vector2D(-4, 0));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(-Velocity.X, 4));
                        }
                        break;
                    case "LD+X30":
                        if (Position.X < ArenaWidth - 1)
                        {
                            return ChangeVelocity(new Vector2D(4, 0));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(-Velocity.X, 4));
                        }
                        break;
                    case "LD-Y0":
                        if (Position.Y > 1)
                        {
                            return ChangeVelocity(new Vector2D(0, -4));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(-4, -Velocity.Y));
                        }
                        break;
                    case "LD-Y30":
                        if (Position.Y < ArenaHeight - 1)
                        {
                            return ChangeVelocity(new Vector2D(0, 4));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(-4, -Velocity.Y));
                        }
                        break;
                    case "LD+Y0":
                        if (Position.Y > 1)
                        {
                            return ChangeVelocity(new Vector2D(0, -4));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(4, -Velocity.Y));
                        }
                        break;
                    case "LD+Y30":
                        if (Position.Y < ArenaHeight - 1)
                        {
                            return ChangeVelocity(new Vector2D(0, 4));
                        }
                        else
                        {
                            return ChangeVelocity(new Vector2D(4, -Velocity.Y));
                        }
                        break;
                    case "Q":
                        Vector2D direction = victimOfTry.Position - Position;
                        ChangeVelocity(-5 * direction.UnitVector());
                        break;
                    default:
                        Console.Write("Invalid Try Type");
                        tryType = null;
                        tryEndTurnNumber = 0;
                        tryProgression = 0;
                        victimOfTry = null;
                        break;
                }
                turnNumber++;
                previousPosition = Position;
            }
            else
            {
                tryType = null;
                tryProgression = 0;
                victimOfTry = null;
                tryEndTurnNumber = 0;
            }

            if (animals.Count > 0)
            {
                foreach (var ani in animals)
                {
                    if (!ani.IsLynx && ani.Species != myHareSpecies)
                    {
                        int numberOfCloserAllies = 0;
                        foreach (var other in animals)
                        {
                            if (other.IsLynx && IsSameSpecies(other) && Vector2D.Distance2(other.Position, (ani.Position + ani.Velocity * .01)) < Vector2D.Distance2(Position, (ani.Position + ani.Velocity * .01)))
                            {
                                numberOfCloserAllies++;
                            }
                        }
                        if (numberOfCloserAllies < 4)
                        {
                            Vector2D direction = (ani.Position + ani.Velocity * .01) - Position;
                            previousPosition = Position;
                            turnNumber++;
                            bool leftObstacle = false;
                            bool rightObstacle = false;
                            Vector2D polarAnimalDirection = direction.UnitVector().InPolar();
                            double minObstacleAngle = Math.PI / 4;
                            double angleOffset = Math.PI / 3;
                            foreach (VisibleObstacle obstacle in obstacles)
                            {

                                Vector2D polarObstacleDirection = (obstacle.Position - Position).UnitVector().InPolar();
                                if ((obstacle.ObstacleType == ObstacleType.Tree || obstacle.ObstacleType == ObstacleType.Water) && Vector2D.Distance2(obstacle.Position, Position) < Vector2D.Distance2((ani.Position + ani.Velocity * .01), Position))
                                {
                                    if (Math.Abs(polarAnimalDirection.Y - polarObstacleDirection.Y) < minObstacleAngle && polarAnimalDirection.Y - polarObstacleDirection.Y > 0)
                                    {
                                        rightObstacle = true;
                                    }
                                    else if (Math.Abs(polarAnimalDirection.Y - polarObstacleDirection.Y) < minObstacleAngle && polarAnimalDirection.Y - polarObstacleDirection.Y < 0)
                                    {
                                        leftObstacle = true;
                                    }

                                }
                            }

                            if (leftObstacle && leftObstacle)
                            {
                                Vector2D rightOffsetResult = (Vector2D.PolarVector(1, polarAnimalDirection.Y - angleOffset) + Position);
                                Vector2D leftOffsetResult = (Vector2D.PolarVector(1, polarAnimalDirection.Y + angleOffset) + Position);
                                Vector2D closestPoint = Vector2D.NullVector();
                                double closestDistance = double.MaxValue;
                                Vector2D[] cornerList = { new Vector2D(0, 0), new Vector2D(0, ArenaHeight), new Vector2D(ArenaWidth, 0), new Vector2D(ArenaWidth, ArenaHeight) };
                                foreach (Vector2D corner in cornerList)
                                {
                                    double aDistance = Vector2D.Distance2(corner, Position);
                                    if (closestDistance > aDistance)
                                    {
                                        closestPoint = corner;
                                        closestDistance = aDistance;
                                    }
                                }
                                if (Vector2D.Distance2(closestPoint, rightOffsetResult) > Vector2D.Distance2(closestPoint, leftOffsetResult))
                                {
                                    return ChangeVelocity(4 * Vector2D.PolarVector(1, polarAnimalDirection.Y - angleOffset));
                                }
                                else
                                {
                                    return ChangeVelocity(4 * Vector2D.PolarVector(1, polarAnimalDirection.Y + angleOffset));
                                }
                            }
                            else if (leftObstacle)
                            {
                                return ChangeVelocity(4 * Vector2D.PolarVector(1, polarAnimalDirection.Y - angleOffset));
                            }
                            else if (rightObstacle)
                            {
                                return ChangeVelocity(4 * Vector2D.PolarVector(1, polarAnimalDirection.Y + angleOffset));
                            }
                            else
                            {
                                return ChangeVelocity(direction.UnitVector() * 4);
                            }
                        }
                    }
                }
            }
            turnNumber++;
            previousPosition = Position;
            return ChangeVelocity(Vector2D.PolarVector(1, Random.NextDouble(0, 2 * Math.PI)));
        }
        private bool isOnEdge(VisibleAnimal animal)
        {
            Vector2D aniPos = animal.Position;
            return isOnEdge(aniPos);
        }
        private bool isOnEdge(Vector2D aniPos)
        {

            return aniPos.X >= 0 && aniPos.X <= .5 || aniPos.Y >= 0 && aniPos.Y <= .5 || aniPos.X <= ArenaWidth && aniPos.X >= ArenaWidth - .5 || aniPos.Y <= ArenaHeight && aniPos.Y >= ArenaHeight - .5;
        }
        private List<VisibleObstacle> GetOrderedObsticles()
        {
            return GetObstacles<Obstacle>().OrderBy(o => Vector2D.Distance2(o.Position, Position)).ToList();


        }
        private bool isAtCorner() {
            return (Vector2D.Distance2(Vector2D.NullVector(), Position) < 2|| Vector2D.Distance2(new Vector2D(ArenaWidth,ArenaHeight), Position) < 2 || Vector2D.Distance2(new Vector2D(0, ArenaHeight), Position) < 2 || Vector2D.Distance2(new Vector2D(ArenaWidth, 0), Position) < 2);
        }
    }
}