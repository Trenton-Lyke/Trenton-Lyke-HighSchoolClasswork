from graphics import *
import webbrowser
dictionary = {}
def findAverages(filename):
    global dictionary
    dataSet = open(filename,"r")
    dictionary = {}
    for aline in dataSet:
        values = aline.split("	")
        name = values[0]
        avg = 0
        for i in range(1,6):
            avg = avg + float(values[i])
        avg = avg/(len(values)-1)
        dictionary.update({name:avg})
        
    
def drawGraph():
    findAverages("grade.txt")
    win = GraphWin("Window", 600, 600)
    win.setCoords(0,0,600,600)
    yAxis = Line(Point(30,50),Point(30,550))
    xAxis = Line(Point(30,50),Point(590,50))
    xAxis.draw(win)
    yAxis.draw(win)
    x = 50
    scale = 5
    for i in range(21):
        numberScale = Text(Point(20,i*25+50),str(i*5))
        numberScale.setSize(5)
        numberScale.draw(win)
    for key in dictionary.keys():
        bar = Rectangle(Point(x,50),Point(x+50,50+5*dictionary[key]))
        bar.draw(win)
        name = Text(Point(x+25,45),str(key))
        name.setSize(5)
        name.draw(win)
        x = x+60
def main():
    userChoice = ""
    while userChoice.upper() != "Q": 
        userChoice = input("Which function would you like to use? findAverages or drawGraph: ")
        if userChoice.upper() == "FINDAVERAGES":
            findAverages("grade.txt")
        elif userChoice.upper() == "DRAWGRAPH":
            drawGraph()
        elif userChoice.upper() == "Q":
            print("Thank You!")
        else:
            print("That is not a valid input.")
def makeHTMLPage():
    findAverages("grade.txt")
    fontColor = input("What color would you like the text to be? Enter a general color. ex. blue: ").lower()
    fontSize = input("What size would you like the text to be? ex. 12: ")
    backgroundColor = input("What color would you like the background to be? Enter a general color. ex. blue: ").lower()
##    print("You chose a font color of",fontColor+", a font size of",fontSize+", and background color of",backgroundColor)
    data = """<!DOCTYPE html><html><head><title>Data</title><style>body{{background-color:{2};color:{0};font-size:{1}}} img{{width:100px; height:100px}}</style></head><body><h1>here is your graph for student score average</h1><img src="apple.jpg"/><p>hi my name is billy bob joe and i am the one and only potatoe</p></body></html>""".format(fontColor,fontSize,backgroundColor)
    f = open("summary.html","w")    
    f.write(data)
    f.close()
    webbrowser.open_new_tab('summary.html')
makeHTMLPage()

    
