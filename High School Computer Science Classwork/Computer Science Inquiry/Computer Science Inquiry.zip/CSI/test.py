from graphics import*
from random import *
list_1 = [3,85,45,23]
win = GraphWin("", 600,600)
entry1 = Entry(Point(win.getWidth()/2,200),10)
entry1.draw(win)
win.getMouse()
name = entry1.getText()
nameList = []
i = 0
while name != "q":
    nameList.append(int(name))
    firstPoint = win.getMouse()
    name = entry1.getText()
    randPoint = Point(randint(0,win.getWidth()),list_1[i%4])
    userLines = Line(firstPoint, randPoint)
    userLines.draw(win)
    i = i+1
print(nameList)
firstPoint = win.getMouse()
for i in range(10):
    randPoint = Point(randint(0,win.getWidth()),nameList[randint(0,len(nameList))])
    userLines = Line(firstPoint, randPoint)
    userLines.draw(win)
    firstPoint = randPoint
    i = i+1
print(nameList)
