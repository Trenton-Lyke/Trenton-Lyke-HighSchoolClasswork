import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
public class NameRecords {

	public NameRecords(String name, int [] rank) {
		
		
	}
	public static void main(String[] args) {
		File file = new File("names.txt");
		Scanner lenghtFinder;
		int rows = 0; 
		int coloumns = 0;
		try {
			lenghtFinder = new Scanner(file);
			String[] splitLineA = null;
			while(lenghtFinder.hasNextLine()) {
				splitLineA = lenghtFinder.nextLine().split("\\s+");
				rows = rows + 1;
			}
			coloumns = splitLineA.length;
			lenghtFinder.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String[][] Data = new String[rows][coloumns];
		try {
			Scanner sc = new Scanner(file);
			int i = 0;
			while(sc.hasNextLine()) {
				String[] splitLine = sc.nextLine().split("\\s+");
				for(int j = 0; j < splitLine.length; j++) {
					Data[i][j] = splitLine[j];
				}
				i = i + 1;
			
			}
			System.out.println(Data[0][0]);
			sc.close();
		}
		catch (FileNotFoundException e) {
	        e.printStackTrace();
		}
	}
		
	
}