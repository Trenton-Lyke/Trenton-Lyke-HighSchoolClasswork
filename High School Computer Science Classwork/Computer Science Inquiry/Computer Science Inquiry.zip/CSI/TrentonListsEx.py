#Trenton Lyke 11/16/2017 Exploring lists and its methods
#The first part of this program allows the user to enter numbers into a list and multiply them by a scalar
#The second part of this program allows the user to enter a string and replace a substring with a new substring
#The third part of this program allows the user to enter a numbers for heights of a bars, the bars are graphed, sorted from least to greatest, and graphed again

#imports modules used in the program
from graphics import *
from random import *

#function returns a random color
def randomColor():
   return color_rgb(randint(0,255),randint(0,255),randint(0,255))

#function multiplies each number in a list by a scalar
def scalar_mult(scalar, myList):
   newList = []
   print("my original list is: ",myList)
   for i in range(len(myList)):
      newList.append(scalar*myList[i])
   print("my modified list is: ",newList)

#function replaces a subtring of a string with a new substring
def replaceString(string, oldSubstring, newSubstring):
   print("your old string was",string)
   print("your new string is",string.replace(oldSubstring,newSubstring))

#function creates a graph based on a list of numbers
def createGraph(Mylist,colors):
   #creates window for graph
   win = GraphWin("Window", 500, 500)
   win2 = GraphWin("Window2", 500, 500)
   #values for formatting bars
   point1 = Point(10,10)
   barWidth = 20
   space = 5
   bars = []
   bars1 = []
   #formatting of bars
   for i in range(len(Mylist)):
       pointTop = Point(point1.getX()+(barWidth + space)*i,point1.getY())
       pointBottom = Point(pointTop.getX()+barWidth, point1.getY()+Mylist[i])
       Bar = Rectangle(pointTop,pointBottom)
       Bar.setFill(colors[i])
       Bar2 = Rectangle(pointTop,pointBottom)
       Bar2.setFill(colors[i])
       bars.append(Bar2)
       #draws bars
       Bar.draw(win)
   #sort height value list
   Mylist.sort(key=int)
   #draws sorted bars
   for j in range(len(rectangleSort(bars))):
       #gets where bars top left point should be
       pointTop = Point(point1.getX()+(barWidth + space)*j,point1.getY())
       #moves bar to where it should be  
       rectangleSort(bars)[j].move(pointTop.getX()-rectangleSort(bars)[j].getP1().getX(),0)
       #draws bars
       rectangleSort(bars)[j].draw(win2)
       
#sorts list rectangles by point 2 y values(height) and returns that list   
def rectangleSort(Mylist):
   newList = []
   shortenedList = []
   #makes a list that can be shortened for later using Mylist
   for i in range(len(Mylist)):
      shortenedList.append(Mylist[i])
   #makes sorts the rectangles within the shortenedlist and enters them into a new list
   for j in range(len(Mylist)):
      smallestY = shortenedList[0].getP2().getY()
      removeIndex = 0
      for k in range(len(shortenedList)):
         if smallestY > shortenedList[k].getP2().getY():
            smallestY = shortenedList[k].getP2().getY()
            removeIndex = k
      newList.append(shortenedList[removeIndex])
      shortenedList.pop(removeIndex)
   #returns the sorted rectangle list      
   return newList

         
   
#function checks to see if list has values in it and if it does it calls upon the createGraph function
def checkGraph(Mylist, colors):
    if len(Mylist) == 0:
        print("list is empty, cannot process it")
    else:
        createGraph(Mylist, colors)

#makes a line graph with given information
def lineGraph(names, ranks):
   #creates window and draws axises
   win = GraphWin("Window", 700, 700)
   yAxis = Line(Point(50,20),Point(50,550))
   xAxis = Line(Point(50,550),Point(650,550))
   yAxis.draw(win)
   xAxis.draw(win)
   #draws line of line graph and the x axis's labels
   for i in range(10):
      if i < 9:
         QB_Rank = Line(Point(50 * (i + 2), 550-(5*ranks[i])),Point(50 * (i + 3), 550-(5*ranks[i+1])))
         QB_Rank.draw(win)
      QB_Name = Text(Point(50 * (i + 2),560),names[i][0])
      QB_Name.draw(win)
   #draws scale
   for i in range(36):
      scaleNumber = 3*i
      QB_Name = Text(Point(35,550-i*15),str(scaleNumber))
      QB_Name.draw(win)
#Exercise 1
#gets user input for a scalar 
userScalar = float(input("please give me a number to multiply list elements: "))
#gets user input for numbers and then the numbers are put in a list
ans = input("please give me a number or 'q' to quit: ")
userList = []
while ans != 'q':
    userList.append(float(ans))
    ans = input("please give me a number or 'q' to quit: ")
#checks to see if list has values and if it does the scalar_mult function is called upon using the user input 
if len(userList) == 0:
    print("list is empty, cannot process it")
else:
    scalar_mult(userScalar,userList)

#Exercise 2
#gets user input for a string
text = input("please give me a string to modify: ")
#gets user input for a substring of the string
old = input("please give me a string that you want to replace: ")
#gets user input for a new substring that the user wants to rlace the previouly mentioned one with.
new = input("please give me a string that you want to replace it with: ")
#the replaceString function is called upon using the user input 
replaceString(text,old,new)

#Exercise 3

userGraphList = []
randomColors = []
#gets user input for a heights of bars and inputs numbers into a list
graphAns = input("please give me a number less than or equal to 490 for a height of a bar or 'q' to quit: ")
while graphAns != 'q':
    while float(graphAns) > 490:
        print("please make sure it's less than or equal to 490")
        graphAns = input("please give me a number less than or equal to 490 for a height of a bar or 'q' to quit: ") 
    userGraphList.append(float(graphAns))
    graphAns = input("please give me a number less than or equal to 490 for a height of a bar or 'q' to quit: ")
    randomColors.append(randomColor())
#calls upon the checkGraph function with the list
checkGraph(userGraphList, randomColors)

#Exercise 4
#opens data set
dataSet = open("data.txt","r")
QB_names = []
QB_rank = []
#makes list of names and a list of ranks
for lines in dataSet:
   values = lines.split()
   QB_names.append(values[0]+" "+values[1])
   QB_rank.append(float(values[10]))
#calls upon lineGraph function to make a line graph with the information
lineGraph(QB_names,QB_rank)


        
    
