list1 = ['1', '2', '3']
str1 = ','.join(list1)
print(str1)
