# Trenton Lyke 11/6/2017 Exploring how to write a loop and conditional statements
playChoice = ""
while playChoice != "YES" and playChoice != "NO":
   playChoice = input("Would you like to play madlib? yes or no: ").upper()
   if playChoice != "YES" and playChoice != "NO":
      print("Please answer yes or no.")
while playChoice == "YES":
   verb = input("Please enter a verb: ")
   noun = input("Please enter a noun: ")
   adjective = input("Please enter an adjective: ")
   adverb = input("Please enter an adverb: ")
   choice = ""
   while choice != "1" and choice != "2" and choice != "3":
      choice = input("please inter 1,2, or 3 to choose a story: ")
      if choice != "1" and choice != "2" and choice != "3":
         print("Please answer 1,2, or 3.")
   if choice == "1":
      print("Billy loved to",verb+", but one day a",noun,"destroyed his village. That is when Billy's",adjective,"friend started spitting bars and the",noun,
"froze because of his cold beats. Billy covered his ears as",adverb,"as he could, but the cold beats got to him. From that day on Billy could never",verb,adverb,
"again. That was when Billy knew he had to blow up the universe. For without his ability to",verb,"the world would be in agonizing pain. However, Billy's",adjective,
"friend believed he could save the world with his ability to",verb+". So the only logical solution was a",verb,
"battle. Ten minutes in everybody lost their souls to an evil potatoe. This begs the question if we all could",verb,"then would we all lose our souls?")
   elif choice == "2":
      print("Billy hated to",verb+", but one day a",noun,"built a house in his village. That is when Billy's",adjective,"enemy started spitting bars and the",noun,
"caught on fire because of his fire beats. Billy covered his ears as",adverb,"as he could, but the fire beats got to him. From that day on Billy could",verb,adverb,
". That was when Billy knew he had to save the world. For with his ability to",verb,"the world would not be in agonizing pain. However, Billy's",adjective,
"enemy believed he could blow up the universe with his lack of ability to",verb,adverb+". So the only logical solution was a",verb,
"battle. Five minutes in everybody lost their souls to an evil potatoe. This begs the question if we all could not",verb,"then would we all lose our souls?")
   elif choice == "3":
      print("Gary hated to",verb+", but one day a",noun,"started to",verb,"in his village. That is when Gary's",adjective,"frenemy started eating pizza pies and the",noun,
"explode because of his pizza pie eating prowess. Gary covered his eyes as",adverb,"as he could, but the pizza pies got to him. From that day on Gary could never",verb,adverb,
"again. That was when Gary knew he had to save the universe by blowing up the world. For without his ability to",verb,"the world may or may not be in agonizing pain. However, Billy's",adjective,
"frenenemy believed he could detsroy the universe by saving the world with his lack of ability to",verb,adverb+". So the only logical solution was a",verb,
"battle. Two minutes in everybody lost their souls to an evil potatoe. This begs the question if we all could",verb,"then would we all lose our souls?")
   else:
      print("You did not make a correct choice.")
   playChoice = input("Would you like to play madlib? yes or no: ").upper()
   while playChoice != "YES" and playChoice != "NO":
      playChoice = input("Would you like to play madlib? yes or no: ").upper()
      if playChoice != "YES" and playChoice != "NO":
         print("Please answer yes or no.")
print("Thank you for playing")
   

