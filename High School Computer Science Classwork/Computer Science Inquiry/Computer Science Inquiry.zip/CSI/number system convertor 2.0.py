import math
def OtherToDecimal(n, bi, s):
    return n * (bi**s)
def DecimalToOther(a, bf):
    return str(int(a%bf))
done = 'NO'
while done != 'YES':
    baseInt = float(input("What is the base of the number you want to convert: "))
    baseFin = int(input("What is the base you want to convert it to: "))
    number = input("What is the number you want to convert: ")
    answero = ''
    answerd = 0
    seq, seqInv = float(0), len(number)-1
    didget = ''
    while seqInv > -1:
        didget = number[seqInv]
        if didget == 'A':
            didget = 10
        elif didget == 'B':
            didget = 11
        elif didget == 'C':
            didget = 12
        elif didget == 'D':
            didget = 13
        elif didget == 'E':
            didget = 14
        elif didget == 'F':
            didget = 15
        didget = float(didget)    
        answerd = answerd + OtherToDecimal(didget, baseInt, seq)
        seq = seq + 1
        seqInv = seqInv - 1 
    print ("Number in base 10: " + str(answerd))
    ans = str(answerd)
    seq, seqInv = float(0), len(ans)-1
    didget = 0
    didget2 = ''
    answerd = int(answerd)
    while answerd > 0:    
        didget2 = DecimalToOther(answerd, baseFin)
        answerd = math.floor(answerd/baseFin)
        if didget2 == '10':
            didget2 = 'A'
        elif didget2 == '11':
            didget2 = 'B'
        elif didget2 == '12':
            didget2 = 'C'
        elif didget2 == '13':
            didget2 = 'D'
        elif didget2 == '14':
            didget2 = 'E'
        elif didget2 == '15':
            didget2 = 'F'
        answero = didget2 + answero
        seq = seq + 1
        seqInv = seqInv - 1
    print("Number in base " + str(baseFin) + ": " + str(answero))
    done = input("Are you done? yes or no: ")
    done = done.upper()
    

    
    


