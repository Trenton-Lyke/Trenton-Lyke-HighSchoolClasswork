#Trenton Lyke 11/16/2017 Exploring lists and its methods
number = []
for i in range(100,10,-1):
    number.append(i)
print(number)

nouns = ["7","5","1"]
print(len(nouns))
print(nouns[1])
nouns.sort()
print(nouns)
