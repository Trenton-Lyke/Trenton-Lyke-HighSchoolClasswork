from graphics import*
from random import*
#function generates a random color
def color():
    red = randint(0, 255)
    green = randint(0, 255)
    blue = randint(0, 255)
    col = color_rgb(red, green, blue)
    return col
#main function is run when program is initialized
def main():
    circleList = []
    UserChoice = input("What number of cocentric circles would you like to make between 1 and 12? Enter q to quit: ")
    while UserChoice.lower() != 'q':
        loopbreaker = False
        if int(UserChoice) > 12 or int(UserChoice) < 1:
            UserChoice = input("Please make sure your number is between 1 and 12? Enter q to quit: ")
        else:
            circleList.append(int(UserChoice))
            UserChoice = input("What number of cocentric circles would you like to make between 1 and 12? Enter q to quit: ")
    createCircles(circleList)
#draws cirles from list
def createCircles(myList):
    win = GraphWin("Circles Lab", 800, 800)
    win.setBackground("blue")
    for item in myList:
        user_Mouse = win.getMouse()
        for i in range(item):
            userCircle = Circle(user_Mouse,100 - i*5)
            userCircle.setFill(color())
            userCircle.draw(win)
    CirclesDrew = Text(Point(100,500),"You drew "+str(len(myList))+" circles")
    CirclesDrew.draw(win)
    toQuit = Text(Point(100,10),"Click to close the window")
    toQuit.setTextColor('white')
    toQuit.draw(win)
    win.getMouse()
    win.close()
    
            
main()      
