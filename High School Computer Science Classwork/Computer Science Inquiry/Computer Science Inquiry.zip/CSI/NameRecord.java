import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
public class NameRecord {

	public NameRecord(String name, int [] rank) {
		
		
	}
	public static void main(String[] args) {
		File file = new File("data.text");
		try {
			Scanner sc = new Scanner(file);
			
			while(sc.hasNextLine()) {
				int i = sc.nextInt();
				System.out.println(i);
			}
			sc.close();
		}
		catch (FileNotFoundException e) {
	        e.printStackTrace();
		}
	}
		
	
}
