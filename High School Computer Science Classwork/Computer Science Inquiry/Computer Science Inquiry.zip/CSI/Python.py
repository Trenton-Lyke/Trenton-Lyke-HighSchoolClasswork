#imported math so that I could use square root function
import math

#function converts grams into ounces
def gramsToOunces():
    #gets user input for grams
    grams = float(input("\nPlease enter a mass in grams: "))
    #converts grams to ounces
    ounces = grams * 28.3495231
    #prints amount in ounces
    print(ounces,"\n")

#function determines the amount obtained by investing the principal (P) for (N) years at the rate of (R).
def compoundIntrest():
    #gets user input for principle amount
    P = float(input("\nPlease enter a principal amount: "))
    #gets user input for rate
    R = float(input("Please enter an intrest rate as a decimal: "))
    #gets user input for time span in year
    N = float(input("Please enter a span of time in years: "))
    #calculates amount obtained
    A = P*(1+R)**N
    #prints amount obtained
    print(A,"\n")

#function determines the x-values of the zeros of a quadratic function given coefficents within the equation
def quadraticEquation():
    #gets user input for leading coefficient
    a = float(input("\nPlease enter the coefficent of term with a degree of 2 within your quadratic function: "))
    #makes sure user input is not 0
    while a == 0:
        #prints error message
        print("error: your equation is not quadratic if the coefficent of term with a degree of 2 is 0.")
        #gets user input for leading coefficient 
        a = float(input("Please make sure that the leading coefficient is a non-zero number: "))
    #gets user input for 1st degree term
    b = float(input("Please enter the coefficent of the term with a degree of 1 within your quadratic function: "))
    #gets user input for 0th degree term
    c = float(input("Please enter the coefficent of the term with a degree of 0 within your quadratic function: "))
    #calculates the x-values of the zeros of a quadratic function
    xValue1 = (-b+math.sqrt(b**2-4*a*c))/(2*a)
    xValue2 = (-b-math.sqrt(b**2-4*a*c))/(2*a)
    #prints the x-values of the zeros of a quadratic function
    print("x =",xValue1,"\tx =",xValue2,"\n")

#function determines which numbers between 2000 and 3200 that are divisible by 7, but not divisible by 5
def specialNumbers():
    #creates a variable for the sequence of numbers
    commaSeperatedSequence = ""
    #loops for ever all numbers between 2000 and 3200
    for i in range(2000,3201):
        #runs code if number is divisible by 7
        if i%7 == 0:
            #runs code if number is not divisible by 5
            if i%5 != 0:
                #runs code if the sequence has no numbers
                if commaSeperatedSequence == "":
                    #adds a number to the sequence
                    commaSeperatedSequence = commaSeperatedSequence + str(i)
                #runs code if the sequence has numbers
                else:
                    #adds a comma, space, and number to the sequence
                    commaSeperatedSequence = commaSeperatedSequence + ", " + str(i)
    #prints sequence
    print(commaSeperatedSequence,"\n")       

#function asks which function the user would like to use
def main():
    #creates a variable for users decision
    decision = ""
    #loops while user does not enter quit
    while decision != "QUIT":
        #prints directions for user
        print("""To convert a value in grams to ounces, please enter 1.
           \nTo use an investment calculator, please enter 2.
           \nTo use a quadratic equation calculator, please enter 3.
           \nTo find all of the numbers between 2000 and 3200 that are divisible by 7, but not divisible by 5, please enter 4.
           \nTo quit, please enter quit.""")
        #gets user input for decision
        decision = input("What would you like to do?: ").upper()
        #checks to see if decision is a valid input
        while decision != "1" and decision != "2" and decision != "3" and decision != "4" and decision != "QUIT":
            #prints directions again
            print("""To convert a value in grams into ounces, please enter 1.
               \nTo use an investment calculator, please enter 2.
               \nTo use a quadratic equation calculator, please enter 3.
               \nTo find all of the numbers between 2000 and 3200 that are divisible by 7, but not divisible by 5, please enter 4.
               \nTo quit, please enter quit""")
            #gets user input for decision
            decision = input("Please enter 1,2,3,4, or quit: ").upper()
        #runs if decision is 1
        if decision == "1":
            #calls gramsToOunces() function
            gramsToOunces()
        #runs if decision is 2
        elif decision == "2":
            #calls compoundIntrest() function
            compoundIntrest()
        #runs if decision is 3
        elif decision == "3":
            #calls quadraticEquation() function
            quadraticEquation()
        #runs if decision is 4
        elif decision == "4":
            #calls specialNumbers() function
            specialNumbers()
#calls on main function
main()


