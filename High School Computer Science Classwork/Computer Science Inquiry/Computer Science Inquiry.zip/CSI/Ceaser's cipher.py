alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
def letterSearch(letter):
    letterPresence = False
    letter = letter.upper()
    for i in range(len(alphabet)):
        if letter == alphabet[i]:
            letterPresence = True
            letterPlace = i
    if letterPresence == True:
        return letterPlace
    elif letterPresence == False:
        return "Character is not present in alphabet."
def messageShift(message, key, cryption):
    finMessage = ""
    for i in range(len(message)):
        if type(letterSearch(message[i])) == int:
            if cryption == "ENCRYPTION":
                CipherLetterPlace = (key + letterSearch(message[i]))%26
            elif cryption == "DECRYPTION":
                CipherLetterPlace = (-key + letterSearch(message[i]))%26
            if message[i] == message[i].upper():
                finMessage = finMessage + alphabet[CipherLetterPlace]
            elif message[i] == message[i].lower():
                finMessage = finMessage + alphabet[CipherLetterPlace].lower()
        else:
            finMessage = finMessage + message[i]
    return finMessage
choice = ""
while choice != "YES" and choice != "NO":
   choice = input("Would you like to use Caesar's cipher? yes or no: ").upper()
   if choice != "YES" and choice != "NO":
      print("Please answer yes or no.")
while choice == "YES":
    userInputCryption = ""
    while userInputCryption != "ENCRYPTION" and userInputCryption != "DECRYPTION" and userInputCryption != "DECODE":
        print("*Ecryption will change a message into a code using a key.\n*Decryption will change a code into a message using a key.\n*Decode will show all possibilites of what the code's original message was.")
        userInputCryption = input("Enter encryption, decryption, or decode: ").upper()
        if userInputCryption != "ENCRYPTION" and userInputCryption != "DECRYPTION" and userInputCryption != "DECODE":
            print("Please enter encryption, decryption, or decode.")
    userInputMessage = input("Enter a message: ")
    if userInputCryption == "ENCRYPTION" or userInputCryption == "DECRYPTION":
        userInputKey = ""
        while type(userInputKey) != int:
            print("*For integer keys, a positive integer will shift letters counter-clockwise and a negative integer will shift letters clockwise")
            try:
                userInputKey = int(input("Enter an integer key: "))
                break
            except ValueError:
                print("Please enter an integer.")
    if userInputCryption == "ENCRYPTION" or userInputCryption == "DECRYPTION": 
        print(messageShift(userInputMessage, userInputKey, userInputCryption))
    elif userInputCryption == "DECODE":
        for i in reversed(range(27)):
            if i < 26:
                print("Message was shifted",26-i,"Counter-clockwise:",messageShift(userInputMessage, -i, "DECRYPTION"))
    choice = ""
    while choice != "YES" and choice != "NO":
       choice = input("Would you like to use Caesar's cipher? yes or no: ").upper()
       if choice != "YES" and choice != "NO":
          print("Please answer yes or no.")
print("Thank you for using Caeser's cipher.")
