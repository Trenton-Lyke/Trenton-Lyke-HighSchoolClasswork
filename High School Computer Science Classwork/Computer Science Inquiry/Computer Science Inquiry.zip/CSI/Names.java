
public class Names {

	public Names(NameRecords name) {
		
	}
}
