# Trenton Lyke 11/13/2017 Graphics Exercise
from graphics import *
from random import *
from time import *
def main():
        win = GraphWin("2 Da Window", 500, 500)
        win.setBackground("red")
        for i in range(6):
            circle = Circle(Point(250,250),50-i*5)
            circle.setFill(color_rgb(randint(0,255),randint(0,255),randint(0,255)))
            circle.draw(win)
        win.getMouse() # pause for click in window
        win.close()
main()
