# Trenton Lyke 11/2/2017 Exploring Python Basics
degrees_Farenheit = input("Temperature in degrees Fahrenheit: " )
try:
   degrees_Farenheit = float(degrees_Farenheit)
except ValueError:
   print("That's not an int!")
degrees_Celsius = (degrees_Farenheit - 32) * (5/9)
print(degrees_Farenheit,"°F = ",degrees_Celsius,"°C")
print ("\  |  /\n"," @ @\n","  *\n","""\\""\"/""")
# I couldn't remember which way you wanted us to do this
print(
    """
\  |  /
  @ @
   *
 \\""\"/
""")
color_favorite = input("Favorite color: ")+" "
indentation_length = len(color_favorite)*10-len(color_favorite)*2
print(color_favorite*10)
print(color_favorite+" "*indentation_length+color_favorite)
print(color_favorite+" "*indentation_length+color_favorite)
print(color_favorite*10)
answer = input("Do you like Python? ")
answer = answer.upper()
if answer == "YES":
    print("That is great!")
elif answer == "NO":
    print("That is disappointing!")
else:
    print("That is not an answer to my question.")    




