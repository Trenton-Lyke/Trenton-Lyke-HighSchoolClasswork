# Trenton Lyke 11/9/2017 Albert Einstein Problem
#function makes user enter yes or no when deciding to play returns that value
def checkPlayChoice(UserPlayChoice):
    while UserPlayChoice != "YES" and UserPlayChoice != "NO":
       UserPlayChoice = input("Would you like to try Eistein's Puzzle? yes or no: ").upper()
       if UserPlayChoice != "YES" and UserPlayChoice != "NO":
          print("Please answer yes or no.")
    return UserPlayChoice
#initializes variable playChoice as nothing
playChoice = ""
#call upon checkPlayChoice funtction and makes variable playChoice the same as what the user enters
playChoice = checkPlayChoice(playChoice)
#loop runs while user enters yes
while playChoice == "YES":
    #description of Einstein's Puzzle
    print("This is Einstein's Puzzle. You are going to be asked for a three digit whole number, which has a difference of atleast two between hundred's place value and one's place value. The procedur will always yield 1089.")
    #initializes variable playChoice as False so loop will run
    validNumber = False
    #loop runs while user hasn't enter a number that meets all of the requirements
    while validNumber == False:
        #makess variable playChoice as True so loop won't run if all requirements are met
        validNumber = True
        #checks to see if making user input an int will cause an error
        try:
            number = int(input("Enter a three digit whole number, which has a difference of atleast two between hundred's place value and one's place value: "))
        except ValueError:
            #makes variable playChoice False so loop will run
            validNumber = False
            #gives directions again
            print("Make sure you have entered a whole number")
            #restarts loop
            continue
        #checks to see if number is a positive three digit number
        if number >= 1000 or number <= 99:
            #makes variable playChoice False so loop will run
            validNumber = False
            #gives directions again
            print("Make sure you enter a three digit whole number.")
            #restarts loop
            continue
        #makes variable reversedOnesPlace the hundreds place digit of user input
        reversedOnesPlace = number//100
        #makes variable reversedTensPlace the tens place digit of user input
        reversedTensPlace = (number%100)//10
        #makes variable reversedHundredsPlace the ones place digit of user input
        reversedHundredsPlace = (number%10)
        #makes variable differenceCheck the difference of the ones place digit of user input and the hundreds place digit of user input
        differenceCheck = abs(reversedOnesPlace - reversedHundredsPlace) 
        if(differenceCheck < 2):
            #makes variable playChoice False so loop will run
            validNumber = False
            #gives directions again
            print("Make sure you enter a number, which has a difference of atleast two between hundred's place value and one's place value.")
            #restarts loop
            continue
    #makes variable reversedNumber reversed version of user input
    reversedNumber = reversedHundredsPlace*100+reversedTensPlace*10+reversedOnesPlace
    #makes variable difference the defference of the reversed version of user input and the user input
    difference = abs(reversedNumber-number)
    #prints user input and reversed version of user input
    print("For the number:",number,"the reversed number is:",reversedNumber)
    #prints user input, reversed version of user input, and difference between the two numbers
    print("The difference between",number,"and",reversedNumber,"is",difference)
    #makes variable reversedOnesPlace the hundreds place digit of difference
    reversedOnesPlace = difference//100
    #makes variable reversedTensPlace the tens place digit of difference
    reversedTensPlace = (difference%100)//10
    #makes variable reversedHundredsPlace the ones place digit of difference
    reversedHundredsPlace = (difference%10)
    #makes variable reversedNumber reversed version of difference
    reversedDifference = reversedHundredsPlace*100+reversedTensPlace*10+reversedOnesPlace
    #prints reversed version of the difference
    print("The reverse difference is:",reversedDifference)
    #prints difference of reversed version of user input, reversed version of user input, and difference between the two numbers
    print("The sum of:",abs(reversedNumber-number),"and",reversedDifference,"is:",abs(reversedNumber-number)+reversedDifference)
    #asks user if they want to try Eistein's Puzzle
    playChoice = input("Would you like to try Eistein's puzzle? yes or no: ").upper()
    #gives directions again if user does not use yes or no
    if playChoice != "YES" and playChoice != "NO":
          print("Please answer yes or no.")
    #call upon checkPlayChoice funtction and makes variable playChoice the same as what the user enters
    playChoice = checkPlayChoice(playChoice)
#prints a thankful statement
print("Thank you for playing.")
    
    
    
    




