#Trenton Lyke 10/30/2017 Python Program
print(5+4/3)
avg = (5+6)/2
print(avg)
