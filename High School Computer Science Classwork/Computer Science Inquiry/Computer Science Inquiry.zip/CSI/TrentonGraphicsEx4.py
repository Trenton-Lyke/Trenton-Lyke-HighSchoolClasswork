# Trenton Lyke 11/13/2017 Graphics Exercise
from graphics import *
from random import *
from time import *
def main():
    for b in range(10):
        win = GraphWin("2 Da Window", 500, 500)
        win.setBackground("red")
        circleLT = Circle(Point(10,10),10)
        circleLT.setFill(color_rgb(255,0,0))
        circleLT.draw(win)
        circleRT = Circle(Point(490,10),10)
        circleRT.setFill(color_rgb(0,255,0))
        circleRT.draw(win)
        circleLB = Circle(Point(10,490),10)
        circleLB.setFill(color_rgb(0,0,255))
        circleLB.draw(win)
        circleRB = Circle(Point(490,490),10)
        circleRB.setFill(color_rgb(255,255,0))
        circleRB.draw(win)
        x = 1
        for i in range(240):
            circle = Circle(Point(250,250),241-i)
            circle.setFill(color_rgb(randint(0,255),randint(0,255),randint(0,255)))
            circle.draw(win)
            print(randint(1,1000))
            circleLT.move(1,1)
            circleRT.move(-1,1)
            circleLB.move(1,-1)
            circleRB.move(-1,-1)
            sleep(.005)
        for i in range(240):
            circleLT.move(-1,-1)
            circleRT.move(1,-1)
            circleLB.move(-1,1)
            circleRB.move(1,1)
            sleep(.005)    
        win.getMouse() # pause for click in window
        win.close()
main()
