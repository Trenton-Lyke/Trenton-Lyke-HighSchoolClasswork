#Resources: https://stackoverflow.com  https://runestone.academy  Mrs. Pandya
#this project analyzes stock from apple it calcualtes and graphs
#average closing costs, graphs daily closing costs and volume,
#and makes a webpage from the graphs and user input.
#the project works with list, files, and functions.

#imports need modules
from graphics import *
from random import *
from datetime import *
from time import *
import webbrowser
#function returns a random color
def randomColor():
   return color_rgb(randint(0,255),randint(0,255),randint(0,255))
#function puts data into a 2D list for later use
def read_data(filename):
    lineCount = 0
    data = []
    #opens data set
    dataSet = open(filename,"r")
    for lines in dataSet:
        if lineCount > 0:
           values = lines.split(",")
           data.append(values)
        lineCount = lineCount + 1
    #returns Data
    return data
def createDictionary():
   regionDict = {}
   data = read_data("State_Data.csv")
   for lists in data:
      if lists[1] in regionDict:
         regionDict.setdefault(lists[1], []).append(lists[0])
         
      else:
         regionDict.update({lists[1]:[lists[0]]})
   return regionDict
def createContent():
   regionStr = ""
   regionDict = createDictionary()
   for regions in regionDict:
      regionStr = regionStr + regions+": "+', '.join(regionDict[regions])+ "<br/>"

   return regionStr
def avgPersonalIncome():
   data = read_data("State_Data.csv")
   stateAbbreviations = ["AL", "AK", "AZ", "AR",  "CA", "CO", "CT", "DE", "DC","FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS",  "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO",  "MT", "NE","NV", "NH", "NM", "NJ", "NY", "NC",  "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD",  "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"]
   stateDict = {}
   stateCount = 0
   dataTypes = 9
   populationIndex = 2
   incomeIndex = 4
   for abrreviations in stateAbbreviations:
      stateDict.update({abrreviations:(float(data[stateCount][incomeIndex])*1000000000)/(float(data[stateCount][populationIndex])*1000000)})
      stateCount = stateCount + 1
   return stateDict
def populationAndGDP():
   data = read_data("State_Data.csv")
   regionDict = createDictionary()
   populationAndGPDDict = {}
   for regions in regionDict:
      regionPopulation = 0
      regionGDP = 0
      for lists in data:
        if lists[1] == regions:
           regionPopulation = regionPopulation + float(lists[2])
           regionGDP = regionGDP + float(lists[3])
      populationAndGPDDict.update({regions:[regionPopulation,regionGDP]})
   return populationAndGPDDict

def graphAvgPersonalIncome():
   stateDict = avgPersonalIncome()
   #sets up window with graph axis's and direction's
   win = GraphWin("Average Personal Income per State", 800, 700)
   win.setCoords(0,0,700,700)
   title = Text(Point(400,685), "Average Personal Income by State")
   title.setSize(18)
   title.draw(win)
   directions = Text(Point(40,660), "Click in the window to \nclose it and continue.")
   directions.setSize(5)
   directions.draw(win)
   yAxis = Line(Point(40,650),Point(40,50))
   xAxis = Line(Point(40,50),Point(660,50))
   yAxis.draw(win)
   xAxis.draw(win)
   yAxisLabel = "Average Personal Income"
   i = 0
   #creates title for y-axis
   for char in yAxisLabel:
      letter = Text(Point(10,500-i*12),char)
      letter.setSize(10)
      letter.draw(win)
      i = i + 1
   #label's y-axis
   for i in range(61):
      scaleNumber = 1500*i
      scale = Text(Point(30,50+i*10),str(scaleNumber))
      scale.setSize(5)
      scale.draw(win)
   xAxisLabel = Text(Point(400,20),"States")
   xAxisLabel.setSize(10)
   xAxisLabel.draw(win)
   #lables x-axis, finds yearly average for closing costs, and graphs yearly average for closing costs.
   stateCount = 0
   for states in stateDict:
      #lables x-axis
      state = Text(Point(12 * (stateCount)+50,40), states)
      state.setSize(5)
      state.draw(win)
        
      #graphs yearly average for closing costs.
      bar = Line(Point(12 * (stateCount)+50,50),Point(12 * (stateCount)+50, 50 + stateDict[states]/150))
      bar.setWidth(5)
      bar.setFill(randomColor())
      bar.draw(win)
      stateCount = stateCount+1
   #waits for user to click in window to close it
   win.getMouse() 
   win.close()

def graphPopulationVsGDP():
   populationAndGPDDict = populationAndGDP()
   win2 = GraphWin("Population and GDP in each region of the US:", 700, 700)
   win2.setCoords(0,0,420,700)
   title = Text(Point(230,670), "Population and GDP in each region of the US:")
   title.setSize(18)
   title.draw(win2)
   title1 = Text(Point(210,620), "Population")
   title1.setSize(18)
   title1.draw(win2)
   title2 = Text(Point(210,330), "GPD")
   title2.setSize(18)
   title2.draw(win2)
   directions = Text(Point(55,660), "Click in the window to \nclose it and continue.")
   directions.setSize(5)
   directions.draw(win2)
   yAxis1 = Line(Point(65,320),Point(65,50))
   yAxis2 = Line(Point(65,350),Point(65,600))
   xAxis1 = Line(Point(65,50),Point(415,50))
   xAxis2 = Line(Point(65,350),Point(415,350))
   yAxis1.draw(win2)
   yAxis2.draw(win2)
   xAxis1.draw(win2)
   xAxis2.draw(win2)
   yAxisLabel = "Millions"
   i = 0
   #creates title for y-axis
   for char in yAxisLabel:
      letter = Text(Point(10,530-i*12),char)
      letter.setSize(10)
      letter.draw(win2)
      i = i + 1
   yAxisLabel = "Billions"
   i = 0
   #creates title for y-axis
   for char in yAxisLabel:
      letter = Text(Point(10,200-i*10),char)
      letter.setSize(8)
      letter.draw(win2)
      i = i + 1
   xAxisLabel = Text(Point(210,20),"Region")
   xAxisLabel.setSize(10)
   xAxisLabel.draw(win2)
   #labels y-axis with numbers to match scale of closing cost graph
   for i in range(26):
        scaleNumber = 4*i
        scale = Text(Point(50,350+10*i),str(scaleNumber))
        scale.setSize(5)
        scale.draw(win2)
   #labels y-axis with numbers to match scale of volume graph
   for i in range(28):
        scaleNumber = 150*i
        scale = Text(Point(40,50+10*i),str(scaleNumber))
        scale.setSize(5)
        scale.draw(win2)
   regionCount = 0
   #draws lines whose heights represent the a number relative to the scale and whose distance from the y-axis represents the date
   for regions in populationAndGPDDict:
      regionLables = Text(Point(85+40*regionCount,40),regions)
      regionLables.setSize(7)
      regionLables.draw(win2)
      volumeShape = Line(Point(85+40*regionCount,50),Point(85+40*regionCount,float(populationAndGPDDict[regions][1]/15) + 50))
      volumeShape.setWidth(20)
      volumeShape.setFill(randomColor())
      volumeShape.draw(win2)
      volumeShape1 = Line(Point(85+40*regionCount,350),Point(85+40*regionCount,float(populationAndGPDDict[regions][0]*(10/4)) + 350))
      volumeShape1.setWidth(20)
      volumeShape1.setFill(randomColor())
      volumeShape1.draw(win2)
      regionCount = regionCount + 1
   #waits for user to click in window to close it
   win2.getMouse() 
   win2.close()
def webPage():
   regionstr = createContent()
   #gets user input for web page styling and tells them what they chose
   fontColor = input("What color would you like the text to be? Enter a general color. ex. blue: ").lower()
   fontSize = input("What size would you like the text to be? Enter a whole number followed by pt. ex. 12pt: ")
   backgroundColor = input("What color would you like the background to be? Enter a general color. ex. blue: ").lower()
   print("You chose a font color of",fontColor+", a font size of",fontSize+", and background color of",backgroundColor)
   #creates a webpage using user input and opens it
   webPageHTML = """<!DOCTYPE html><html><head><link rel="icon" href="Money.jpg" type="image/jpg" sizes="16x16"/><title>State Data</title><style>body{{background-color:{2};color:{0};font-size:{1}; text-align: center}} table,tr,th,td{{padding: 0; margin: auto; border: 10px solid #4CAF50; border-collapse: collapse; }} h1{{text-shadow: 2px 2px 5px blue;}}img{{width:500px; height: 700px; margin: 5px}}</style></head><body><h1>Economic Data of Regions and States in the United States</h1><p>{3} <br/><b>Talk about trends and stuff here<b></p><table><tr><td><img src="PopulationvsGPDgraph.jpg" title="Population vs. GPD"/></td><td><img src="AveragePersonalIncomeGraph.jpg" title="Average Personal Income"></td></tr></table></body></html>""".format(fontColor,fontSize,backgroundColor,regionstr)
   f = open("summary.html","w")    
   f.write(webPageHTML)
   f.close()
   webbrowser.open_new_tab('summary.html')    
#asks user what they want to do and runs functions that will help them
def main():
    userChoice = ""
    while userChoice.upper() != "Q":
        print("This computer contains 3 functions that analyze data on apple stock.\n 1. Makes a graph of the average personal income per state in the United States.\n 2. Makes a graph of region's populations and region's GPD in the United States.\n 3. Makes a web page out of those graphs.")
        userChoice = input("Which function would like to run? Enter 1,2, or 3 for the functions or q to quit: ")
        if userChoice == '1':
            graphAvgPersonalIncome()
        elif userChoice == '2':
            graphPopulationVsGDP()
        elif userChoice == '3':
            webPage()
        elif userChoice.upper() == "Q":
            print("Thank You!")
        else:
            print("That is not a valid input.") 
   
#runs main function      
main()


###gets the first year
##def getFirstYear():
##    #calls upon read_data function to assign values to Global variable Data
##    read_data("AAPL.txt")
##    #sets firstDate to the numerical representation of the first date without the slashes
##    firstDate = Data[dateIndex][0].split("/")
##    #sets firstYear to the last value within the firstDate list which is the year value 
##    firstYear = firstDate[2]
##    #returns the integer form of the year
##    return int(firstYear)
###sets global variable yearIndex to a list of indexes within the Date list that start new years
##def getYearIndex():
##    #calls upon read_data function to assign values to Global variable Data
##    read_data("AAPL.txt")
##    #makes information stored in yearIndex in this function global and makes year Index an empty list
##    global yearIndex
##    yearIndex = []
##    #calls upon the getFirstYear function to set year to the first year within Data
##    year = getFirstYear()
##    #calls upon the getFirstYear function to add the first year within Data to the yearIndex list
##    yearIndex.append(getFirstYear())
##    #adds all years within data set other than the first into yearIndex list
##    for i in range(len(Data[dateIndex])-1):
##        date = Data[dateIndex][i].split("/")
##        if year < int(date[2]):
##            yearIndex.append(int(date[2]))
##        year = int(date[2])
###draws a bar graph of average closing costs
##def avgClosingCost():
##    #makes averageClosingCosts an empty list
##    averageClosingCosts = []
##    #calls upon read_data function to assign values to Global variable Data
##    read_data("AAPL.txt")
##    #calls upon getYearIndex function to assign values to Global variable yearIndex
##    getYearIndex()
##    #sets up window with graph axis's and direction's
##    win = GraphWin("Yearly Average Closing Cost", 410, 700)
##    win.setCoords(0,0,420,700)
##    title = Text(Point(210,685), "Yearly Average Closing Cost")
##    title.setSize(18)
##    title.draw(win)
##    directions = Text(Point(40,660), "Click in the window to \nclose it and continue.")
##    directions.setSize(5)
##    directions.draw(win)
##    yAxis = Line(Point(40,650),Point(40,50))
##    xAxis = Line(Point(40,50),Point(390,50))
##    yAxis.draw(win)
##    xAxis.draw(win)
##    yAxisLabel = "Average Closing Cost"
##    i = 0
##    #creates title for y-axis
##    for char in yAxisLabel:
##       letter = Text(Point(10,500-i*12),char)
##       letter.setSize(10)
##       letter.draw(win)
##       i = i + 1
##    #label's y-axis
##    for i in range(61):
##      scaleNumber = 10*i
##      scale = Text(Point(33,50+scaleNumber),str(scaleNumber))
##      scale.setSize(5)
##      scale.draw(win)
##    xAxisLabel = Text(Point(210,20),"Year")
##    xAxisLabel.setSize(10)
##    xAxisLabel.draw(win)
##    #lables x-axis, finds yearly average for closing costs, and graphs yearly average for closing costs.
##    for i in range(len(yearIndex)):
##        #lables x-axis
##        year = Text(Point(20 * (i + 3),40), str(getFirstYear()+i))
##        year.setSize(5)
##        year.draw(win)
##        #finds yearly average for closing costs
##        yearlyCloseSum = 0
##        days = 0
##        for j in range(len(Data[dateIndex])-1):
##           if int(Data[dateIndex][j][len(Data[dateIndex][j])-4:]) == yearIndex[i]:
##              yearlyCloseSum = yearlyCloseSum + float(Data[closeIndex][j])
##              days = days + 1
##        averageClosingCosts.append(yearlyCloseSum/days)
##        #graphs yearly average for closing costs.
##        bar = Line(Point(20 * (i + 3),50),Point(20 * (i + 3), 50 + averageClosingCosts[i]))
##        bar.setWidth(10)
##        bar.setFill(randomColor())
##        bar.draw(win)
##    #waits for user to click in window to close it
##    win.getMouse() 
##    win.close()
###graphs daily closing cost and daily trade volume
##def closingVsVolume():
##   #calls upon read_data function to assign values to Global variable Data
##   read_data("AAPL.txt")
##   #calls upon getYearIndex function to assign values to Global variable yearIndex
##   getYearIndex()
##   #draws graph titles, directions, and axises
##   win2 = GraphWin("Closing Cost vs. Trade Volume", 410, 700)
##   win2.setCoords(0,0,420,700)
##   title = Text(Point(210,685), "Daily Closing Cost")
##   title.setSize(18)
##   title.draw(win2)
##   title2 = Text(Point(210,230), "Daily Trade Volume")
##   title2.setSize(18)
##   title2.draw(win2)
##   directions = Text(Point(55,660), "Click in the window to \nclose it and continue.")
##   directions.setSize(5)
##   directions.draw(win2)
##   yAxis = Line(Point(65,650),Point(65,50))
##   xAxis = Line(Point(65,50),Point(415,50))
##   yAxis.draw(win2)
##   xAxis.draw(win2)
##   yAxisLabel = "Daily Closing Cost"
##   i = 0
##   #creates title for y-axis
##   for char in yAxisLabel:
##      letter = Text(Point(10,500-i*12),char)
##      letter.setSize(10)
##      letter.draw(win2)
##      i = i + 1
##   yAxisLabel = "Daily Trade Volume"
##   i = 0
##   #creates title for y-axis
##   for char in yAxisLabel:
##      letter = Text(Point(10,230-i*10),char)
##      letter.setSize(8)
##      letter.draw(win2)
##      i = i + 1
##   xAxisLabel = Text(Point(210,20),"Year")
##   xAxisLabel.setSize(10)
##   xAxisLabel.draw(win2)
##   #makes dates list and dayDifferences list empty
##   dates = []
##   dayDifferences = []
##   #creates date objects and puts them in the dates list
##   for i in range(len(Data[dateIndex])-1):
##      values = Data[dateIndex][i].split("/")
##      dates.append(date(int(values[2]),int(values[0]),int(values[1])))
##   firstDate = date(dates[0].year,1,1)
##   #gets every dates distance from the first day of year within the data set
##   for i in range(len(dates)):
##      dayDifferences.append(((dates[i] - firstDate).total_seconds())/86400)
##   #labels x-axis with years
##   for i in range(len(yearIndex)):
##        year = Text(Point(65 + 20* (i + 1),40), str(getFirstYear()+i))
##        year.setSize(5)
##        year.draw(win2)
##   #labels y-axis with numbers to match scale of closing cost graph
##   for i in range(21):
##        scaleNumber = 40*i
##        scale = Text(Point(50,250+20*i),str(scaleNumber))
##        scale.setSize(5)
##        scale.draw(win2)
##   #labels y-axis with numbers to match scale of volume graph
##   for i in range(4):
##        scaleNumber = 300*i
##        scale = Text(Point(40,50+50*i),str(scaleNumber)+" million")
##        scale.setSize(5)
##        scale.draw(win2)
##   #draws lines whose heights represent the a number relative to the scale and whose distance from the y-axis represents the date
##   for i in range(len(dayDifferences)):
##      volumeShape = Line(Point(85+(20/365)*dayDifferences[i],50),Point(85+(20/365)*dayDifferences[i],(float(Data[volumeIndex][i])/100000000)*(50/3) + 50))
##      volumeShape.setOutline("red")
##      volumeShape.draw(win2)
##      closeShape = Line(Point(85+(20/365)*dayDifferences[i],250),Point(85+(20/365)*dayDifferences[i],float(Data[closeIndex][i])/2 + 250))
##      closeShape.setOutline("blue")
##      closeShape.draw(win2)
##   #waits for user to click in window to close it
##   win2.getMouse() 
##   win2.close()
###creates a web page using user input for the style
##def webPage():
##   #gets user input for web page styling and tells them what they chose
##   fontColor = input("What color would you like the text to be? Enter a general color. ex. blue: ").lower()
##   fontSize = input("What size would you like the text to be? Enter a whole number followed by pt. ex. 12pt: ")
##   backgroundColor = input("What color would you like the background to be? Enter a general color. ex. blue: ").lower()
##   print("You chose a font color of",fontColor+", a font size of",fontSize+", and background color of",backgroundColor)
##   #creates a webpage using user input and opens it
##   webPageHTML = """<!DOCTYPE html><html><head><link rel="icon" href="Cpencils.jpg" type="image/jpg" sizes="16x16"/><title>Apple Stock Data</title><style>body{{background-color:{2};color:{0};font-size:{1}; text-align: center}} table,tr,th,td{{padding: 0; margin: auto; border: 10px solid #4CAF50; border-collapse: collapse; }} h1{{text-shadow: 2px 2px 5px blue;}}img{{width:410px; margin: 5px}}</style></head><body><h1>Apple Stock Summary for the past 15 Years</h1><p>As can be seen by the graphs below, there was an upward trend for the closing costs of Apple’s stock, which began in 2003 and ended in 2012. Since 2012, there has been a downward trend for the closing costs most likely due to a drop in sales; however, 2017 might show promise of breaking this trend. This is because as of the beginning of 2017 the closing costs have been greater than the closing costs of 2016. During the closing cost’s upward trends the trade volume increases, while after a downward trend in closing cost’s trade volumes decrease.</p><table><tr><td><img src="closing.jpg" title="Average Closing Cost"/></td><td><img src="CloseVsVolume.jpg" title="Daily Closing Cost vs. Daily Trade Volume"></td></tr></table></body></html>""".format(fontColor,fontSize,backgroundColor)
##   f = open("summary.html","w")    
##   f.write(webPageHTML)
##   f.close()
##   webbrowser.open_new_tab('summary.html')
###asks user what they want to do and runs functions that will help them
##def main():
##    userChoice = ""
##    while userChoice.upper() != "Q":
##        print("This computer contains 3 functions that analyze data on apple stock.\n 1. Makes a graph of the average closing cost.\n 2. Makes a graph of daily closing cost and daily trade volume of Apple's stock.\n 3. Makes a web page out of those graphs.")
##        userChoice = input("Which function would like to run? Enter 1,2, or 3 for the functions or q to quit: ")
##        if userChoice.upper() == ("read_data").upper():
##            read_data("AAPL.txt")
##        elif userChoice == '1':
##            avgClosingCost()
##        elif userChoice == '2':
##            closingVsVolume()
##        elif userChoice == '3':
##            webPage()
##        elif userChoice.upper() == "Q":
##            print("Thank You!")
##        else:
##            print("That is not a valid input.") 
##   
###runs main function      
##main()

