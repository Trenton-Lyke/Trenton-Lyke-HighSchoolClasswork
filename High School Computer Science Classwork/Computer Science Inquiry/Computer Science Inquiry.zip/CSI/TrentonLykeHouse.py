# Trenton Lyke 11/13/2017 Exploring graphis module
#imports graphics module
from graphics import *
#imports random module
from random import *
#gives random color
def randomColor():
   return color_rgb(randint(0,255),randint(0,255),randint(0,255))
#main function
def main():
   #sets up canvas
   win = GraphWin("House", 500, 500)
   #makes bacground blue
   win.setBackground("blue")
   #makes point1 the first point the user clicks on
   point1 = win.getMouse()
   #plots an orange point at point1
   win.plot(point1.getX(),point1.getY(),"orange")

   
   #makes point1 the second point the user clicks on
   point2 = win.getMouse()
   #makes houseWidth the horizontal distance between point1 and point2
   houseWidth = abs(point1.getX()-point2.getX())
   #makes doorWidth 1/5 of houseWidth
   doorWidth = (1/5)*houseWidth
   #makes windowWidth 1/2 of doorWidth
   windowWidth = (1/2)*doorWidth
   #makes houseMiddleX the average of the x-values of point1 and point2
   houseMiddleX = (point1.getX()+point2.getX())/2

   
   #makes frame a rectangle with 2 vertices that are point1 and point2
   frame = Rectangle(point1,point2)
   #fills frame with random color
   frame.setFill(randomColor())
   #draws frame
   frame.draw(win)

   
   #makes point1 the third point the user clicks on
   point3 = win.getMouse()
   if point1.getY() >= point2.getY():
      #makes door a rectangle which bottom side has the same y-value as the bottom of the house, its top vertices are half the distance of doorWidth away from point3, and its top side has the same y value as point 3
      door = Rectangle(Point(point3.getX()-(.5*doorWidth),point1.getY()),Point(point3.getX()+(.5*doorWidth),point3.getY()))
   elif point1.getY() <= point2.getY():
      #makes door a rectangle which bottom side has the same y-value as the bottom of the house, its top vertices are half the distance of doorWidth away from point3, and its top side has the same y value as point 3
      door = Rectangle(Point(point3.getX()-(.5*doorWidth),point2.getY()),Point(point3.getX()+(.5*doorWidth),point3.getY()))
   #fills door with random color
   door.setFill(randomColor())
   #draws door
   door.draw(win)

   
   #makes point1 the fourth point the user clicks on
   point4 = win.getMouse()
   #makes window a square center at point4 with a width of windowWidth
   window = Rectangle(Point(point4.getX()-(.5*windowWidth),point4.getY()-(.5*windowWidth)),Point(point4.getX()+(.5*windowWidth),point4.getY()+(.5*windowWidth)))
   #fills window with random color
   window.setFill(randomColor())
   #draws window 
   window.draw(win)

   
   #makes point1 the fifth point the user clicks on
   point5 = win.getMouse()
   if point1.getY() >= point2.getY():
      #makes roof a triangle with a point at point 5 and the top corners of the frame
      roof = Polygon(Point(point1.getX(),point2.getY()),point5,point2)
   elif point1.getY() <= point2.getY():
      #makes roof a triangle with a point at point 5 and the top corners of the frame
      roof = Polygon(Point(point2.getX(),point1.getY()),point5,point1)   
   #fills roof with random color
   roof.setFill(randomColor())
   #draws roof
   roof.draw(win)


   #makes message "I hope you liked my house!!" above the roof and in the middle of the two sides of the frame
   message = Text(Point(houseMiddleX,point5.getY()-5),"I hope you liked my house!!" )
   #draws message
   message.draw(win)
   #makes userExit "Enter q to exit" at point (10,10)
   userExit = Text(Point(10,10),"Enter q to exit." )
   #draws userExit
   userExit.draw(win)
   #initializes keyString variable
   keyString = ""
   #loops while user has not decided to exit
   while keyString.lower() != "q":
      #sets keyString to a key that the user enters
      keyString = win.getKey()
   #closes canvas   
   win.close()
#calls upon main function
main()
