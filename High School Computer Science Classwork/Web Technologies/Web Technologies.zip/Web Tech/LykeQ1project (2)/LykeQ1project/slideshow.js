var myIndex = 0;

slideShow();
function slideShow() {
    var i;
    var x = document.getElementsByName("slides");
    for (i = 0; i < 10; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
	//document.write(x.length)
    if (myIndex > 10) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(slideShow(), 9000);    
}