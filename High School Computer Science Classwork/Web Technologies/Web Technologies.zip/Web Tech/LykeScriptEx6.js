//main function that runs other function based on user's inputs
function main(){
	var userChoice = document.getElementById("decision").value;	
	switch (parseInt(userChoice)){
		case 1:
			arrayToString();
			break;
		case 2:
			mostPopularItem();
			break;
		case 3:
			sumOfSquares();
			break;
		case 4:
			sumOfCorresponding();
			break;
		case 5:
			quit();
			break;
		default:
			break;
	}
}

//converts array to a string
function arrayToString(){
	var myColor = ["White", "Red", "Black", "Green"];
	document.getElementById("exercises").innerHTML = "The string from a given array is: " + myColor.join(" * ");
}

//finds the element of an array that is repeated the most
function mostPopularItem(){
	var arr1=[3, 'a', 'a', 'a', 2, 3, 'a', 3, 'a', 2, 4, 9, 3]; 
	var popularTerm;
	
	var mostRepeats = 0;
	for(var i = 0; i < arr1.length; i++){
		var repeats = 0;
		for(var j = 0; j < arr1.length; j++){
			if(arr1[i] == arr1[j]){
				repeats++
			}
		}
		if(repeats > mostRepeats){
			mostRepeats = repeats;
			popularTerm = arr1[i];
		}
	}
	document.getElementById("exercises").innerHTML = "The most repeated element is " +popularTerm+ " and is repeated " +mostRepeats+ " times."
}

//calculates the sum of squares of numbers of arrays
function sumOfSquares(){
	var sum = 0;
	var numbers = [0,1,2,3,4]
	for(var i = 0; i < numbers.length; i++ ){
		sum += (numbers[i])*(numbers[i])
	}
	document.getElementById("exercises").innerHTML = "The sum of the squares of the elements of array ["+ numbers + "] is: " + sum;
}

//adds the corresponding elements of two arrays and makes an array of the sums
function sumOfCorresponding(){
	var sumArray = [];
	var array1 = [1,0,2,3,4];
	var array2 = [3,5,6,7,8,13];
	var arrayLength;
	if(array2.length > array1.length){
		arrayLength = array2.length;
	}
	else{
		arrayLength = array1.length;
	}
	for(var i = 0; i < arrayLength; i++ ){
		if(array1[i] && array2[i]){
			sumArray.push(array1[i] + array2[i]);
		}
		else if(array1[i]){
			sumArray.push(array1[i])
		}
		else if(array2[i]){
			sumArray.push(array2[i])
		}
	}
	document.getElementById("exercises").innerHTML = "The sum of the corresponding values of the array ["+array1+"] and ["+array2+"] is [" + sumArray +"]";
}

//alerts the user that the page is closing and then closes the page
function quit(){
	alert("This webpage will now close itself, thank you for using it!!! ");
	window.close();
}
