//canvas element
var canvas = document.getElementById("canvas");
//context for canvas element
var context = canvas.getContext("2d");
//creats a random number with a given upper bound and lower bound
function randomNum(lowerbound, upperbound){
	return Math.floor(Math.random()*(upperbound)) + lowerbound;
	 
}
//creats a random number with a given upper bound 
function rand(upperbound){
	return Math.floor(Math.random()*upperbound);
	 
}
//creates a random color
function createColor(){
	var color = "rgb("+rand(256)+","+rand(256)+","+rand(256)+")";
	return color;
}
//draws a rectangle
function drawRectangle(x,y){
	
	
	context.beginPath();
	var color = createColor();
	context.rect(x,y,100,100);
	context.fillStyle = color;
	context.fill();
	context.stroke();
	context.closePath();
	return color;
}
//draws a circle
function drawCircle(x,y,radius)
{
	
	context.beginPath();
	var color = createColor();
	context.arc(x, y, radius, 0, 2 * Math.PI);
	context.fillStyle = color;
	context.fill();
	context.stroke();
	context.closePath();
	return color;
}
//draws circle or rectangle pyramid
function draw(){
	var number = randomNum(1,3);
	if(number == 1){
		drawCircles();
	}
	if(number == 2){
		drawRect(); 
	}
}
//draws circle pyramid
function drawCircles(){
	context.clearRect(0,0,500,500);
	var color;
	
	var rows = randomNum(1,5);
	//draws pyramid based on number of rows
	switch(rows){
		case 1:
			for(var i = 0; i < rows; i++){
				color = drawCircle(50 + 100*i,500- (50 + 88*i),50);
			}
			
			break;
		case 2:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawCircle(50 + 100*0,500- (50 + 88*i),50);
					drawCircle(50 + 100*(1),500- (50 + 88*i),50);
				}
				if(i == 1){
					color = drawCircle(100 + 100*0,500- (50 + 88*i),50);
					
				}
			}
			break;
		case 3:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawCircle(50 + 100*0,500- (50 + 88*i),50);
					drawCircle(50 + 100*(1),500- (50 + 88*i),50);
					drawCircle(50 + 100*(2),500- (50 + 88*i),50);
				}
				if(i == 1){
					drawCircle(100 + 100*0,500- (50 + 88*i),50);
					drawCircle(100 + 100*1,500- (50 + 88*i),50);
				}
				if(i == 2){
					color = drawCircle(50 + 100*1,500- (50 + 88*i),50);
				}
			}
		break;
		case 4:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawCircle(50 + 100*0,500- (50 + 88*i),50);
					drawCircle(50 + 100*(1),500- (50 + 88*i),50);
					drawCircle(50 + 100*(2),500- (50 + 88*i),50);
					drawCircle(50 + 100*(3),500- (50 + 88*i),50);
				}
				if(i == 1){
					drawCircle(100 + 100*0,500- (50 + 88*i),50);
					drawCircle(100 + 100*1,500- (50 + 88*i),50);
					drawCircle(100 + 100*2,500- (50 + 88*i),50);
				}
				if(i == 2){
					drawCircle(50 + 100*1,500- (50 + 88*i),50);
					drawCircle(50 + 100*2,500- (50 + 88*i),50);
				}
				if(i == 3){
					color = drawCircle(100 + 100*1,500- (50 + 88*i),50);
				}
			}
		break;
		case 5:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawCircle(50 + 100*0,500- (50 + 88*i),50);
					drawCircle(50 + 100*(1),500- (50 + 88*i),50);
					drawCircle(50 + 100*(2),500- (50 + 88*i),50);
					drawCircle(50 + 100*(3),500- (50 + 88*i),50);
					drawCircle(50 + 100*(4),500- (50 + 88*i),50);
				}
				if(i == 1){
					drawCircle(100 + 100*0,500- (50 + 88*i),50);
					drawCircle(100 + 100*1,500- (50 + 88*i),50);
					drawCircle(100 + 100*2,500- (50 + 88*i),50);
					drawCircle(100 + 100*3,500- (50 + 88*i),50);
				}
				if(i == 2){
					drawCircle(50 + 100*1,500- (50 + 88*i),50);
					drawCircle(50 + 100*2,500- (50 + 88*i),50);
					drawCircle(50 + 100*3,500- (50 + 88*i),50);
				}
				if(i == 3){
					drawCircle(100 + 100*1,500- (50 + 88*i),50);
					drawCircle(100 + 100*2,500- (50 + 88*i),50);
				}
				if(i == 4){
					color = drawCircle(50 + 100*2,500- (50 + 88*i),50);
					
				}
			}
		break;
	}
	document.getElementById("color").innerHTML = "You have made a " + rows + " layer tower" + "<br>Your top circle is filled with " + color;
}
//draws rectangle pyramid
function drawRect(){
	context.clearRect(0,0,500,500);
	var color;
	//draws pyramid based on number of rows
	var rows = randomNum(1,5);
	switch(rows){
		case 1:
			for(var i = 0; i < rows; i++){
				color = drawRectangle(0+100*0,500- (100 + 100*i));
			}
			
			break;
		case 2:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawRectangle(0+100*0,500- (100 + 100*i));
					drawRectangle(0+100*1,500- (100 + 100*i));
					
				}
				if(i == 1){
					color = drawRectangle(50+100*0,500- (100 + 100*i));
					
				}
			}
			break;
		case 3:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawRectangle(0+100*0,500- (100 + 100*i));
					drawRectangle(0+100*1,500- (100 + 100*i));
					drawRectangle(0+100*2,500- (100 + 100*i));
				}
				if(i == 1){
					drawRectangle(50+100*0,500- (100 + 100*i));
					drawRectangle(50+100*1,500- (100 + 100*i));
				}
				if(i == 2){
					color = drawRectangle(0+100*1,500- (100 + 100*i));
				}
			}
		break;
		case 4:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawRectangle(0+100*0,500- (100 + 100*i));
					drawRectangle(0+100*1,500- (100 + 100*i));
					drawRectangle(0+100*2,500- (100 + 100*i));
					drawRectangle(0+100*3,500- (100 + 100*i));
				}
				if(i == 1){
					drawRectangle(50+100*0,500- (100 + 100*i));
					drawRectangle(50+100*1,500- (100 + 100*i));
					drawRectangle(50+100*2,500- (100 + 100*i));
				}
				if(i == 2){
					drawRectangle(0+100*1,500- (100 + 100*i));
					drawRectangle(0+100*2,500- (100 + 100*i));
				}
				if(i == 3){
					color = drawRectangle(50+100*1,500- (100 + 100*i));
				}
			}
		break;
		case 5:
			for(var i = 0; i < rows; i++){
				if(i == 0){
					drawRectangle(0+100*0,500- (100 + 100*i));
					drawRectangle(0+100*1,500- (100 + 100*i));
					drawRectangle(0+100*2,500- (100 + 100*i));
					drawRectangle(0+100*3,500- (100 + 100*i));
					drawRectangle(0+100*4,500- (100 + 100*i));
				}
				if(i == 1){
					drawRectangle(50+100*0,500- (100 + 100*i));
					drawRectangle(50+100*1,500- (100 + 100*i));
					drawRectangle(50+100*2,500- (100 + 100*i));
					drawRectangle(50+100*3,500- (100 + 100*i));
				}
				if(i == 2){
					drawRectangle(0+100*1,500- (100 + 100*i));
					drawRectangle(0+100*2,500- (100 + 100*i));
					drawRectangle(0+100*3,500- (100 + 100*i));
				}
				if(i == 3){
					drawRectangle(50+100*1,500- (100 + 100*i));
					drawRectangle(50+100*2,500- (100 + 100*i));
				}
				if(i == 4){
					color = drawRectangle(0+100*2,500- (100 + 100*i));
					
				}
			}
		break;
	}
	document.getElementById("color").innerHTML = "You have made a " + rows + " layer tower" + "<br>Your top rectangle is filled with " + color;
}