//Javascript to create a list
//rompts user for what cases they would like to use
var num = parseInt(prompt("Please choose a list to display. Enter 1 (numbered list), 2 (lettered list), 3 (roman numeral list), or 4 (to start list at user defined number)"));
//string variables for creating the list 
var beginning = "";
var middle = "<li>First List Item</li><li>Second List Item</li><li>Third List Item</li><li>Fourth List Item</li>"
var end = ""
//switch used to format string for list
switch (num){
	case 1:
		beginning = "This is a regular ordered list: <br><ol>";
		end = "</ol>";
		break;
	case 2:
		beginning = "This is an ordered list with letters: <br><ol type='A'>";
		end = "</ol>";
		break;
	case 3:
		beginning = "This is an ordered list with roman numerals: <br><ol type='I'>";
		end = "</ol>";
		break;
	case 4:
		start = parseInt(prompt("Please enter the number you would like to start at."));
		beginning = "This is an ordered list that you chose the starting value for: <br><ol start='"+start+"'>";
		end = "</ol>";
		break;
	default:
		middle = "Invalid choice, please enter 1,2,3, or 4."
		break;
}
//creates list on the webpage
document.getElementById("list").innerHTML = beginning + middle + end;

//prompts user for choices of images
var img1 = parseInt(prompt("Please choose an image to display. Enter 1 (table), 2 (calculator), 3 (pencils), or 4 (smiley face)"));
var img2 = parseInt(prompt("Please choose an image to display. Enter 1 (table), 2 (calculator), 3 (pencils), or 4 (smiley face)"));
//switch to display the user's first image
switch (img1){
	case 1:
		document.getElementById("left_picture").src = "table.jpg"
		break;
	case 2:
		document.getElementById("left_picture").src = "calculator.jpg"
		break;
	case 3:
		document.getElementById("left_picture").src = "Cpencils.jpg"
		break;
	case 4:
		document.getElementById("left_picture").src = "smiley face.png"
		break;
	default:
		document.getElementById("left").innerHTML = "Invalid choice, please enter 1,2,3, or 4."
		break;
}
//switch to display the user's second image
switch (img2){
	case 1:
		document.getElementById("right_picture").src = "table.jpg"
		break;
	case 2:
		document.getElementById("right_picture").src = "calculator.jpg"
		break;
	case 3:
		document.getElementById("right_picture").src = "Cpencils.jpg"
		break;
	case 4:
		document.getElementById("right_picture").src = "smiley face.png"
		break;
	default:
		document.getElementById("right").innerHTML = "Invalid choice, please enter 1,2,3, or 4."
		break;
}