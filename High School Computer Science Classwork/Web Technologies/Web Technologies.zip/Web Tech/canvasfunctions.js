//canvas element
var canvas = document.getElementById("canvas");
//context for canvas element
var context = canvas.getContext("2d");
//variable to hold the last function that was called
var lastFunction = rand; 
//arrays to hold info about random sculptures for scaling
var arrayX;
var arrayY;
var colorsList = [];
//creats a random number with a given upper bound
function rand(upperbound){
	return Math.floor(Math.random()*upperbound);
	 
}

//creates a random color
function createColor(){
	var color = "rgb("+rand(256)+","+rand(256)+","+rand(256)+")";
	return color;
}
//draws a circle
function drawCircle()
{
	color = prompt("What color would you like this shape to be: ", "blue")
	context.clearRect(0,0,500,500);
	context.beginPath();
	context.arc(250, 250, 200, 0, 2 * Math.PI);
	context.fillStyle = color;
	context.fill();
	context.stroke();
	context.closePath();
	lastFunction = drawCircle;
}
//draws a line
function drawLine()
{
	color = prompt("What color would you like this shape to be: ", "blue")
	context.clearRect(0,0,500,500);
	context.beginPath();
	context.moveTo(0, 0);
	context.lineTo(500, 500);
	context.strokeStyle = color;
	context.stroke();
	context.closePath();
	lastFunction = drawLine;
}
//draws a rectangle
function drawRectangle(){
	color = prompt("What color would you like this shape to be: ", "blue")
	context.clearRect(0,0,500,500);
	context.beginPath();
	context.rect(20,20,460,460);
	context.fillStyle = color;
	context.fill();
	context.stroke();
	context.closePath();
	lastFunction = drawRectangle;
}
//draws text
function drawText(){
	color = prompt("What color would you like this shape to be: ", "blue")
	context.clearRect(0,0,500,500);
	context.beginPath();
	context.font = "30px Arial";
	context.fillStyle = color;
	context.fillText("This canvas is cool!!!", 10, 50);
	context.closePath();
	lastFunction = drawText;
}
//draws an image
function drawImage(){
	context.clearRect(0,0,500,500);
	context.beginPath();
	var smile = document.getElementById("smileyFace");
	context.drawImage(smile, 20, 20, 460, 460);
	context.closePath();
	lastFunction = drawImage;
}
//draws a gradient
function drawGradient(){
	color1 = prompt("What color would you like the first part to be: ", "blue")
	color2 = prompt("What color would you like the second color to be: ", "red")
	context.clearRect(0,0,500,500);
	context.beginPath();
	var grd = context.createLinearGradient(0, 0, 200, 0);
	grd.addColorStop(0, color1);
	grd.addColorStop(1, color2);
	context.fillStyle = grd;
	context.fillRect(20, 20, 460, 460);
	context.closePath();
	lastFunction = drawGradient;
}
//draws multiple circles
function drawMultiple(){
	context.clearRect(0,0,500,500);
	
	for(var i = 0; i < 6; i++){
		context.beginPath();
		context.arc(250, 250, 200-i*20, 0, 2 * Math.PI);
		context.fillStyle = createColor();
		context.fill();
		context.stroke();
		
	}
	context.closePath();
	lastFunction = drawMultiple;
}
//draws a random sculpture using half circles
function drawSculpture(){
	context.clearRect(0,0,500,500);
	context.beginPath();
	arrayX = [rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500)]
	arrayY = [rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500),rand(500)]
	for(var i = 0; i < arrayX.length; i++){
		color = createColor();
		colorsList.push(color)
		context.arc(arrayX[i], arrayY[i], rand(20), Math.PI, 2 * Math.PI);
		context.fillStyle = color;
		context.fill();
		context.stroke();
	}
	context.closePath();
	lastFunction = drawSculpture;
}
function drawPreviousSculpture(){
	context.clearRect(0,0,500,500);
	context.beginPath();
	
	for(var i = 0; i < arrayX.length; i++){
		
		context.arc(arrayX[i], arrayY[i], rand(20), Math.PI, 2 * Math.PI);
		context.fillStyle = colorsList[i];
		context.fill();
		context.stroke();
	}
	context.closePath();
	lastFunction = drawSculpture;
}
//draws a random figure
function drawRandom(){
	var array = [drawCircle,drawLine,drawRectangle,drawText,drawImage,drawGradient,drawMultiple,drawSculpture]
	var i = rand(8);
	array[i]();
	lastFunction = array[i];
}
//scales the previously drawn shape
function scaleShape(){
	ratio = prompt("how much would you like to scale this by", .5)
	context.clearRect(0,0,500,500);
	context.scale(ratio,ratio);
	if(lastFunction==drawSculpture){
		drawPreviousSculpture();
	}
	else{
		lastFunction();
	}
	context.scale(1/ratio,1/ratio);
}