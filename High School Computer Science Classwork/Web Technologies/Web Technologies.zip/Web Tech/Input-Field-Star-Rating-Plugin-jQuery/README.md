# simple-rating
Jquery Bootstrap simple rating script readme will be here
