//global variables for cars on canvas
var BlackFord;
var BlueFord;
var BrownChevy;
var YellowChevy;
var BlueVolkswagen;
var GreenLamborghini;
var WhiteLamborghini;
var GreyAudi;
var BlueAudi;
var RedBugatti;
var canvas;
var context;
var slidesIndex = 0;
//function draws cars
function drawCars(){
	// gets the canvas element using the DOM
    canvas = document.getElementById('canvas');
          
    // Makes sure that code is not execute when canvas is not supported
    if (canvas.getContext) {
            
        // use getContext to use the canvas for drawing
        context = canvas.getContext('2d');
               
        //sets the variables to there corresponding images on the canvas
        BlackFord = document.getElementById('BlackFord');
		BlueFord = document.getElementById('BlueFord');
		BrownChevy = document.getElementById('BrownChevy');
		YellowChevy = document.getElementById('YellowChevy');
		BlueVolkswagen = document.getElementById('BlueVolkswagen');
		GreenLamborghini = document.getElementById('GreenLamborghini');
		WhiteLamborghini = document.getElementById('WhiteLamborghini');
		GreyAudi = document.getElementById('GreyAudi');
		BlueAudi = document.getElementById('BlueAudi');
		RedBugatti = document.getElementById('RedBugatti');
		
		//draws the cars in their parking spaces on the canvas in the correct orientation
		context.drawImage(GreenLamborghini,255,135,90,135);
        context.drawImage(WhiteLamborghini,372,135,90,135);
		context.drawImage(BlueAudi,489,135,90,135);
        context.drawImage(GreyAudi,606,135,90,135);
		context.drawImage(RedBugatti,721,135,90,135);
		context.rotate(Math.PI);
        context.drawImage(BlackFord,-345,-430,90,135);
        context.drawImage(BlueFord,-461,-430,90,135);
		context.drawImage(BrownChevy,-577,-430,90,135);
        context.drawImage(YellowChevy,-693,-430,90,135);
		context.drawImage(BlueVolkswagen,-809,-430,90,135);
		context.rotate(-Math.PI);
		
		
	}
	//alerts the user that canvas is not supported on their browser when canvas is not supported
	else{
		alert('You need Safari or Firefox 1.5+ to see this demo.');
	}
}
//function causes economy car to leave off the canvas with an animation and disapear if the correct parameters are given
function economicExit(car,xPosition,yPosition){
	//rotates the canvas to orient it for an animation with the economy cars
	context.rotate(Math.PI);
	//variable for interation
	var y = 1;
	//Runs the function every 0.02 seconds
	var animation = setInterval(function(){
		//saves the colors on the canvas
		context.save();
		//clears the rectangle with the car in it from before
		context.clearRect(xPosition,yPosition-y+2,90,137);
		//draws the car in its new position
		context.drawImage(car,xPosition,yPosition-y,90,135);
		//restores the color of the canvas
		context.restore();
		//iterates y
		y+=1;
		//stops running the function when y reahes 500
		if(y == 500){
			//clears the interval
			clearInterval(animation);
			//clears the rectangle with the car in it from before
			context.clearRect(xPosition,yPosition-y,90,135);
			//rotates it back to its original orientation
			context.rotate(-Math.PI);
		}
	},20)
	
}

function luxuryExit(car,xPosition,yPosition){
	//variable for interation
	var y = 1;
	//Runs the function every 0.02 seconds
	var animation = setInterval(function(){
		//saves the colors on the canvas
		context.save();
		//clears the rectangle with the car in it from before
		context.clearRect(xPosition,yPosition-y+2,90,137);
		//draws the car in its new position
		context.drawImage(car,xPosition,yPosition-y,90,135);
		//restores the color of the canvas
		context.restore();
		//iterates y
		y+=1;
		//stops running the function when y reahes 500
		if(y == 500){
			//clears the interval
			clearInterval(animation);
			//clears the rectangle with the car in it from before
			context.clearRect(xPosition,yPosition-y,90,135);
		}
	},20)
}
//resets the form
function resetForm(){
	//creates a list of elements of the class form
	var formList = document.getElementsByClassName("purchaseForm");
	//sets each value of the elements of the forms to an empty string
	for(var i = 0; i < formList.length; i++){
			formList[i].value= "";
	}
}
function validateForm(){
	//string to track and display errors
	var errors = "";
	//boolean to see if the form is valid
	var isFormValid = true;
	//creates a list of elements of the class form
	var formList = document.getElementsByClassName("purchaseForm");
	//checks to see if the name field is valid if not it set the forms validity to false and incorporates the invalidity into the error
	if(!formList[0].checkValidity()){
		isFormValid = false;
		errors += "\nPlease enter your full name"
	}
	//checks to see if the age field is valid if not it set the forms validity to false and incorporates the invalidity into the error
	if(!formList[1].checkValidity()){
		isFormValid = false;
		errors += "\nPlease enter your age (you must be 21 or older)"
	}
	//checks to see if the id field is valid if not it set the forms validity to false and incorporates the invalidity into the error
	if(!formList[2].checkValidity()){
		isFormValid = false;
		errors += "\nPlease add a picture of your license"
	}
	//checks to see if the email field is valid if not it set the forms validity to false and incorporates the invalidity into the error
	if(!formList[3].checkValidity()){
		isFormValid = false;
		errors += "\nPlease enter a valid email"
	}
	//checks to see if the phone number field is valid if not it set the forms validity to false and incorporates the invalidity into the error
	if(!formList[4].checkValidity()){
		isFormValid = false;
		errors += "\nPlease enter a phone number"
	}
	//checks to see if the car field is valid if not it set the forms validity to false and incorporates the invalidity into the error
	if(!formList[5].checkValidity()){
		isFormValid = false;
		errors += "\nPlease select a car"
	}
	//checks to see if the rental days field is valid if not it set the forms validity to false and incorporates the invalidity into the error
	if(!formList[6].checkValidity()){
		isFormValid = false;
		errors += "\nPlease enter how many days you want the rental"
	}
	//alerts the errors for the user to see if the form is invalid
	if(!isFormValid){
		alert(errors)
	}
	//returns the validity of the form
	return isFormValid
}
//decide
function selectedCarDrive(){
	//variable for the select cars name as a string
	var car;
	//runs code if the form is valid
	if(validateForm()){
		//switch the runs a section of code based on which car was selected
		//makes selected car drive of the canvas, be erased, be disabled in the select box, hides the cars description, and sets the car variable to a string based on the selected car for the invoice
		switch(parseInt(document.getElementById("ListOfCars").value)){
			case 1:
				luxuryExit(GreenLamborghini,255,135)
				document.getElementById("GreenLamborghiniOption").disabled = true;	
				document.getElementById("GreenLamborghiniDescription").style.display = "none";
				car = "Green Lamborghini"
				break;
			case 2:
				luxuryExit(WhiteLamborghini,372,135)
				document.getElementById("WhiteLamborghiniOption").disabled = true;
				document.getElementById("WhiteLamborghiniDescription").style.display = "none";
				car = "White Lamborghini"
				break;
			case 3:
				luxuryExit(BlueAudi,489,135)
				document.getElementById("BlueAudiOption").disabled = true;	
				document.getElementById("BlueAudiDescription").style.display = "none";
				car = "Blue Audi"
				break;
			case 4:
				luxuryExit(GreyAudi,606,135)
				document.getElementById("GreyAudiOption").disabled = true;
				document.getElementById("GreyAudiDescription").style.display = "none";
				car = "Grey Audi"
				break;
			case 5:
				luxuryExit(RedBugatti,721,135)
				document.getElementById("RedBugattiOption").disabled = true;	
				document.getElementById("RedBugattiDescription").style.display = "none";
				car = "Red Bugatti"
				break;
			case 6:
				economicExit(BlackFord,-345,-430)
				document.getElementById("BlackFordOption").disabled = true;	
				document.getElementById("BlackFordDescription").style.display = "none";
				car = "Black Ford"
				break;
			case 7:
				economicExit(BlueFord,-461,-430)
				document.getElementById("BlueFordOption").disabled = true;	
				document.getElementById("BlueFordDescription").style.display = "none";
				car = "Blue Ford"
				break;
			case 8:
				economicExit(BrownChevy,-577,-430)
				document.getElementById("BrownChevyOption").disabled = true;
				document.getElementById("BrownChevyDescription").style.display = "none";	
				car = "Brown Chevy"
				break;
			case 9:
				economicExit(YellowChevy,-693,-430)
				document.getElementById("YellowChevyOption").disabled = true;	
				document.getElementById("YellowChevyDescription").style.display = "none";
				car = "Yellow Chevy"
				break;
			case 10:
				economicExit(BlueVolkswagen,-809,-430)
				document.getElementById("BlueVolkswagenOption").disabled = true;	
				document.getElementById("BlueVolkswagenDescription").style.display = "none";
				car = "Blue Volkswagen"
				break;
			default:
				alert("no car selected");
		}
		//alerts and prints the invoice for the rental
		printInvoice(car, parseInt(document.getElementById("ListOfCars").value))
		//resets the form
		resetForm();
	}
}
//this function alerts and prints the invoice for the rental
function printInvoice(car, carNumber){
	//initializes the invoice string with its title
	var invoice = "Invoice:\n"
	//creates a list of elements of the class form
	var formList = document.getElementsByClassName("purchaseForm");
	//variable that will contain the cost per day corresponding with the car
	var rate;
	//adds the name and age info to invoice
	invoice += formList[0].value + ", "+ formList[1].value + " years old\n";
	//adds the email and phone number info to invoice
	invoice += "Primary methods of contact:\nEmail: "+formList[3].value+"\nPhone Number: "+formList[4].value;
	//adds the car info to invoice
	invoice += "\nChosen car:\n"+car+"\nCost per day:\n";
	//adds the corresponding rate to invoice
	if(carNumber <= 5){
		invoice +="$49.99\n";
		rate = 49.99;
	}
	else{
		invoice +="$29.99\n";
		rate = 29.99;
	}
	//adds the overall cost with 2 decimal places to invoice
	invoice += "Number of days of Rental:\n"+formList[6].value + " days\nTotal cost:\n$ " + (parseInt(formList[6].value)*rate).toFixed(2);
	//alerts the invoice so the user will see it and tells them their is an additional invoice on the bottom of the page
	alert(invoice + "\nYour invoice has also been printed at the bottom of this page");
	//prints an additional invoice on the bottom of the page
	document.getElementById("invoice").innerHTML = invoice.replace(/\n/gi,"<br><br>");
}
//calls carousel function to run a slideshow of the cars
carousel();

//function hides all images within the slideshow div, then makes them disapear an reapear every 9 seconds
function carousel() {
    //array of images in the slideshow
    var slideshow = [document.getElementById("1"),document.getElementById("2"),document.getElementById("3"),document.getElementById("4"),document.getElementById("5"),document.getElementById("6"),document.getElementById("7"),document.getElementById("8"),document.getElementById("9"),document.getElementById("10")];
	//for every image in the slide show it makes its dislay none or in other words hides all the slides
    for (var i = 0; i < slideshow.length; i++) {
       slideshow[i].style.display = "none";  
    }
	//increaments the index of the slideshows so it can show different slides
    slidesIndex++;
	//resets the slide show if the slide number is greater than the length of the slideshow
    if (slidesIndex > slideshow.length) {
		slidesIndex = 1
	}    
	//displays the slide at the given index minus 1
    slideshow[slidesIndex-1].style.display = "block"; 

	//recurssion allows the function to continue forever every 9 seconds
    setTimeout(carousel, 9000);    
	
	//ps additional add-ins allow the slides to fade in and out
}



