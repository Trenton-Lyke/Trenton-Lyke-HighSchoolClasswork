	//creates a random number given a upper and lower bound
	function createRandom(low, high){
		//creates a random number within the bounds
		var num = Math.floor(Math.random()*high + low);
		//returns the random number
		return num;
	}
	
	//creates a table with alternating black and white coloumns
	function createBlackAndWhite(){
		//gets random number of rows and coloumns
		var rows = createRandom(1, 10);
		var coloumns = createRandom(1, 10);
		
		//creates string for html for table
		var table = "<table>";
		
		//creates rows and coloumns for table with alternating black and white coloumns
		for(var i = 0; i<rows; i++){
			table += "<tr>";
				//creates cells for the table giving them the correct class based on the color they should be
				for (j =0; j< coloumns; j++){
					if(j%2 == 0){
						table += "<td class='black'>black</td>";
					}
					else{
						table += "<td class='white'>white</td>";
					}
					
				} 
			table += "</tr>";
		}
		table += "</table>";
		
		//displays the table in the canvas
		document.getElementById("canvas").innerHTML = table;
		
		//displays exclimation in the exclimation paragraph under the buttons
		document.getElementById("exclimation").innerHTML = "<h2>Do you like this design? I think it is beautiful!</h2>";
	}
	
	//creates a table like a black and white checker board
	function createCheckBoard(){
		//gets random number of rows and coloumns
		var rows = createRandom(1, 10);
		var coloumns = createRandom(1, 10);
		
		//creates string for html for table
		var table = "<table>";
		
		//creates rows and coloumns for table like a black and white checker board
		for(var i = 0; i<rows; i++){
			table += "<tr>";
				//creates cells for the table giving them the correct class based on the color they should be
				for (j =0; j< coloumns; j++){
					if(i%2 ==0){
						if(j%2 == 0){
							table += "<td class='black'>black</td>";
						}
						else{
							table += "<td class='white'>white</td>";
						}
					}
					else{
						if(j%2 == 0){
							table += "<td class='white'>white</td>";
						}
						else{
							table += "<td class='black'>black</td>";
						}
					}
				} 
			table += "</tr>";
		}
		table += "</table>";
		
		//displays the table in the canvas
		document.getElementById("canvas").innerHTML = table;
		
		//displays exclimation in the exclimation paragraph under the buttons
		document.getElementById("exclimation").innerHTML = "<h2>Do you like this design? I think it is beautiful!</h2>";
	}