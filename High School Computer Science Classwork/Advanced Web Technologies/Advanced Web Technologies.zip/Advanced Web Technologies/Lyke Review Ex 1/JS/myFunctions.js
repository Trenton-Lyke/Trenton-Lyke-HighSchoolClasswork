/*
sources:
https://keithscode.com/tutorials/javascript/3-a-simple-javascript-password-validator.html
*/

//checks if the fields are the same
function checkSame(fieldId1,fieldId2,messageId,submitId)
{
	//gets submit button so it can be disbaled
	var submitButton = document.getElementById(submitId);
	
    //Stores the field objects into variables
    var input1 = document.getElementById(fieldId1);
    var input2 = document.getElementById(fieldId2);
	
    //Stores the object to output a message
    var message = document.getElementById(messageId);
	
    //Sets the good and bad colors
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
	
    //Compare the values in the two fields
    if(input1.value == input2.value){
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password 
        input2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
        message.innerHTML = "Phone numbers match!";
		//enables submit button
		//submitButton.disabled = false;
    }else{
        //The passwords do not match.
        //Set the color to the bad color and
        //notify the user.
        input2.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Phone numbers don't match!";
		//disables submit button
		//submitButton.disabled = true;
    }
}  

//compares dates in the table
function compareDates(dateName1, dateName2, messageName,submitId) {
	//gets arrays of date inputs and message output objects
	var fromDates = document.getElementsByName(dateName1);
	var toDates = document.getElementsByName(dateName2);
	var messages = document.getElementsByName(messageName);
	
	//gets submit button so it can be disabled
	var submitButton = document.getElementById(submitId);
	
	//loops for ever set of dates
	for(var i = 0; i < fromDates.length; i++){
		
		//gets a set of dates from the arrays
		var date1 = fromDates[i];
		var date2 = toDates[i];
		
		//gets the dates values
		var rawDate1 = date1.value;
		var rawDate2 = date2.value;
		
		//runs if both dates are set
		if(rawDate1 != "" && rawDate2 != ""){
			
			//Sets good and bad colors
			var goodColor = "#66cc66";
			var badColor = "#ff6666";
			
			//gets the message output object corresponding to the dates
			var message = messages[i];
			
			//runs if dates are out of order
			if(rawDate1 > rawDate2){
				//warns user the dates are incompatible
				message.innerHTML = "Incompatible dates!";
				date2.style.backgroundColor = badColor;
				message.style.color = badColor;
				
				//disables submit button
				//submitButton.disabled = true;
			}
			//otherwise
			else{
				//congratulates the user
				message.innerHTML = "The date is great!";
				date2.style.backgroundColor = goodColor;
				message.style.color = goodColor;
				
				//enables submit button
				//submitButton.disabled = false;
			}
		}	
	}
}

//adds row to table
function addRow(tableId){
	var table = document.getElementById(tableId);
	var numberOfRows = table.rows.length;
	if(numberOfRows < 5){
		var row = table.insertRow(numberOfRows);
		var numberOfCols = table.rows[0].cells.length;
		for(var i=0; i<numberOfCols; i++){
			var newCell = row.insertCell(i);
			newCell.innerHTML = table.rows[0].cells[i].innerHTML;
		}
	}
	else{
		alert("You may only check out 5 books at a time");
	}
	
}

/*function deleteRow(tableId){
	var table = document.getElementById(tableId);
	var numberOfRows = table.rows.length;

	
	for(var i=0; i<numberOfRows; i++){
		var row = table.rows[i]
		var box = row.cells[0]
		alert(box.checked)
		if(box.checked && box != null){
			if(rowCount <= 1){
				alert("You can't remove all books");
				break;
			}
			table.deleteRow(i);
			numberOfRows--;
			i--;
		}
		//alert("hi");
	}
}*/

//deletes checked rows from table
function deleteRow(tableId, checkBoxesName){
	//the table the row will be deleted in
	var table = document.getElementById(tableId);
	
	//boolean that indicates true when the row indexs of the table changes due to a row deletion
	var switching = true;

	//gets an array of check boxes
	var checkBoxes = document.getElementsByName(checkBoxesName);
	
	//finds the number of checked checkboxes
	var numberOfCheckedBoxes = 0;
	for(var i = 0; i < checkBoxes.length; i++){
		if(checkBoxes[i].checked){
			numberOfCheckedBoxes++;
		}
	}
	
	//runs if not all of the check boxes are checked 
	if(numberOfCheckedBoxes < checkBoxes.length){
		//switches while the boolean indicating that table row indexes switched is set to true
		while(switching){
			
			//updates checkboxes array and the number of checkboxes incase any were deleted with a row deletion
			checkBoxes = document.getElementsByName(checkBoxesName);
			
			//sets switching to false so it won't loop again unless a row is deleted
			switching = false;
			
			//loops through all the checkboxes and deletes rows with checked checkboxes
			for(var j = 0; j < checkBoxes.length; j++){
				if(checkBoxes[j].checked){
					table.deleteRow(j);
					//sets switching to true and breaks out of for loop so that the indexes of the table will be updated with a new iteration of the outer while loop
					switching = true;
					break;
				}
			}	
		}
	}
	//otherwise tells user the have to checkout atleast one book
	else{
		alert("You have to at least check out 1 book");
	}
}