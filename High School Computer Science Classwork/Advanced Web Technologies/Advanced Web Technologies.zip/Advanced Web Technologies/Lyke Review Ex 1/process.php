<!DOCTYPE html>
<!-- Review Exercise 1---->
<html>
	<!-- Trenton Lyke 01/14/19 Review Exercise 1-->
	<head>
		<title>Library Records</title>
		<link rel="stylesheet" type="text/css" href="CSS/design.css">
	</head>
	<body>
		<!--title of page-->
		<h1>Your Checkout Records</h1>
		<fieldset>
			<legend>Books Checked Out</legend>
			
			<?php
				//gets info about the user and books
				$name = $_POST["name"];
				$check = $_POST["check"];
				$bookName = $_POST["bookName"];
				$bookGenre = $_POST["bookGenre"];
				$fromDate = $_POST["from"];
				$toDate = $_POST["to"];
				$libraryBranch = $_POST["libraryBranch"];
				if($fromDate > $toDate){
					exit("The date you return the book must be after you check it out. <a href='index.html'>Return</a>");
				}
				//displays user's info and books
				echo "Here are your books $name:<br>";
				foreach($bookName as $a => $b){
					echo "Book Name: $b<br>";
					echo "Book Genre: $bookGenre[$a]<br>";
					echo "Checked out from: $fromDate[$a]<br>";
					echo "To: $toDate[$a]<br>";
					echo "At: $libraryBranch[$a]<br><br>";
				}
			?>
		</fieldset>
	</body>
</html>