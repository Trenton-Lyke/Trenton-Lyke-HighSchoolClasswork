// Initialize Firebase
var config = {
    apiKey: "AIzaSyAOu6DSdfSSELaQaKvqHJ67GFNgDzSQS5s",
    authDomain: "my-awsome-project-cedd0.firebaseapp.com",
    databaseURL: "https://my-awsome-project-cedd0.firebaseio.com",
    projectId: "my-awsome-project-cedd0",
    storageBucket: "my-awsome-project-cedd0.appspot.com",
    messagingSenderId: "513955135796"
  };
  firebase.initializeApp(config);
/*
var userId = $("#teamNumber");
var userName = $("#heading");
var heading = $("#heading");
$("#submit").click(function(){
	firebase.database().ref('users/').push().set({
		username: userName.val(),
		email: email.val()
	});
	var firebaseRef = firebase.database().ref();
	
	var messageText = email.val();
	
	//firebaseRef.child("bobnodemon").set(messageText)
	firebaseRef.push().set(messageText)
});

function writeUserData() {
  
}*/
const db = firebase.database();
/*db.ref('users').child("1").set({
	name: "David",
	email: "david@gmail.com",
	age: 99,
	locations: "SF",
	age_location: "99_SF"
});
db.ref('users').child("9").set({
	name: "Alice",
	email: "alice@gmail.com",
	age: 26,
	locations: "Berlin",
	age_location: "26_Berlin"
});
db.ref('events/').child("fm").set({
	name: "Firebase Meetup",
	date: "9"
});
db.ref('eventAttendees/').child("fm").set({
	"1": "David",
	"9": "Alice"
});*/
var email = $("#email");
const users = db.ref().child("users")
//const query = users.child("1");
//const query = users.orderByChild('email').equalTo('alice@gmail.com')
//const query = users.orderByChild('email').startAt('d').endAt("d\uf8ff")
//const query = users.orderByChild('age').endAt(49)
//const query = users.orderByChild('age').startAt(51)
query.on('value', snap => email.val(JSON.stringify(snap.val())))
