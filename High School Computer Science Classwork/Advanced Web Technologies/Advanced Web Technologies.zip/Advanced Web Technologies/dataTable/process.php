<?php
//Trenton Lyke 12/4/2018 product supply
include 'config.php'; //uses php of the config file to connect to database
//adds the style for the page onto the page
include 'styling.php';





//selects the records from the table that have quantities less than 2000
$sql = 'SELECT * FROM post';
$result = mysqli_query($conn, $sql);
echo "<h3>All the products with quantities less than 2000</h3>";
//displays records
if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
	   echo " title: ".$row["title"]."<br>";
	}
} else {
	echo "0 results";
}




?>