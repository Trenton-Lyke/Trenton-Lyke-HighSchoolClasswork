

//creates accordian
$( function() {
	$( "#accordion" ).accordion({active: false,
	collapsible: true,});
} );

//creates tabs
$( function() {
	$( "#tabs" ).tabs();
} );

 
//creates popovers
$(function(){
	$.noConflict();
    $('[data-toggle="popover"]').popover();   
});
















/*$( function() {
    //$( "#draggable" ).draggable()
	
    $( "#droppable" ).droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "p" )
          .html( "Dropped!" );
      }
    });
	$('.draggable').each(function() {
    alert( this.id );
	$(this.id).draggable();
	$( "#a" ).draggable()
});
  } );*/
  