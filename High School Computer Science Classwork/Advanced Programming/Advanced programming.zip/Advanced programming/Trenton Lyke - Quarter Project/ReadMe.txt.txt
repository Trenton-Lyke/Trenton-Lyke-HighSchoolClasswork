Original Author:
Author: Trenton Lyke
Version: 1.1
Date: 5/15/2020

Start: Run the main method of the Driver class 
(Will likely need to do this in eclipse becuse the project was not set up in BlueJ)

Description: The program attempts finds the path across the topographical map of the mountain that results 
in the least aggregate amount of change in elevation. The red lines do a simple greedy algorithm from each starting point
and the green line is the best of those paths (Part I of the project). The yellow lines do an improved multithreaded recursive greedy algorithm
from each starting point and the blue line is the best of those paths (Part II of the project). Part II will always be better or the same as Part I.
Their is also more information about the paths drawn displayed in the console as well.
