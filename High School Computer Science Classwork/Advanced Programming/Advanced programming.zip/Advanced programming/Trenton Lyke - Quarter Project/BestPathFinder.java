import java.awt.Graphics;

//class that finds the best path using the brute force greedy algorithm hybrid
//implements the runnable interface so that it can find the best path on a thread seperate from the main thread
public class BestPathFinder implements Runnable{
	//instance variables used to find the best complete path
	private int columnsStep;
	private int numberOfColumns;
	private Graphics g;
	private int oldRow;
	//used to get the total elevation change of the path
	private double change;
	//used to give the best complete path after the thread rejoins the main thread
	private int[][] completePath;
	private int row;
	private int maxRow;
	private int numberOfRows;
	private MapDataDrawer map;
	//sets instance variables
	public BestPathFinder(int columnsStep, int numberOfColumns, Graphics g, int oldRow,  int row, int maxRow, int numberOfRows, MapDataDrawer map) {
		// TODO Auto-generated constructor stub
		this.columnsStep=columnsStep;
		this.numberOfColumns=numberOfColumns;
		this.g=g;
		this.oldRow=oldRow;
		completePath=new int[numberOfColumns][3];
		this.row=row;
		this.maxRow=maxRow;
		this.numberOfRows=numberOfRows;
		this.map=map;
	}
	
	//finds the best path and sets it to the completePath variable
	public void run() {
		int oldCol = 0;
      	int col = 0;
      int i =0;
      change = 0;
      for(int maxCol = columnsStep; maxCol <= numberOfColumns; maxCol+=columnsStep) {
      
      	int[][] bestPath = map.getLowestElevPath(g, oldRow, oldCol, row, col,maxRow,maxCol, numberOfRows);
      	for(int k = col; k < maxCol; k++) {
      		if(col%columnsStep != 0 || col == 0) {
      			completePath[k]=bestPath[k];
      		}
      	}
      	change+=bestPath[col][2];
      	oldRow=bestPath[bestPath.length-1][0];
      	oldCol=bestPath[bestPath.length-1][1];
      	row=bestPath[bestPath.length-1][0];
      	col=bestPath[bestPath.length-1][1];
      	
      	
      	i++;
      }
	             
	}
	
	//returns the total elevation change of the path
	public int getChange() {
		return (int)change;
	}
	//returns the best complete path
	public int[][] getCompletePath() {
		return completePath;
	}
	
}
