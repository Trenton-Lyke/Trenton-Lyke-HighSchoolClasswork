import java.util.*;
import java.io.*;
import java.awt.*;

public class MapDataDrawer
{

  private int[][] grid;

  public MapDataDrawer(String filename, int rows, int cols) throws Exception{
      // initialize grid 
      //read the data from the file into the grid
	  grid = new int[rows][cols];
	  Scanner scanner = new Scanner(new File(filename));
	  int row = 0;
	  int col = 0;
	  while(scanner.hasNextInt() && row<rows) {
		  grid[row][col]=scanner.nextInt();
		  
		  col++;
		  if(col!=0 && col%cols==0) {
			  col=0;
			  row++;
		  }
		 
	  }
	  
	  
  }
  
  /**
   * @return the min value in the entire grid
   */
  public int findMinValue(){
	  int min = Integer.MAX_VALUE;
	  for(int i = 0; i < grid.length; i++) {
		  for(int j = 0; j < grid[0].length; j++) {
			  if(grid[i][j] !=0 && min > grid[i][j]) {
				  min=grid[i][j];
			  }
		  }
		  
	  }
    return min;    
  }
  /**
   * @return the max value in the entire grid
   */
  public int findMaxValue(){
	  int max = Integer.MIN_VALUE;
	  for(int i = 0; i < grid.length; i++) {
		  for(int j = 0; j < grid[0].length; j++) {
			  if(grid[i][j] !=0 && max < grid[i][j]) {
				  max=grid[i][j];
			  }
		  }
		  
	  }
    return max; 
  }
  
  /**
   * @param col the column of the grid to check
   * @return the index of the row with the lowest value in the given col for the grid
   */
  public  int indexOfMinInCol(int col){
	  int min = Integer.MAX_VALUE;
	  int lowestValueIndex = 0;
	  for(int i = 0; i < grid.length; i++) {
		  if(grid[i][col] !=0 && min > grid[i][col]) {
			  min=grid[i][col];
			  lowestValueIndex=i;
		  } 
	  }
    return lowestValueIndex; 
  }
  
  /**
   * Draws the grid using the given Graphics object.
   * Colors should be grayscale values 0-255, scaled based on min/max values in grid
   */
  public void drawMap(Graphics g){
      int maxValue = findMaxValue();
      
      for(int j = 0; j < grid[0].length; j++) {
    	  
		  for(int i = 0; i < grid.length; i++) {
			  int grayScaleValue = (int)(((double)grid[i][j]/maxValue)*255);
			  g.setColor(new Color(grayScaleValue,grayScaleValue,grayScaleValue));
			  g.fillRect(j, i, 1, 1);
		  }
      }
      
      
      
  }

   /**
   * Find a path from West-to-East starting at given row.
   * Choose a foward step out of 3 possible forward locations, using greedy method described in assignment.
   * @return the total change in elevation traveled from West-to-East
   */
  public int drawLowestElevPath(Graphics g, int row){
	  double totalChange = 0;
	for(int j = 0; j < grid[row].length-1; j++) {
		int minChange = Integer.MAX_VALUE;
		int minChangeI = -1;
		for(int i = -1; i <=1; i++) {
			if(row+i>=0 && row+i < grid.length && grid[row+i][j+1] != 0) {
			int currentElevationChange = Math.abs(grid[row+i][j+1]-grid[row][j]);
			if(currentElevationChange < 0) {
				System.out.println("error "+currentElevationChange);
			}
			if( minChange >=  currentElevationChange) {
				if(minChange > currentElevationChange || (minChange == currentElevationChange && i ==0)) {
					minChange = currentElevationChange;
					minChangeI = i;
				}
				else if (minChangeI !=0 && Math.floor(2*Math.random()) == 0){
					minChange = currentElevationChange;
					minChangeI = i;
				}
				
			}
			}
		}
		g.drawLine(j, row,j+1, row+minChangeI);
		row += minChangeI;
		totalChange+=minChange;
	}
	if(totalChange < 0) {
		System.out.println("error "+totalChange);
	}
	return (int)totalChange;
  }
  
  //returns a 2d int array of rows, columns, and aggregate change in elevation of the path starting 
  //in column 0 of a specified row and ending in the last column with the lowest aggregate change in elevation
  //the algorithm recursively uses brute force techniques on smaller column spans of the map and not
  //the entire map to find the best path sections by greedy standards then puts the sections together
  //to form the complete path and returns it
  public int[][] getLowestElevPath(Graphics g, int oldRow, int oldCol, int row, int col, int maxRow, int maxCol, int numberOfRows){
	  
	    double totalChange = 0;
	    if(row < numberOfRows && col < maxCol-1) {
	    	if(grid[row][col]==0) {
	    		int[][] coordinateStack = new int[maxCol][3];
	    		coordinateStack[col] = new int[] {row, col, Integer.MAX_VALUE};
	    		return coordinateStack;
	    	}
	    	else {
	    		int[][] paths = new int[][] {
	    			{row-1, col+1, Integer.MAX_VALUE},
	    			{row, col+1, Integer.MAX_VALUE},
	    			{row+1, col+1,  Integer.MAX_VALUE}
	    		};
	    		int[][][] possiblePaths = new int[][][]{new int[maxCol][3], new int[maxCol][3],new int[maxCol][3]};
	    		if(row-1>0) {
	    			possiblePaths[0]=getLowestElevPath(g, row, col,row-1, col+1, maxRow, maxCol, numberOfRows);
	    			paths[0] = possiblePaths[0][col+1];
	    		}
	    		possiblePaths[1]=getLowestElevPath(g, row, col, row, col+1,maxRow, maxCol, numberOfRows);
	    		paths[1]=possiblePaths[1][col+1];
	    		if(row+1<grid.length) {
	    			possiblePaths[2]=getLowestElevPath(g, row, col, row+1, col+1, maxRow, maxCol, numberOfRows);
	    			paths[2]=possiblePaths[2][col+1];
	    		}
	    		int minChange = Integer.MAX_VALUE;
	    		int minChangeI = 0;
	    		for(int i = 0; i < paths.length; i++) {
	    			if(minChange>paths[i][2]) {
	    				minChange=paths[i][2];
	    				minChangeI=i;
	    			}
	    		}
	    		possiblePaths[minChangeI][col]=new int[] {row, col, minChange+Math.abs(grid[row][col]-grid[oldRow][oldCol])};
	    		

	    		return possiblePaths[minChangeI];
	    	}
	    }
	    else {
	    	int[][] coordinateStack = new int[maxCol][3];
	    	coordinateStack[col]=new int[] {row, col, Math.abs(grid[row][col]-grid[oldRow][oldCol])};
	    	
	    	return coordinateStack;
	    }

  }
  //finds the best of the paths determined by the greedy brute force algorithm and returns it
  //it does this by using the greedy brute force algorithm to find the best path for each starting row possible
  //dependent on the row step (which is a process sped up by multithreading) and the compares the elevation
  //change of all those paths to find the best path with the lowest elevation change
  public int[][] getBestPathGreedyBruteForce(Graphics g, int numberOfColumns, int numberOfRows, int columnsStep, int rowsStep){
  	int minChange = Integer.MAX_VALUE;
      int[][] minChangePath = new int[0][0];

      int oldRow = 0;
      
      int row = 0;
      int numberOfIterations = numberOfRows/rowsStep;
      Thread[] threads = new Thread[numberOfIterations];
      BestPathFinder[] bestPathFinders = new BestPathFinder[numberOfIterations];
      int count = 0;
      for(int maxRow = rowsStep; maxRow <= numberOfRows; maxRow+=rowsStep) {
    	bestPathFinders[count] = new BestPathFinder(columnsStep, numberOfColumns,g, oldRow, row, maxRow,numberOfRows, this);
      	threads[count] = new Thread(bestPathFinders[count]);
      	threads[count].start();
      	row=maxRow;
        oldRow=row;  
        count++;
      }
      try {
      for(Thread thread : threads) {
    	
			thread.join();
		
      }
      g.setColor(Color.YELLOW);
      for(BestPathFinder bestPathFinder : bestPathFinders) {
    	  drawMapPath(g,bestPathFinder.getCompletePath());
        if(minChange > bestPathFinder.getChange()) {
    		minChange = bestPathFinder.getChange();
    		minChangePath=bestPathFinder.getCompletePath();
    	}
      }
      } catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

      System.out.println("The aggregate change in elevation in the path found by Trenton's Algorithm: "+minChange);
      return minChangePath;
  }
  
  //draws a path on the map given a 2d array of rows and columns
  public void drawMapPath(Graphics g, int[][] minChangePath) {
	  
	  for(int i = 0; i < minChangePath.length-1; i++) {
      	
      	g.drawLine(minChangePath[i][1], minChangePath[i][0], minChangePath[i+1][1], minChangePath[i+1][0]);
      }
  }
  
  /**
   * @return the index of the starting row for the lowest-elevation-change path in the entire grid.
   */
  public int indexOfLowestElevPath(Graphics g){
	  int minChange = Integer.MAX_VALUE;
	  int minChangeI = 0;
     for(int i = 0; i < grid.length; i++) {
    	 int currentElevationChange = drawLowestElevPath(g, i);
    	 if(minChange > currentElevationChange) {
    		 minChange=currentElevationChange;
    		 minChangeI = i;
    	 }
     }
     return minChangeI;
  }
  
  
}