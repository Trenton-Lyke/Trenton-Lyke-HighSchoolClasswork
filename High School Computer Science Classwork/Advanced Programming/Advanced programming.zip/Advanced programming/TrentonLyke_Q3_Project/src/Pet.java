import java.time.LocalDate;
import java.util.HashMap;

//pet class for all animal types in the animal hospital implementing the boardable interface
public class Pet implements Boardable{
	
	//instance variables for pets
	private String name;
	private String ownerName;
	private String color;
	private String ownerEmail;
	private LocalDate boardingStartDate;
	private LocalDate boardingEndDate;
	protected int gender;
	
	//constructor
	public Pet(String name, String ownerName, String ownerEmail, String color) {
		this.name = name;
		this.ownerName = ownerName;
		this.ownerEmail = ownerEmail;
		this.color = color;
	}
	
	//get methods for object fields
	public String getPetName() {
		return name;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public String getEmail() {
		return ownerEmail;
	}
	public String getColor() {
		return color;
	}
	public String getGender() {
		return intToGender(gender);
	}
	
	//set methods for object fields
	public void setGender(int gender) {
		this.gender=gender;
	}
	
	//returns string based on information from pet
	public String toString() {
		return "Pet:\r\n" + 
				getPetName() + " owned by "+getOwnerName()+"\r\n" + 
				"owner's email: "+getEmail()+"\r\n" + 
				"Pet Color: "+getColor()+"\r\n" + 
				"Gender: "+getGender()+"\r\n" + 
				"**************************\r\n" + 
				"**************************";
	}
	
	//sets the start date of the pets boarding
	public void setBoardStart(int month, int day, int year) {
		
		boardingStartDate = LocalDate.of(year, month, day);
	};
	
	//sets the end date of the pets boarding
	public void setBoardEnd(int month, int day, int year){
		
		boardingEndDate = LocalDate.of(year, month, day);
	}
	
	//returns boolean based of if the pet is boarding
	public boolean boarding(int month, int day, int year){
		
		LocalDate givenDate = LocalDate.of(year, month, day);
		return givenDate.equals(boardingStartDate) || givenDate.equals(boardingEndDate) || (givenDate.isAfter(boardingStartDate)&&givenDate.isBefore(boardingEndDate));
	}
	
	//converts the integer value of the gender field into a string representation of the gender
	public static String intToGender(int gender) {
		switch(gender) {
		case 1:
			return "male";
		case 2:
			return "female";
		case 3:
			return "neutered";
		case 4:
			return "spayed";
		default:
			return "unknown";
		}
	}
}
