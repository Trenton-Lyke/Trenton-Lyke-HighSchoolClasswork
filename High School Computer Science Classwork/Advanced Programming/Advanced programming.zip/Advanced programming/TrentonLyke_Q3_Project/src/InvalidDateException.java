//exception for invalid dates
public class InvalidDateException extends Exception{

	//constructor inherits from super class
	public InvalidDateException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

}
