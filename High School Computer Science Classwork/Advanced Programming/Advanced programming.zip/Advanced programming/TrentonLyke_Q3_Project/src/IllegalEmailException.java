//exception class for illegal emails
public class IllegalEmailException extends Exception{

	//constructor inherits from super class
	public IllegalEmailException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

}
