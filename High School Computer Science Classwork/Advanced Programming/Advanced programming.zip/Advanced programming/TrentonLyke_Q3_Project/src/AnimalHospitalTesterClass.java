
public class AnimalHospitalTesterClass {

	

	public static void main(String[] args) {
		//creates animal hospital object
		AnimalHospital animalHospital = new AnimalHospital("Animals.txt");
		
		//tests methods of class
		
		animalHospital.printPetInfoByName("abc");
		animalHospital.printPetInfoByOwner("trenton");
		animalHospital.printPetsBoarding(9, 10, 2005);
		
		
	}

}
