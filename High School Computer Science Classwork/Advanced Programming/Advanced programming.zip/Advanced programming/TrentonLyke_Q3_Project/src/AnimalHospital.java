import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.io.BufferedWriter;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.io.FileWriter;
import java.util.Scanner; // Import the Scanner class to read text files
//class to represent data in an animal hospital
public class AnimalHospital {
	
	//instance variables
	
	//arraylist of animals
	private ArrayList<Pet> animals = new ArrayList<Pet>();
	
	//file that the AnimalHospital class reads from
	private String inputFile;
	
	//constructor for animal hospital
	public AnimalHospital(String inputFile){
		
		try {
			this.inputFile = inputFile;
	      File animalFile = new File(inputFile);
	      Scanner fileReader = new Scanner(animalFile);
	      boolean isEnd = false;
	      while (fileReader.hasNextLine() && !isEnd) {
	        String line = fileReader.nextLine();
	        line = line.trim();
	        String[] data = line.split(" ");
	        try {
				isEnd = addData(data);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	      }
	      fileReader.close();
	     
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    }
	};
	
	//gets methods for pets info in String form
	public String getAllPetInfo() {
		String records = "";
		for(Pet animal : animals) {
			records += animal.toString() + "\n";
		}
		return records;
	};
	public String getPetInfoByName(String name) {
		String records = "";
		for(Pet animal : animals) {
			if(name.equals(animal.getPetName())) {
				records += animal.toString() + "\n";
			}
		}
		return records;
	};
	
	public String getPetInfoByOwnerName(String name) {
		String records = "";
		for(Pet animal : animals) {
			if(name.equals(animal.getOwnerName())) {
				records += animal.toString() + "\n";
			}
		}
		return records;
	};
	
	public String getPetInfoByOwnerEmail(String email) {
		String records = "";
		for(Pet animal : animals) {
			if(email.equals(animal.getEmail())) {
				records += animal.toString() + "\n";
			}
		}
		return records;
	};
	public String getPetInfoByColor(String color) {
		String records = "";
		for(Pet animal : animals) {
			if(color.equals(animal.getColor())) {
				records += animal.toString() + "\n";
			}
		}
		return records;
	};
	public String getPetInfoByGender(String gender) {
		String records = "";
		for(Pet animal : animals) {
			if(gender.equals(animal.getGender())) {
				records += animal.toString() + "\n";
			}
		}
		return records;
	};
	public String getPetInfoByType(String type) {
		String records = "";
		for(Pet animal : animals) {
			if(type.equals("DOG") && animal instanceof Dog) {
				records += animal.toString() + "\n";
			}
			else if(type.equals("CAT") && animal instanceof Cat) {
				records += animal.toString() + "\n";
			}
			else if(type.equals("BIRD") && animal instanceof Bird) {
				records += animal.toString() + "\n";
			}
		}
		return records;
	};
	public String getPetsBoarding(int month, int day, int year) {
		String records = "";
		for(Pet animal : animals) {
			if(animal.boarding(month, day, year)) {
				records += animal.toString() + "\n";
			}
		}
		return records;
	};
	
	//print methods for pet info
	public void printPetInfoByName(String name) {
		System.out.println(getPetInfoByName(name));
		
	};
	public void printPetInfoByOwner(String name) {
		System.out.println(getPetInfoByOwnerName(name));
	};
	public void printPetsBoarding(int month, int day, int year) {
		System.out.println(getPetsBoarding(month, day, year));
	};
	
	//validators for pet info
	public void validateEmail(String email) throws IllegalEmailException {
		if(!EmailValidation.emailValidation(email)) {
			throw new IllegalEmailException("Invalid email address");
		}
	}
	public void validateDate(int month, int day, int year) throws InvalidDateException {
		HashMap<Integer,Integer> daysInMonths = new HashMap<Integer,Integer>(){{
			put(1,31);
			put(2,28);
			put(3,31);
			put(4,30);
			put(5,31);
			put(6,30);
			put(7,31);
			put(8,31);
			put(9,30);
			put(10,31);
			put(11,30);
			put(12,31);
		}};
		if(year%4==0) {
			daysInMonths.replace(2, 29);
		}
		
		if(year >2020 || year <2000){
			throw new InvalidDateException("Invalid year");
		}
		if(month > 12 || month < 1) {
			throw new InvalidDateException("Invalid month");
		} 
		if(day>daysInMonths.get(month) || day<1) {
			throw new InvalidDateException("Invalid day");
		}
		
	}
	public int[][] validate(String email, String startDate, String endDate) throws Exception{
		
		
		int[] startDateArray = getDateArrayFromString(startDate.trim());
		validateDate(startDateArray[0],startDateArray[1],startDateArray[2]);
		int[] endDateArray = getDateArrayFromString(endDate.trim());
		validateDate(endDateArray[0],endDateArray[1],endDateArray[2]);
		validateEmail(email);
		return new int[][] {startDateArray, endDateArray};
}
	
	//data type converter methods
	public int[] getDateArrayFromString(String date) {
		return new int[] {Integer.parseInt(date.substring(0, 2)),Integer.parseInt(date.substring(2, 4)),Integer.parseInt(date.substring(4, 8))};
	}
	public int genderToInt(String gender) {
		switch(gender) {
		case "male":
			return 1;
		case "female":
			return 2;
		case "neutered":
			return 3;
		case "spayed":
			return 4;
		default:
			return 0;
		}
	}
	
	//adds pet entry to animals array and to the inputfile that the class reads from
	public boolean addEntry(String[] data) {
		try {
			addData(data);
			File animalFile = new File(inputFile);
		      Scanner fileReader = new Scanner(animalFile);
		      BufferedWriter out = new BufferedWriter( 
					   new FileWriter("temp.txt", false)); 
		      while (fileReader.hasNextLine()) {
		    	
					
		    	  String line = fileReader.nextLine();
		    	  if(!line.toUpperCase().trim().equals("END")) {
					out.write(line+"\n"); 
		    	  }
					
		      }
		      out.close();
		      fileReader.close();
		      File tempFile = new File("temp.txt");
		      fileReader = new Scanner(tempFile);
		      out = new BufferedWriter( 
					   new FileWriter(inputFile, false)); 
		      while (fileReader.hasNextLine()) {
		    	  String line = fileReader.nextLine();
		    	  if(!line.toUpperCase().trim().equals("END")) {
					out.write(line+"\n"); 
		    	  }
		      }
				String line = "";
				for(String str : data) {
					line += str + " ";
				}
				line.trim();
				line+="\n";
				out.write(line); 
				out.write("END");
				out.close(); 
				
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return false;
		}
		
	}
	
	//adds data to the animals array
	public boolean addData(String[] data) throws Exception{
		
			int[][] validatedDates;
			int[] startDateArray;
			int[] endDateArray;
		switch(data[0].trim().toUpperCase()) {
        case "DOG":
        	
        	
    		validatedDates = validate(data[3],data[7],data[8]);
    		startDateArray = validatedDates[0];
    		endDateArray = validatedDates[1];
    		Dog aDog = new Dog(data[1].trim(), data[2].trim(), data[3].trim(), data[4].trim(), data[6].trim());
    		aDog.setGender(genderToInt(data[5].trim()));
			aDog.setBoardStart(startDateArray[0],startDateArray[1],startDateArray[2]);
			aDog.setBoardEnd(endDateArray[0],endDateArray[1],endDateArray[2]);
			animals.add(aDog);
    		
        	
        	break;
        case "CAT":
        	
    		validatedDates = validate(data[3],data[7],data[8]);
    		startDateArray = validatedDates[0];
    		endDateArray = validatedDates[1];
    		Cat aCat = new Cat(data[1].trim(), data[2].trim(), data[3].trim(), data[4].trim(), data[6].trim());
    		aCat.setGender(genderToInt(data[5].trim()));
    		aCat.setBoardStart(startDateArray[0],startDateArray[1],startDateArray[2]);
			aCat.setBoardEnd(endDateArray[0],endDateArray[1],endDateArray[2]);
			animals.add(aCat);
    		
    			
        	break;
        case "BIRD":
        	
    
    		validatedDates = validate(data[3],data[6],data[7]);
    		startDateArray = validatedDates[0];
    		endDateArray = validatedDates[1];
    		Bird aBird = new Bird(data[1].trim(), data[2].trim(), data[3].trim(), data[4].trim());
    		aBird.setGender(genderToInt(data[5].trim()));
    		aBird.setBoardStart(startDateArray[0],startDateArray[1],startDateArray[2]);
			aBird.setBoardEnd(endDateArray[0],endDateArray[1],endDateArray[2]);
			animals.add(aBird);
    		
        	break;
        case "END":
        	return true;
        	
        default:
        	System.out.println("Invalid start of line");
        	break;
        }
		return false;
		
	}
	
	
	
	
}
