//class used to represent dogs
public class Dog extends Pet{
	//subclass specific instance variable
	private String size;
	
	//constructor (uses superclasses constructor)
	public Dog(String name, String ownerName, String ownerEmail, String color, String size) {
		super(name, ownerName, ownerEmail, color);
		this.size = size;
	}
	
	//get method for subclass specific field
	public String getSize() {
		return size;
	}
	
	//returns string based on fields
	public String toString() {
		return "DOG:\r\n" + 
				getPetName() + " owned by "+getOwnerName()+"\r\n" + 
				"owner's email: "+getEmail()+"\r\n" + 
				"Pet Color: "+getColor()+"\r\n" + 
				"Gender: "+getGender()+"\r\n" + 
				"Size: "+size+"\r\n" + 
				"**************************\r\n" + 
				"**************************";
	}
}
