//class used to represent cats
public class Cat extends Pet{
	//subclass specific instance variable
	private String hairLength;
	
	//constructor (uses superclasses constructor)
	public Cat(String name, String ownerName, String ownerEmail, String color, String hairLength) {
		super(name, ownerName, ownerEmail, color);
		this.hairLength = hairLength;
	}
	
	//get method for subclass specific field
	public String gethairLength() {
		return hairLength;
	}
	
	//returns string based on fields
	public String toString() {
		return "CAT:\r\n" + 
				getPetName() + " owned by "+getOwnerName()+"\r\n" + 
				"owner's email: "+getEmail()+"\r\n" + 
				"Pet Color: "+getColor()+"\r\n" + 
				"Gender: "+getGender()+"\r\n" + 
				"Hair: "+hairLength+"\r\n" + 
				"**************************\r\n" + 
				"**************************";
	}

}
