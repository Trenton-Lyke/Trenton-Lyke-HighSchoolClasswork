import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import java.awt.event.*;

//class for creating GUI for the animal hospital
public class GUI extends JFrame  {
	
	//instance variables for class
	final static String QUERYPANEL = "Run Query";
    final static String ENTRYPANEL = "Add Entry";
    final static int extraWindowWidth = 100;
	static GraphicsConfiguration gc;
	
	private static JFrame frame;
	private static JTextArea resultsField;
	
	private static JPanel formPage;
	
	
	
	
	private static AnimalHospital animalHospital;
	
	//main method for creating GUI
	
	public static void main(String[] args) {
		animalHospital = new AnimalHospital("Animals.txt");
		frame= new JFrame(gc);
		
		frame.setTitle("Welecome to the Animal Hospital");
		frame.setSize(2000, 2000);
		frame.setLocation(0, 0);
		
		
		
		JTabbedPane tabbedPane = new JTabbedPane();
		 
        //Create the "cards".
        JPanel queryPage = new JPanel() {
            //Make the panel wider than it really needs, so
            //the window's wide enough for the tabs to stay
            //in one row.
            public Dimension getPreferredSize() {
                Dimension size = super.getPreferredSize();
                size.width += extraWindowWidth;
                return size;
            }
        };
        queryPage.setLayout(new BorderLayout());
        queryPage.add(new JLabel("Query Page - Find Pets or Info about who is here"), BorderLayout.NORTH);
        resultsField = new JTextArea(15,50);
        resultsField.setMinimumSize(new Dimension(500, 1500));
        resultsField.setPreferredSize(new Dimension(500, 1500)); 
        JScrollPane scrollPane = new JScrollPane(resultsField);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        queryPage.add(scrollPane, BorderLayout.CENTER);
        JPanel buttonPanel = createButtonPanel();
        
        queryPage.add(buttonPanel, BorderLayout.SOUTH);
        formPage = new JPanel();
        formPage.setLayout(new BorderLayout());
        
        formPage.add(createForm("DOG", "", "", "", "", "male","01","01","2000","01","01","2020"),  BorderLayout.CENTER);
        
		
 
        tabbedPane.addTab(QUERYPANEL, queryPage);
        tabbedPane.addTab(ENTRYPANEL, formPage);
        
        JPanel pane = new JPanel();
        pane.setLayout(new BorderLayout());

        pane.add(tabbedPane, BorderLayout.CENTER);
        frame.add(pane);
        frame.pack();
        frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		
		
		
	}
	
	//prompt methods
	public static String prompt(String prompt){
		JFrame inputFrame = new JFrame("Input for query");
        String input = JOptionPane.showInputDialog(inputFrame, prompt);
        return input;
        
        
        
    }
	public static int[] promptDate(String prompt){
		JFrame inputFrame = new JFrame("Input for query");
		JComboBox month = new JComboBox(new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"});
		JComboBox day = new JComboBox(new String[] {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"});
		JComboBox year = new JComboBox(new String[] {"2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"});
		JPanel datePanel = new JPanel();
		datePanel.setLayout(new GridLayout(2,3));
		datePanel.add(new JLabel("Month"));
		datePanel.add(new JLabel("Day"));
		datePanel.add(new JLabel("Year"));
		datePanel.add(month);
		datePanel.add(day);
		datePanel.add(year);
		
		int result = JOptionPane.showConfirmDialog(null, datePanel, 
	               prompt, JOptionPane.OK_CANCEL_OPTION);
		int[] dateArray = new int[3];
		if (result == JOptionPane.OK_OPTION) {
	         dateArray[0]=Integer.parseInt((String) month.getSelectedItem());
	         dateArray[1]=Integer.parseInt((String) day.getSelectedItem());
	         dateArray[2]=Integer.parseInt((String) year.getSelectedItem());
	         
	    }
		else {
			dateArray = null;
		}
        
        
        return dateArray;
        
        
        
    }
	public static String promptType(String prompt){
		JFrame inputFrame = new JFrame("Input for query");
		JComboBox type = new JComboBox(new String[] {"DOG","CAT","BIRD"});
		JPanel datePanel = new JPanel();
		datePanel.setLayout(new GridLayout(2,1));
		datePanel.add(new JLabel("Type of Animal"));
		datePanel.add(type);
		
		
		int result = JOptionPane.showConfirmDialog(null, datePanel, prompt, JOptionPane.OK_CANCEL_OPTION);
		
		if (result == JOptionPane.OK_OPTION) {
	         return (String) type.getSelectedItem();
	         
	    }
		else {
			return null;
		}
        
        
        
        
        
    }
	
	//creates button panel
	public static JPanel createButtonPanel() {
		JPanel buttonPanel = new JPanel();
        buttonPanel.setMinimumSize(new Dimension(800,150));
        buttonPanel.setPreferredSize(new Dimension(800,150));
        buttonPanel.setLayout(new GridLayout(3,3));
        
       
        JButton getAllRecords = new JButton("Print All Records");
        
        
        JButton getByAnimalName = new JButton("Find Animals by Animal Name");
        
        
        JButton getByOwnerName = new JButton("Find Animals by Owner Name");
        
      
        JButton getByOwnerEmail = new JButton("Find Animals by Owner Email");
        
        
        JButton getByBoardingDate = new JButton("Find Animals Boarding at on a Specific Date");
        
        
        JButton getByType = new JButton("Find Animals by Type");
        
        
        JButton getByColor = new JButton("Find Animals by Color");
        
        
        JButton getByGender = new JButton("Find Animals by Gender");
        
        
        JButton ExitButton = new JButton("Exit");
        
        
        buttonPanel.add(getAllRecords);
        buttonPanel.add(getByAnimalName);
        buttonPanel.add(getByOwnerName);
        buttonPanel.add(getByOwnerEmail);
        buttonPanel.add(getByBoardingDate);
        buttonPanel.add(getByType);
        buttonPanel.add(getByColor);
        buttonPanel.add(getByGender);
        buttonPanel.add(ExitButton);
        
        
        
        
        getAllRecords.addActionListener(new ActionListener()
        {
           
            public void actionPerformed(ActionEvent e)
            {
            	resultsField.setText(animalHospital.getAllPetInfo());
            }
        }
        );
        
        
        getByAnimalName.addActionListener(new ActionListener()
        {
            
            public void actionPerformed(ActionEvent e)
            {
            	String name  = prompt("Enter the name of the pet: ");
            	if(name != null) {
            	resultsField.setText(animalHospital.getPetInfoByName(name));
            	}
            }
        }
        );
        
        
        getByOwnerName.addActionListener(new ActionListener()
        {
            
            public void actionPerformed(ActionEvent e)
            {
            	String name  = prompt("Enter the name of the owner: ");
            	if(name != null) {
            	resultsField.setText(animalHospital.getPetInfoByOwnerName(name));
            	}
            }
        }
        );
        
        getByOwnerEmail.addActionListener(new ActionListener()
        {
        	public void actionPerformed(ActionEvent e)
            {
        		String email = prompt("Enter the email of the owner: ");
            	if(email != null) {
            		resultsField.setText(animalHospital.getPetInfoByOwnerEmail(email));
            	}
            }
        }
        );
        
        
        getByBoardingDate.addActionListener(new ActionListener()
        {
            
            public void actionPerformed(ActionEvent e)
            {
            	int[] date = promptDate("Enter the date of boarding: ");
            	if(date != null) {
            		resultsField.setText(animalHospital.getPetsBoarding(date[0],date[1],date[2]));
            	}
            }
        }
        );
        
        
        getByType.addActionListener(new ActionListener()
        {
            
            public void actionPerformed(ActionEvent e)
            {   
            	String type= promptType("Enter the type of animal: ");
            	if(type != null) {
            		resultsField.setText(animalHospital.getPetInfoByType(type));
            	}
            }
        }
        );
        
        
        getByColor.addActionListener(new ActionListener()
        {
            
            public void actionPerformed(ActionEvent e)
            {
            	String color = prompt("Enter the color of the animal: ");
            	if(color != null) {
            		resultsField.setText(animalHospital.getPetInfoByColor(color));
            	}
            }
        }
        );
        
        
        getByGender.addActionListener(new ActionListener()
        {
        	public void actionPerformed(ActionEvent e)
            {
        		String gender = prompt("Enter the gender of animal: ");
            	if(gender != null) {
            		resultsField.setText(animalHospital.getPetInfoByGender(gender));
            	}
            }
        }
        );
        
        
        
        //action listener for the exit button
        ExitButton.addActionListener(new ActionListener()
        {
            //runs when the exit button is clicked
            public void actionPerformed(ActionEvent e)
            {
                //closes the window
                frame.dispose();
            }
        }
        );
        
        
        
		return buttonPanel;
	}
	
	//creates dynamic form for entry page
	public static JPanel createForm(String typeOfAnimal, String petName, String ownerName, String ownerEmail, String color, String genderOfAnimal, String aStartMonth, String aStartDay, String aStartYear, String anEndMonth, String anEndDay, String anEndYear) {
		JComboBox type = new JComboBox(new String[] {"DOG","CAT","BIRD"});
		
		type.setSelectedItem(typeOfAnimal);
		
		
		JPanel form = new JPanel();
		form.setLayout(new GridLayout(5,2));
		JPanel fieldAndLabel = new JPanel();
		fieldAndLabel.setLayout(new GridLayout(2,1));
		fieldAndLabel.add(new JLabel("Pet Type"));
		fieldAndLabel.add(type);
		form.add(fieldAndLabel);
		String[] labels = new String[] {"Pet Name:", "Owner Name:", "Owner Email", "Pet Color"};
		
		JTextField[] generalFormFields = new JTextField[] {new JTextField(petName), new JTextField(ownerName), new JTextField(ownerEmail), new JTextField(color)};
		for(int i = 0; i<generalFormFields.length; i++) {
			JPanel fieldAndLabel2 = new JPanel();
			fieldAndLabel2.setLayout(new GridLayout(2,1));
			fieldAndLabel2.add(new JLabel(labels[i]));
			fieldAndLabel2.add(generalFormFields[i]);
			form.add(fieldAndLabel2);
		}
		JPanel fieldAndLabel3 = new JPanel();
		fieldAndLabel3.setLayout(new GridLayout(2,1));
		fieldAndLabel3.add(new JLabel("Pet Gender"));
		JComboBox gender = new JComboBox(new String[] {"male","female","neutered","spayed"});
		gender.setSelectedItem(gender);
		fieldAndLabel3.add(gender);
		form.add(fieldAndLabel3);
		
		
		JPanel fieldAndLabel4 = new JPanel();
		fieldAndLabel4.setLayout(new GridLayout(2,1));
		JTextField other = new JTextField();
		switch(typeOfAnimal) {
		case "DOG":
			
			fieldAndLabel4.add(new JLabel("Size"));
			fieldAndLabel4.add(other);
			break;
		case "CAT":
			
			fieldAndLabel4.add(new JLabel("Hair Length"));
			fieldAndLabel4.add(other);
			break;
		case "BIRD":
			
			fieldAndLabel4.add(new JLabel(""));
			fieldAndLabel4.add(new JLabel(""));
			break;
		}
		form.add(fieldAndLabel4);
		
		
		JPanel dateAndLabel = new JPanel();
		dateAndLabel.setLayout(new GridLayout(2,1));
		
		JComboBox startMonth = new JComboBox(new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"});
		JComboBox startDay = new JComboBox(new String[] {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"});
		JComboBox startYear = new JComboBox(new String[] {"2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"});
		startMonth.setSelectedItem(aStartMonth);
		startDay.setSelectedItem(aStartDay);
		startYear.setSelectedItem(aStartYear);
		JPanel startDatePanel = new JPanel();
		startDatePanel.setLayout(new GridLayout(2,3));
		startDatePanel.add(new JLabel("Month"));
		startDatePanel.add(new JLabel("Day"));
		startDatePanel.add(new JLabel("Year"));
		startDatePanel.add(startMonth);
		startDatePanel.add(startDay);
		startDatePanel.add(startYear);
		dateAndLabel.add(new JLabel("Boarding Start Date"));
		dateAndLabel.add(startDatePanel);
		form.add(dateAndLabel);
		
		JPanel dateAndLabel2 = new JPanel();
		dateAndLabel2.setLayout(new GridLayout(2,1));
		
		JComboBox endMonth = new JComboBox(new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"});
		JComboBox endDay = new JComboBox(new String[] {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"});
		JComboBox endYear = new JComboBox(new String[] {"2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"});
		endMonth.setSelectedItem(anEndMonth);
		endDay.setSelectedItem(anEndDay);
		endYear.setSelectedItem(anEndYear);
		JPanel endDatePanel = new JPanel();
		endDatePanel.setLayout(new GridLayout(2,3));
		endDatePanel.add(new JLabel("Month"));
		endDatePanel.add(new JLabel("Day"));
		endDatePanel.add(new JLabel("Year"));
		endDatePanel.add(endMonth);
		endDatePanel.add(endDay);
		endDatePanel.add(endYear);
		dateAndLabel2.add(new JLabel("Boarding End Date"));
		dateAndLabel2.add(endDatePanel);
		form.add(dateAndLabel2);
		
		
		JPanel fieldAndLabel5 = new JPanel();
		fieldAndLabel5.setLayout(new GridLayout(2,1));
		fieldAndLabel5.add(new JLabel(""));
		
		JButton submitButton = new JButton("Submit");
		fieldAndLabel5.add(submitButton);
		form.add(fieldAndLabel5);
		
		type.addItemListener(new ItemListener() {

	        @Override
	        public void itemStateChanged(ItemEvent e) {
	        	formPage.add(createForm((String) type.getSelectedItem(), (String) generalFormFields[0].getText(), (String) generalFormFields[1].getText(), (String) generalFormFields[2].getText(), (String) generalFormFields[3].getText(), (String) gender.getSelectedItem(), (String) startMonth.getSelectedItem(), (String) startDay.getSelectedItem(), (String) startYear.getSelectedItem(),(String) endMonth.getSelectedItem(),(String) endDay.getSelectedItem(),(String) endYear.getSelectedItem() ),  BorderLayout.CENTER);
	            
	        }
	    });
		//action listener for the exit button
        submitButton.addActionListener(new ActionListener()
        {
            //runs when the exit button is clicked
            public void actionPerformed(ActionEvent e)
            {
            	
                if(((String) type.getSelectedItem()).equals("DOG") || ((String) type.getSelectedItem()).equals("CAT")) {
                
                String[] data = new String[] {(String) type.getSelectedItem(), (String) generalFormFields[0].getText(), (String) generalFormFields[1].getText(), (String) generalFormFields[2].getText(), (String) generalFormFields[3].getText(), (String) gender.getSelectedItem(), (String) other.getText(), refineDate((String) startMonth.getSelectedItem())+ refineDate((String) startDay.getSelectedItem())+ (String) startYear.getSelectedItem(),refineDate((String) endMonth.getSelectedItem())+refineDate((String) endDay.getSelectedItem())+(String) endYear.getSelectedItem()};
                animalHospital.addEntry(data);
                }
                else {
                	String[] data = new String[] {(String) type.getSelectedItem(), (String) generalFormFields[0].getText(), (String) generalFormFields[1].getText(), (String) generalFormFields[2].getText(), (String) generalFormFields[3].getText(), (String) gender.getSelectedItem(), refineDate((String) startMonth.getSelectedItem())+ refineDate((String) startDay.getSelectedItem())+ (String) startYear.getSelectedItem(),refineDate((String) endMonth.getSelectedItem())+refineDate((String) endDay.getSelectedItem())+(String) endYear.getSelectedItem()};
                    animalHospital.addEntry(data);
                }
                generalFormFields[0].setText("");
                generalFormFields[1].setText("");
                generalFormFields[2].setText("");
                generalFormFields[3].setText("");
                other.setText("");
                               
            }
        }
        );
		
		return form;
	}

	//makes sure a digit has a 0 before it in a string if it is less than 10
	public static String refineDate(String date) {
		if(date.length() < 2) {
			return "0"+date;
		}
		return date;
	}

}
