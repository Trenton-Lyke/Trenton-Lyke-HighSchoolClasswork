//a class used to represent birds
public class Bird extends Pet{
	
	//subclass specific instance variable
	private boolean featherClipped;
	
	//constructor (uses superclasses constructor)
	public Bird(String name, String ownerName, String ownerEmail, String color) {
		super(name, ownerName, ownerEmail, color);
		featherClipped = false;
	}
	
	//get method for subclass specific field
	public boolean clipped() {
		return featherClipped;
	}
	
	//set method for subclass specific field
	public void setClipped() {
		featherClipped = true;
	}
	
	//returns string based on fields
	public String toString() {
		return "BIRD:\r\n" + 
		getPetName() + " owned by "+getOwnerName()+"\r\n" + 
		"owner's email: "+getEmail()+"\r\n" + 
		"Pet Color: "+getColor()+"\r\n" + 
		"Gender: "+getGender()+"\r\n" + 
		"Feathers clipped: "+clipped()+"\r\n" + 
		"**************************\r\n" + 
		"**************************";
	}

}