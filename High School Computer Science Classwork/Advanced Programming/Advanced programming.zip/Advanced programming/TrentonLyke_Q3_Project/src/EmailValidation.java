//email validation class *not the creator of class
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class EmailValidation {
   
    //returns boolean base on if a string matches the regex format of an email
    public static boolean emailValidation(String email)
    {
        String email_pattern = "^[a-zA-Z0-9_#$%&�*+/=?^.-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pat = Pattern.compile(email_pattern);
        Matcher mat = pat.matcher(email);
        return mat.matches();
    }
    
}