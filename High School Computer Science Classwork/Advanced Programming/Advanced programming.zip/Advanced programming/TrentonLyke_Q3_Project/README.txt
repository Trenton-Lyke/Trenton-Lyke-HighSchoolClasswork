Author: Trenton Lyke
Created: 3/4/2020
Purpose/Description: A series of classes taking advantage of interfaces and inheritance 
in order to represent pets and data of an animal hospital. 