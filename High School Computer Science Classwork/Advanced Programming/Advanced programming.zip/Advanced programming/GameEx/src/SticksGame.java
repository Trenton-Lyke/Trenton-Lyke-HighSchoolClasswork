import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class SticksGame {
	private static int originalNumberOfSticks;
	private static int numberOfSticks;
	private static String name;
	private static ArrayList<Player> players;
	private static HashMap<Integer, Game> moveHistory;
	private ArrayList<Integer> moves;
	public SticksGame(String name, int numberOfSticks, ArrayList<Player> players) {
		// TODO Auto-generated constructor stub
		this.originalNumberOfSticks = numberOfSticks;
		this.numberOfSticks = numberOfSticks;
		this.name = name;
		this.players = players;
		this.moves = new ArrayList<Integer>();
		this.moveHistory = new HashMap<Integer, Game>();
	}
	public int getNumSticks() {
		return numberOfSticks;
		
	}
	public int getOriginalNumSticks() {
		return originalNumberOfSticks;
		
	}
	public ArrayList<Player> getPlayers() {
		return players;
		
	}
	public void removeSticks(int numberOfSticks) {
		this.numberOfSticks -= numberOfSticks;
		moves.add(numberOfSticks);
		
	}
	public HashMap<Integer, Game> getMoveHistory() {
		return moveHistory;
	}
	
	public boolean hasSticks() {
		return (this.numberOfSticks>0);
	}
	public void updateMoveHistory(int gameNumber, String losingPlayer) {
		moveHistory.put(gameNumber, new Game(moves, losingPlayer));
		moves = new ArrayList<Integer>();
		
	}
	public void resetGame() {
		numberOfSticks = getOriginalNumSticks();
		for( Player player : getPlayers()) {
			player.resetPlayer();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player p1 = new Player("P1",0,1, 9999);
		Player p2 = new Player("P2",0, 3, 9999);
		Player p3 = new Player("P3",0,3, 9999);
		Player p4 = new Player("P4",0,3, 9999);
		SticksGame bigGame = new SticksGame("Game", 20, new ArrayList<Player>(Arrays.asList(p1,p2)));
		for(int gameNumber = 1; gameNumber <= 10000; gameNumber++) {
		//System.out.println("Game "+gameNumber);
		//System.out.println("Hello let's play sticks starting with "+bigGame.getNumSticks() + " sticks");
		int moveNumber = 0;
		while(bigGame.hasSticks()) {
			
			for( Player player : bigGame.getPlayers()) {
				int decision = 0;
				if(bigGame.hasSticks()) {
				decision = player.takeSticksAll(moveNumber, bigGame.getNumSticks(), gameNumber);
					while(decision == 0 && bigGame.hasSticks()) {
						decision = player.takeSticksAll(moveNumber, bigGame.getNumSticks(), gameNumber);
					}
					bigGame.removeSticks(decision);
					//System.out.println(player.getName()+" removed "+ decision +" sticks. There are "+bigGame.getNumSticks()+" remaining.");
					
				}
				else {
					break;
				}
				if(!bigGame.hasSticks()) {
					for( Player otherPlayer : bigGame.getPlayers()) {
						
						if(otherPlayer.equals(player)) {
							//System.out.println(otherPlayer.getName()+" loses");
							otherPlayer.updateMoveHistory(gameNumber, false);
							//bigGame.updateMoveHistory(gameNumber, otherPlayer.getName());
						}
						else {
							//System.out.println(otherPlayer.getName()+" wins");
							otherPlayer.updateMoveHistory(gameNumber, true);
						}
					}
					
				}
			}
			moveNumber++;
		}
		//System.out.println("Done");
		
		bigGame.resetGame();
		}
		//for(int i = 1; i <= bigGame.getMoveHistory().size(); i++) {
			//System.out.println("Loser: "+bigGame.getMoveHistory().get(i).getLosingPlayer()+" moves of everyone: "+bigGame.getMoveHistory().get(i).getMoves());

		//}
		for(Player player : bigGame.getPlayers()) {
			System.out.print(player.getName() + " \n"+player.getMovePercentagesAsString());
		}
	}

}
