import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
public class Player {
	private int playeType;
	private String name;
	private int numberOfSticks;
	private HashMap<Integer, Game> moveHistory;
	private double[][] movePercentage;
	private int[] moves;
	private int trainingPeriod;
	public Player(String name, int numberOfSticks, int playeType, int trainingPeriod) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.numberOfSticks = numberOfSticks;
		this.moves = new int[20];
		this.moveHistory = new HashMap<Integer, Game>();
		this.playeType = playeType;
		this.movePercentage= new double[20][3];
		this.trainingPeriod = trainingPeriod;
	}
	public void addMove(int move, int numSticks) {
		moves[numSticks]=move;
	}
	public void updateMoveHistory(int gameNumber, boolean won) {
		
		moveHistory.put(gameNumber, new Game(moves, won));
		moves = new int[20];
		int largestSize = 20;
		
		
		movePercentage = new double[20][3];
		int[] moveCount = new int[20];
		for( int i =0; i < largestSize; i++ ) {
			
			movePercentage[i]=new double[] {0,0,0};
			moveCount[i]=0;
			
		}
		for(int i = 1; i <= moveHistory.size(); i++) {
			
			if(moveHistory.get(i).didWin()) {
				int[] moveSet = moveHistory.get(i).getMoves();
				
				for(int j = 0; j < moveSet.length; j++) {
					if(moveSet[j]-1 != -1) {
						double[] percentArray = movePercentage[j];
						percentArray[moveSet[j]-1]=percentArray[moveSet[j]-1]+1;
						movePercentage[j]= percentArray;
						moveCount[j] = moveCount[j]+1;
					}
				}
			}
		}
		for(int j = 0; j < movePercentage.length; j++) {
			
			double[] percentArray = movePercentage[j];
			int count = moveCount[j];
			
			for(int i = 0; i < percentArray.length; i++) {
				percentArray[i]=percentArray[i]/count;
				
			}
			
		}
	}
	public int[] getMoves() {
		return moves;
	}
	public String getName() {
		return name;
	}
	public String getMovePercentagesAsString(){
		String percentage = "";
		int i = 0;
		for(double[] percentages : movePercentage) {
			percentage += ""+(i+1) +". 1:"+percentages[0] +" 2:"+percentages[1]+" 3:"+percentages[2]+ " \n";
			i++;
		}
		return percentage;
	}
	public double[][] getMovePercentage(){
		return movePercentage;
		
	}
	public boolean isLegalMove(int numberOfSticks, int sticksInPlay) {
		return (sticksInPlay-numberOfSticks>=0);
	}
	public int takeSticks(int numberOfSticks, int sticksInPlay) {
		if(sticksInPlay == 1 || sticksInPlay == 2) {
			
			this.numberOfSticks += 1;
			
			addMove(1,sticksInPlay-1);
			
			return 1;
		}
		else if(isLegalMove(numberOfSticks,sticksInPlay) && numberOfSticks >=1 && numberOfSticks <= 3) {
			this.numberOfSticks += numberOfSticks;
			
			addMove(numberOfSticks,sticksInPlay-1);
			
			return numberOfSticks;
		}
		return 0;
	}
	public int takeSticksAll(int moveNumber, int sticksInPlay, int gameNumber) {
		if(playeType == 1) {
			return takeRandomSticks( sticksInPlay);
		}
		
		else if(playeType == 2) {
			return takeUserSticks(sticksInPlay);
		}
		else {
			return takeStratSticks(moveNumber,sticksInPlay, gameNumber);
		}
	}
	public int takeRandomSticks(int sticksInPlay) {
		int randomNumberOfSticks = getRandomNumberInRange(1, 3);
		return takeSticks(randomNumberOfSticks, sticksInPlay);
	}
	public int takeUserSticks(int sticksInPlay) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Choose to take between 1-3 sticks: ");
		String line = scan.nextLine();
		int numberOfSticks = Integer.parseInt(line);
		return takeSticks(numberOfSticks, sticksInPlay);
		
	}
	public int takeStratSticks(int moveNumber, int sticksInPlay, int gameNumber) {
		int bestMove = 1;
		double bestPercent = 0;
		
		for(int i = 1; i <= 3; i++) {
			if(movePercentage[sticksInPlay-1] != new double[] {0,0,0} && gameNumber > trainingPeriod) {
			if(!(new Double(movePercentage[sticksInPlay-1][i-1])).isNaN()) {
				
			//System.out.println(movePercentage.get(moveNumber)[i-1]);
				if(movePercentage[sticksInPlay-1][i-1] > bestPercent) {
					
					bestMove = i;
					bestPercent =movePercentage[sticksInPlay-1][i-1];
				}
			}
			
		}
			else {
				
				return takeRandomSticks(sticksInPlay);
			}
			
		}
		
		return takeSticks(bestMove, sticksInPlay);
	}
	private static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	public void resetPlayer() {
		numberOfSticks = 0;
	}

}
