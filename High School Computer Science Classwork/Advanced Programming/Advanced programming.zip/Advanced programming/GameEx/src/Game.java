import java.util.ArrayList;

public class Game {
	private int[] moves;
	private ArrayList<Integer> moves2;
	private boolean won;
	private String losingPlayer;
	public Game(int[] moves, boolean won) {
		// TODO Auto-generated constructor stub
		this.moves = moves;
		this.won = won;
	}
	public Game(ArrayList<Integer> moves, String losingPlayer) {
		// TODO Auto-generated constructor stub
		this.moves2 = moves;
		this.won = won;
	}
	public Game(int[] moves, String losingPlayer) {
		// TODO Auto-generated constructor stub
		this.moves = moves;
		this.losingPlayer = losingPlayer;
	}
	public int[] getMoves(){
		return moves;
	}
	public ArrayList<Integer> getMoves2(){
		return moves2;
	}
	public boolean didWin() {
		return won;
	}
	public String getLosingPlayer(){
		return losingPlayer;
	}

}
