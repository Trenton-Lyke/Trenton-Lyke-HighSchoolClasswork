import java.io.File;  // Import the File class
import java.io.FileWriter;
import java.io.IOException;
public class Sorter2 {

	
	public static void mergeSort(int[] a, int n) {
	    if (n < 2) {
	        return;
	    }
	    int mid = n / 2;
	    int[] l = new int[mid];
	    int[] r = new int[n - mid];
	 
	    for (int i = 0; i < mid; i++) {
	        l[i] = a[i];
	    }
	    for (int i = mid; i < n; i++) {
	        r[i - mid] = a[i];
	    }
	    mergeSort(l, mid);
	    mergeSort(r, n - mid);
	 
	    merge(a, l, r, mid, n - mid);
	}
	
	public static void merge(
			  int[] a, int[] l, int[] r, int left, int right) {
			  
			    int i = 0, j = 0, k = 0;
			    while (i < left && j < right) {
			        if (l[i] <= r[j]) {
			            a[k++] = l[i++];
			        }
			        else {
			            a[k++] = r[j++];
			        }
			    }
			    while (i < left) {
			        a[k++] = l[i++];
			    }
			    while (j < right) {
			        a[k++] = r[j++];
			    }
			}
	

 public static int[] getRandomArray(int length) {
	 int[] randomArray = new int[length];
	 for(int number: randomArray) {
		 number = (int) (length*Math.random());
	 }
	 return randomArray;
 }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
			 try {
			      File myObj = new File("sort.txt");
			      if (myObj.createNewFile()) {
			        System.out.println("File created: " + myObj.getName());
			      } else {
			        System.out.println("File already exists.");
			      }
			      try {
				      FileWriter myWriter = new FileWriter("sort.txt");
				      myWriter.write("List Size, Merge Sort\n");
				      for(int i =10000; i <= 10000000; i+=999000) {
				    	  int[] randArray = getRandomArray(i);
				    	  
				    	  double initTime = System.nanoTime();
				    	  mergeSort(randArray, randArray.length);
				    	  double elapsedTime = System.nanoTime() - initTime;
				    	  
				    	  
				 
				    	  System.out.println(i+","+elapsedTime);
				    	  
				      }
				      myWriter.close();
				      System.out.println("Successfully wrote to the file.");
				    } catch (IOException e) {
				      System.out.println("An error occurred.");
				      e.printStackTrace();
				    }
			    } catch (IOException e) {
			      System.out.println("An error occurred.");
			      e.printStackTrace();
			    }
			 
	}

}
