import java.awt.Color;
import java.util.Scanner;
import java.util.Stack;

class GFG 
{ 
	//array of stacks
	//indexes represent rods
	//layers on stack represent disks 
	//where the value of the stack is proportional to the disk width
	static Stack[] rods = {new Stack(), new Stack(), new Stack()};
	
	static Canvas myCanvas;
	static double canvasHeight = 600;
	static double rodHeight = canvasHeight - 100;
	static double diskHeight;
	static double diskWidthCoefficient;
	static int rodWidth;
	static int n;
	static Color[] colors;
	
	
	
    // Java recursive function to solve tower of hanoi puzzle 
    static void towerOfHanoi(int n, Stack from_rod, Stack to_rod, Stack aux_rod) 
    { 
    	//base case
        if (n == 1) 
        { 
        	//System.out.println("Move disk 1 from rod " +  from_rod + " to rod " + to_rod); 
        	from_rod.pop();
        	to_rod.push(n);
        	
            
            drawStacks();
        	return; 
        } 
        
        //recursive step
        towerOfHanoi(n-1, from_rod, aux_rod, to_rod); 
        //System.out.println("Move disk " + n + " from rod " +  from_rod + " to rod " + to_rod); 
        from_rod.pop();
        to_rod.push(n);
        
        drawStacks();
        towerOfHanoi(n-1, aux_rod, to_rod, from_rod); 
        
    } 
      
    //  Driver method 
    public static void main(String args[]) 
    { 
    	for(int k = 1; k < 50;k++) {
    	double initial_time= System.currentTimeMillis();
    	//Scanner scan = new Scanner(System.in);
    	//System.out.println("Enter a number 1 to 6: ");
    	//String input = scan.nextLine();
    	n = k;
    	/*if(isNumeric(input) ) {
    		n = Integer.parseInt(input);
    	}
    	else {
    		System.out.println("Sorry that was an invalid input default set to 4");
    	}*/
    	colors = new Color[n];
    	
    	for(int i = 0; i < n; i++) {
    		colors[n-1-i] = Color.getHSBColor(i*((float)1)/n, 1, 1);
    		//System.out.println(colors[i]);
    	}
    	//number of disks in the game
    	
    	//canvas that the game is drawn on
    	myCanvas = new Canvas("Tower of Hanoi Bonaza", 1260, (int) canvasHeight);
    	diskHeight = rodHeight/n;
    	diskWidthCoefficient = 50/n;
    	drawRods(); 
  
    	//adds disks to rod
        for(int i = n; i >= 1; i--) {
        	rods[0].push(i);
        }
        
        //draws stacks initially
        drawStacks();
        
        //recurively solves puzzle
        towerOfHanoi(n, rods[0], rods[2], rods[1]);  // A, B and C are names of rods 
        
        double final_time = System.currentTimeMillis();
        System.out.println("number of disks: "+k+" elapsed time: " + ((final_time-initial_time)/1000)+" seconds");
        rods[2] = new Stack();
    	}
    } 
    //draws rods
    public static void drawRods() {
    	myCanvas.setForegroundColor(Color.BLACK);
        for(int i = 0; i <3; i++) {
        	rodWidth = (int) (diskWidthCoefficient*.8);
        	
        	myCanvas.fillRectangle(200+(400+rodWidth)*i,100, rodWidth, (int)rodHeight);
    	}
    }
    
    //draws stacks
    public static void drawStacks() {
    	myCanvas.erase();
    	drawRods();
    	for(int rod = 0; rod < rods.length; rod++) {
    		for(int disk = 0; disk<rods[rod].size() ; disk++) {
    			int diskNumber = (int)rods[rod].elementAt(disk);
    			
    			myCanvas.setForegroundColor(colors[diskNumber-1]);
	    			
    			int diskWidth = (int)(diskWidthCoefficient*diskNumber);
    			myCanvas.fillRectangle(((200+rodWidth/2)-diskWidth/2) + (400+rodWidth)*rod, (int) (100 + diskHeight*(n-1) - diskHeight*disk), (int) diskWidth, (int) diskHeight);
    		}
    	}
    	myCanvas.wait(10);
    	
    }
    public static boolean isNumeric(String str) { 
		  try {  
		    Integer.parseInt(str);  
		    return true;
		  } catch(NumberFormatException e){  
		    return false;  
		  }  
		}
} 