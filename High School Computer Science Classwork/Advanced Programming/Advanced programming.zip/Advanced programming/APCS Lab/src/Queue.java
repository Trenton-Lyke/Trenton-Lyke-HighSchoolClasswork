import java.util.Random;

public class Queue {

	private static int[] queue = new int[3];
	public Queue() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int size = 0;
		String[] directions = args[0].trim().split(",");
		for(String direction : directions) {
			System.out.println("Input is "+direction.trim());
			switch(direction.trim()) {
				case "1":
					System.out.println("The input is enque");
					if(size < 3) {
						
						queue[size]=getRandomNumberInRange(0, 100);
						size++;
						System.out.print("\nFront");
						for(int i = 0; i < size; i++) {
							System.out.print(" "+queue[i]+" ");
						}
						System.out.print("End\n");
					}
					else {
						System.out.println("Queue is full");
					}
					break;
				case "2":
					System.out.println("The input is deque");
					if(size > 0) {
						for(int i = 1; i < size; i++) {
							queue[i-1]=queue[i];
						}
						size--;
						queue[size]=0;
						System.out.print("\nFront");
						for(int i = 0; i < size; i++) {
							System.out.print(" "+queue[i]+" ");
						}
						System.out.print("End\n");
					}
					else {
						System.out.println("Queue is empty");
					}
					break;
			}
		}
	}
	public static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}

}
