
public class PrimeNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean[] aPrimeArray = getPrimes(1000000);
		for(int i = 0; i < aPrimeArray.length; i++) {
			if(aPrimeArray[i]) {
				System.out.println(i);
			}
		}
	}
	public static boolean[] getPrimes(int upperBound) {
		boolean[] primeArray = new boolean[upperBound];
		
		//initializes array for algorithm
		for(int i = 0; i < upperBound; i++) {
			primeArray[i] = true;
		}
		primeArray[0] = false;
		primeArray[1] = false;
		
		//loops through half of range
		for(int i = 0; i < upperBound/2; i++) {
			
			//if the index is true (i.e. the index is true) then it sets all indexes that are multiples of that index to false
			if(primeArray[i]) {
				for(int j = 2*i; j< upperBound; j+=i) {
					primeArray[j] = false;
				}
			}
		}
		return primeArray;
	}

}
