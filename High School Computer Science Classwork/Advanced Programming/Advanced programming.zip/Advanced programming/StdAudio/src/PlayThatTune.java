import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PlayThatTune {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		int sps = 44100;
		
		
		
		Scanner scan = new Scanner(new File("music2.txt"));
		while(scan.hasNextLine()) {
			String[] line = scan.nextLine().trim().split(" ");
			
			double duration = Double.parseDouble(line[1].trim());
			int N = (int) (sps * duration);	
			double[] a = new double[N+1];
			
					
		
			double hz = (440 * Math.pow(2,Double.parseDouble(line[0].trim())/12));
			System.out.println(hz);
		for(int i = 0; i <= N; i++) {
			a[i] = Math.sin(2*Math.PI *i*  hz/sps);
		}
		StdAudio.play(a);
		}
	}

}
