
public class Palindrome {
	
	public static boolean isPalindrome(String number){
		if(number.length() == 2) {
			if(number.charAt(0)==number.charAt(1)) {
				return true;
			}
			else {
				return false;
			}
		}
		if(number.length() == 1) {
			return true;
		}
		if(number.charAt(0)==number.charAt(number.length()-1)) {
			return true && isPalindrome(number.substring(1,number.length()-1));
		}
		else {
			return false;
		}
	}
}
