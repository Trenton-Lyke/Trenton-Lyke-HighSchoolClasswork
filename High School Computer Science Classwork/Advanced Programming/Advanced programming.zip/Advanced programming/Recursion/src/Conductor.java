import java.util.Scanner;
import java.util.*;

public class Conductor {
	public static void main(String args[]) 
    { 
		
		int highestPalindrome = 0;
		int multiplier1 = 0;
		int multiplier2 = 0;
		int numOfPalindromes = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of digits: ");
    	String input = scan.nextLine();
    	double initTime=System.currentTimeMillis();
    	Set<String> palindromes = new HashSet<String>(); 
         
    	
    	int digits =3;
    	if(isNumeric(input) ) {
    		digits = Integer.parseInt(input);
    	}
    	else {
    		System.out.println("Sorry that was an invalid input default set to 4");
    	}
		for(int i =(int)Math.pow(10, digits-1); i <= Math.pow(10, digits)-1; i++) {
			for(int j =(int) Math.pow(10, digits-1); j <= Math.pow(10, digits)-1; j++) {
				if(Palindrome.isPalindrome(""+(i*j)) && highestPalindrome < (i*j)) {
					highestPalindrome = i*j;
					multiplier1 = i;
					multiplier2 = j;
					
				}
				if(Palindrome.isPalindrome(""+(i*j))) {
					palindromes.add(""+(i*j)); 
				}
			}
		}
		
		System.out.println("i: "+multiplier1);
		System.out.println("j: "+multiplier2);
		System.out.println("number of palindrome: "+palindromes.size());
		System.out.println("largest palindrome: "+highestPalindrome);
		System.out.println("elapsed time: " +(System.currentTimeMillis()-initTime));
    }
	public static boolean isNumeric(String str) { 
		  try {  
		    Integer.parseInt(str);  
		    return true;
		  } catch(NumberFormatException e){  
		    return false;  
		  }  
	}
}
