import java.util.Stack;

public class Fib {
	
	//returns a stack of fibonacci numbers using recursion
	public static Stack getFibonacciNumbers(int n) {
		//base case
		if(n==2) {
			Stack fibNumbers = new Stack();
			fibNumbers.push(0);
			fibNumbers.push(1);
			return fibNumbers;
			
		}
		//recursive step
		else {
			Stack fibNumbers = getFibonacciNumbers(n-1);
			int nextNumber = (int)fibNumbers.elementAt(fibNumbers.size()-1)+(int)fibNumbers.elementAt(fibNumbers.size()-2);
					
			fibNumbers.add(nextNumber);
			return fibNumbers;
		}
	}
	
}
