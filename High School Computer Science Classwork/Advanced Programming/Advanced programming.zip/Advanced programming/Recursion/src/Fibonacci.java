import java.util.Stack;

public class Fibonacci {
	
	
	public static Stack getFibonacciNumbers(int n) {
		
		if(n==2) {
			Stack fibNumbers = new Stack();
			fibNumbers.push(0);
			fibNumbers.push(1);
			return fibNumbers;
			
		}
		else {
			Stack fibNumbers = getFibonacciNumbers(n-1);
			int nextNumber = (int)fibNumbers.elementAt(fibNumbers.size()-1)+(int)fibNumbers.elementAt(fibNumbers.size()-2);
					
			fibNumbers.add(nextNumber);
			return fibNumbers;
		}
	}
	
}
