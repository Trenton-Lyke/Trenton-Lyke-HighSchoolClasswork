import java.util.Stack;

public class Driver {
	public static void main(String args[]) 
    { 
		//gets first 40 fibonacci numbers
		Stack fibNumbers = Fib.getFibonacciNumbers(40);
		int sum = 0;
		System.out.println("All fibonacci numbers: ");
		for(int i =0; i < fibNumbers.size(); i++) {
			
			//prints out all fibonacci numbers
			System.out.println(fibNumbers.get(i));
					
			//filters out all odd fibonacci numbers and fibonacci numbers greater than or equal to 4000000
			//adds filtered fibonacci to the sum
			if((int)fibNumbers.get(i)%2==0 && (int)fibNumbers.get(i) < 4000000) {
				
				sum += (int)fibNumbers.get(i);
			}
		}
		//prints out sum
		System.out.println("sum: " + sum);
			
    }
}
