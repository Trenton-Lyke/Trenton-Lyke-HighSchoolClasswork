
public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(power(1,2));
	}
	public static int power(int base, int exponent) {
		if(exponent == 1) {
			return base;//base case
		}
		else {
			return (base*power(base, exponent-1));//recursive step
			
		}
	}

}
