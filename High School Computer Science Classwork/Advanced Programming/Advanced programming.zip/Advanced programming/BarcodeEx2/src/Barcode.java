
public class Barcode {
	
	
	//converts a barcode zipcode into a numerical zipcode
	public static String convertZipCodeBarcodeToDigits(String barcode){
		if(barcode != null) {
			String strippedBarcode = barcode.replaceAll("\\s","");
			if(strippedBarcode.length() == 32 && strippedBarcode.charAt(0) == '|' && strippedBarcode.charAt(0) == strippedBarcode.charAt(strippedBarcode.length()-1)) {
				barcode = strippedBarcode.substring(1,strippedBarcode.length());
			}
			else {
				System.out.println("error invalid zipcode");
				return "";
			}
			}
			else {
				System.out.println("error invalid zipcode");
				return "";
			}
		String digits = "";
		for(int i = 0; i < barcode.length()-1; i +=5) {
			int digit = Digit.convertBarcodeToDigit(barcode.substring(i, i+5));
			if(digit != -1) {
				digits += digit;
			}
			else {
				System.out.println("error unrecognized pattern in barcode");
				return "";
			}
			
		}
		return digits.substring(0,digits.length()-1);
	}
	
	//converts numerical zipcode to a barcode zipcode
	public static String convertZipCodeDigitsToBarcode(String digits) {
		if(isNumeric(digits) && digits.length() == 5 ) {	
			String barcode = "|";
			int sum = 0;
			for(int i = 0; i < digits.length(); i++) {
				int digit = Integer.parseInt(String.valueOf(digits.charAt(i)));
				barcode += Digit.convertDigitToBarcode(digit);
				sum += digit;
				
			}
			barcode += Digit.convertDigitToBarcode(new Integer(((10-(sum%10))%10)))+"|";
			
			return barcode;
		}
		else if(digits.length() != 5) {
			System.out.println("error input was not the correct size");
			return "";
		}
		else {
			System.out.println("error input was not numerical");
			return "";
		}
	}
	
	//checks if a string is an integer
	public static boolean isNumeric(String str) { 
		  try {  
		    Integer.parseInt(str);  
		    return true;
		  } catch(NumberFormatException e){  
		    return false;  
		  }  
		}
	
}
