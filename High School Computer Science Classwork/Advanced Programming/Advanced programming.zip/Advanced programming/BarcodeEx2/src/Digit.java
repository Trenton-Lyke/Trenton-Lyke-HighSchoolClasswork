import java.util.ArrayList;
import java.util.*;
public class Digit {
	//initializes a ArrayList of all the barcodes at the index of the digit they represent
	static ArrayList<String> digitTable = new ArrayList<String>(Arrays.asList("||:::",":::||","::|:|","::||:",":|::|", ":|:|:",":||::","|:::|","|::|:","|:|::"));
	
	//converts a barcode to a digit
	public static int convertBarcodeToDigit(String symbolCode) {
		int digit = digitTable.indexOf(symbolCode);
		if(digit != -1) {
			return digit;
		}
		else {
			System.out.println("error invalid barcode");
			return -1;
		}
		
	}
	
	//converts a digit to a barcode
	public static String convertDigitToBarcode(int digit) {
		if(digit <= 9 && digit >= 0) {
		
		return digitTable.get(digit);
		}
		else {
			System.out.println("error invalid digit");
			return "";
		}
	}
	
	
	
}
