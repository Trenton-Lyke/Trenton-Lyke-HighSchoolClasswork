
public class Digit {
	
	public static int convertSymbolToDigit(String symbolCode) {
		if(symbolCode.length() == 5) {
			if(symbolCode.equals("||:::")) {
				return 0;
			}
			int[] placeValue = {7,4,2,1,0};
			int digit = 0;
			for(int i = 0; i < symbolCode.length(); i++) {
				if(symbolCode.charAt(i) == '|') {
					digit += placeValue[i];
				}
				else if(symbolCode.charAt(i) == ':'){
					
				}
				else {
					System.out.println("error invalid symbol code");
					return -1;
				}
				
			}
			return digit;
		}
		else {
			System.out.println("error invalid symbol code");
			return -1;
		}
		
	}
	public static int convertNumberCodeToDigit(String numberCode) {
		String symbolCode = convertToSymbolCode(numberCode);
		if(symbolCode != "") {
			int digit = convertSymbolToDigit(symbolCode);
			return digit;
		}
		else {
			return -1;
		}
	}
	public static String convertToNumberCode(int digit) {
		if(digit <= 9 && digit >= 0) {
		String[] digitTable = {"11000","00011","00101","00110","01001", "01010","01100","10001","10010","10100"};
		return digitTable[digit];
		}
		else {
			System.out.println("error invalid digit");
			return "";
		}
	}
	public static String convertToSymbolCode(String numberCode) {
		if(numberCode.length() == 5) {
		String symbolCode = "";
		for(int i = 0; i < numberCode.length(); i++) {
			if(numberCode.charAt(i) == '1') {
				symbolCode += "|";
			}
			else {
				symbolCode += ":";
			}
		}
		return symbolCode;
		}
		else {
			System.out.print("error invalid number code");
			return "";
		}
	}
	public static String convertToSymbolCode(int digit) {
		String numberCode = convertToNumberCode(digit); 
		if(numberCode != "") {
			String symbolCode = convertToSymbolCode(numberCode);
			return symbolCode;	
		}
		else {
			return "";
		}
	}
	
}
