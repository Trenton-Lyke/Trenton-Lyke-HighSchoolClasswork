
public class Barcode {
	
	
	
	public static String convertZipCodeToDigits(String barcode){
		if(barcode != null) {
			String strippedBarcode = barcode.replaceAll("\\s","");
			if(strippedBarcode.length() == 32 && strippedBarcode.charAt(0) == '|' && strippedBarcode.charAt(0) == strippedBarcode.charAt(strippedBarcode.length()-1)) {
				barcode = strippedBarcode.substring(1,strippedBarcode.length());
			}
			else {
				System.out.println("error invalid zipcode");
				return "";
			}
			}
			else {
				System.out.println("error invalid zipcode");
				return "";
			}
		String digits = "";
		for(int i = 0; i < barcode.length()-1; i +=5) {
			int digit = Digit.convertSymbolToDigit(barcode.substring(i, i+5));
			if(digit != -1) {
				digits += digit;
			}
			else {
				System.out.println("error unrecognized symbol in barcode");
				return "";
			}
			
		}
		return digits.substring(0,digits.length()-1);
	}
	public static String convertToDigits(String barcode){
		String digits = "";
		for(int i = 0; i < barcode.length()-1; i +=5) {
			
			int digit = Digit.convertSymbolToDigit(barcode.substring(i, i+5));
			if(digit != -1) {
				digits += digit;
			}
			else {
				System.out.println("error unrecognized symbol in barcode");
				return "";
			}
			
		}
		return digits;
	}
	public static String convertToBarcode(String digits) {
		if(isNumeric(digits)) {
			String barcode = "|";
			
			for(int i = 0; i < digits.length(); i++) {
				int digit = Integer.parseInt(String.valueOf(digits.charAt(i)));
				barcode += Digit.convertToSymbolCode(digit);
				
			}
			barcode += "|";
			return barcode;
		}
		else {
			System.out.println("error innput was not numerical");
			return "";
		}
	}
	public static String convertZipCodeToBarcode(String digits) {
		if(isNumeric(digits) && digits.length() == 5 ) {	
			String barcode = "|";
			int sum = 0;
			for(int i = 0; i < digits.length(); i++) {
				int digit = Integer.parseInt(String.valueOf(digits.charAt(i)));
				barcode += Digit.convertToSymbolCode(digit);
				sum += digit;
			}
			barcode += Digit.convertToSymbolCode(new Integer((10-(sum%10))))+"|";
			return barcode;
		}
		else if(digits.length() != 5) {
			System.out.println("error innput was not the correct size");
			return "";
		}
		else {
			System.out.println("error innput was not numerical");
			return "";
		}
	}
	public static boolean isNumeric(String str) { 
		  try {  
		    Double.parseDouble(str);  
		    return true;
		  } catch(NumberFormatException e){  
		    return false;  
		  }  
		}
	
}
