import java.util.Scanner;
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input;
		do {
			Scanner scan = new Scanner(System.in);
			System.out.println("Input 1,2,3,4, or 5");
			input = scan.nextLine().replaceAll("\\s","");
			switch(input) {
				case "1":
					System.out.println("Input a digit to get a barcode");
					
					String stringDigit = scan.nextLine().replaceAll("\\s","");
					if(isNumeric(stringDigit)) {
						System.out.println(Digit.convertToSymbolCode(Integer.parseInt(stringDigit)));
					}
					else {
						System.out.println("error input was not numeric");
					}
					break;
				case "2":
					System.out.println("Input a barcode to get a digit");
					String barcode = scan.nextLine().replaceAll("\\s","");
					int digit = Digit.convertSymbolToDigit(barcode);
					if(digit != -1) {
						System.out.println(digit);
					}
					break;
				case "3":
					System.out.println("Input a zipcode pattern to get a zipcode number");
					String zipcode = scan.nextLine().replaceAll("\\s","");
					
					System.out.println(Barcode.convertZipCodeToDigits(zipcode));
					break;
				case "4":
					System.out.println("Input a zipcode number to get a zipcode pattern");
					String zipcodeNumber = scan.nextLine().replaceAll("\\s","");
					System.out.println(Barcode.convertZipCodeToBarcode(zipcodeNumber));
					break;
				case "5":
					System.out.println("Thank you. Now ending the program.");
					break;
				default:
					System.out.println("Invalid input.");
					break;
			}
			
			
		}while(!input.equals("5"));
		
	}
	public static boolean isNumeric(String str) { 
		  try {  
		    Double.parseDouble(str);  
		    return true;
		  } catch(NumberFormatException e){  
		    return false;  
		  }  
		}

}
