#!/bin/bash
#This program uses the following
#figlet
#cowsay
#sl
#cmatrix
#libaa-bin
#pacman
#bb
#You may have to create symbilic links for some of those packages like so: ln -s /usr/games/program_name /usr/bin/program_name

echo "This program uses figlet, cowsay, sl, cmatrix, libaa-bin, pacman, and bb. You may have to create symbilic links for some of those packages like so: \nln -s /usr/games/program_name /usr/bin/program_name"

#creates array for the results to be displayed at the end
declare -a resultsArray

#displays title with figlet
figlet -f banner.flf "Welcome to the choose your own adventure game titled: BREAD"

#uses dragon to greet you based on the time of the day with cowsay
coditionalTimeInHours=$(date +%k)
greeting="Greetings"
if [ $coditionalTimeInHours -lt 6 ]; then
  greeting="You Should Be Asleep"
elif [ $coditionalTimeInHours -lt 12 ]; then
  greeting="Good Morning"
elif [ $coditionalTimeInHours -lt 19 ]; then
  greeting="Good Afternoon"
else
  greeting="Good Evening"
fi
cowsay -f dragon "$greeting $USER."
sleep 2

#gets the correct name of the user if they do not go by their username
cowsay -f dragon "$USER is your name right?"
read -p "Y/N: " userinput
playerName="$USER"
if [ "$userinput" == "N" ]; then
cowsay -f dragon "Oopsy Doopsy! What is your name then?"
read -p "Enter your name: " playerName
cowsay -f dragon "Sorry about that my bad. $greeting $playerName. Let's get to it."
else
cowsay -f dragon "Alrighty then $playerName. Let's get to it."
fi
resultsArray[0]="$playerName"
sleep 3

cowsay -f dragon "Okay but first lets hear a message from our cow of fortune."

sleep 3

cowsay "This video is sponsored by RAID SHADOW LEGENDS. An amazing mobile game that combines amazing graphics with amazing gameplay, stories, and more."

sleep 2

cowsay -f dragon "No you fool. Say the fortune."

sleep 3

cowsay "Oh sorry"

sleep 1

#displays randomly generated fortune with fortune and cowsay
fortune|cowsay

sleep 4


#run train using sl until the player dies
cowsay -f dragon "Oh wait!!Oh no!!A train!!Watch out $playerName. Try to dodge it or to stop it with your mind or something."
read -p "Enter 1 to dodge or 2 to try to stop the train with yor mind: " userInput


i=0
while [ "$userInput" == "1" ]
do
((i++))
sleep 3
sl
cowsay -f dragon "Oh no another train do you dodge?"
read -p "Enter 1 to dodge or 2 to try to stop the train with yor mind: " userInput
done
resultsArray[1]="$i"
clear

figlet "YOU DIED $playerName"

sleep 3


#displays matrix using cmatrix to scare the player
figlet "And now you've been hacked hit q to escape"

sleep 3

cmatrix

cowsay -f dragon "Okay $playerName that was probably pretty stressful how about you chillax for a little bit do you wanna sit relax by a fire or play some videogames?"

#allows te player to look at a fire using aafire, play pacman with pacman, or use the bb command if they choose neither
read -p "Enter 1 for fire or 2 for video games: " userInput
if [ "$userInput" == "1" ];then
cowsay -f dragon "Alrighty then let's relax by the fire since we're done with everything now!"
sleep 2
resultsArray[2]="You decided to relax by the fire."
cowsay -f dragon "But before we do that I just want to let you know the data that I collected on you using an array. Your name is ${resultsArray[0]}, you dodged the train ${resultsArray[1]} times, and ${resultsArray[2]}"
sleep 2
aafire

elif [ "$userInput" == "2" ];then
cowsay -f dragon "Alrighty then let's play some pacman my dudes since we're done with everything!"
resultsArray[2]="You decided to play video games."
sleep 2
cowsay -f dragon "But before we do that I just want to let you know the data that I collected on you using an array. Your name is ${resultsArray[0]}, you dodged the train ${resultsArray[1]} times, and ${resultsArray[2]}" 
sleep 2
pacman
else
cowsay -f dragon "I'm done with this I give up"
sleep 2
resultsArray[2]="You decided to ne mean to me."
cowsay -f dragon "But before I do that I just want to let you know the data that I collected on you using an array. Your name is ${resultsArray[0]}, you dodged the train ${resultsArray[1]} times, and ${resultsArray[2]}"
sleep 2
bb
fi






