import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class QProject {
	//scanner for getting key for cypher key table
	private Scanner userScanner = new Scanner(System.in);
	//key table used for encypting and decrypting
	private char[][] keyTable;
	//alphabet used by cypher
	private final char[] ALPHABET = "ABCDEFGHIKLMNOPQRSTUVWXYZ".toCharArray();
	
	//creates a QProject object (cypher) with a given key string
	public QProject(String key) {
		// TODO Auto-generated constructor stub
		setKeyTable(key);
	}
	
	//gets a key string from the user to generate a key table to set to the QProject's key table
	public void getKey() {
		System.out.print("Please enter the key for the cypher: ");
		String userInput = userScanner.nextLine();
		setKeyTable(userInput);
	}
	
	//generates key table based on key string
	public char[][] generateKeyTable(String key){
		char[][] aKeyTable = new char[5][5];
		//cleans key
		key = cleanText(key);
		String keyTableString = "";
		
		//adds key string to key table
		int row = 0;
		int col = 0;
		for(char character : key.toCharArray()) {
			if(!keyTableString.contains(String.valueOf(character))) {
				keyTableString += String.valueOf(character);
				aKeyTable[row][col]=character;
				col +=1;
				row+=col/5;
				col%=5;
			}
		}
		
		//adds rest of the alphabet into the table
		row = 0;
		col = 0;
		outerloop:
		for(int i = 0; i < ALPHABET.length; i++) {
			while(keyTableString.contains(String.valueOf(ALPHABET[i]))) {
				i++;
				if(i >= ALPHABET.length) {
					break outerloop;
				}
			}
			if(!(new String(ALPHABET).contains(String.valueOf(aKeyTable[row][col])))) {
				keyTableString += String.valueOf(ALPHABET[i]);
				aKeyTable[row][col]=ALPHABET[i];
				
			}
			else {
				i--;
			}
			row +=1;
			col+=row/5;
			row%=5;	
		}
		return aKeyTable;
	}
	
	//sets the key table of the cypher to the key table generated from the key string
	public void setKeyTable(String key) {
		this.keyTable=generateKeyTable(key);
	}
	
	//prints out the key table
	public void printKeyTable() {
		for(char[] row : keyTable) {
			System.out.println(new String(row));
		}
	}
	
	//encrypts message given cypher
	public String encrpyt(String clearText) {
		char[][] digraphs = cleanAddXSeperatorsAndConvertToDigraphs(clearText);
		//printDigraphs(digraphs);
		digraphs = encryptDigraphs(digraphs);
		String code = "";
		for(char[] digraph : digraphs) {
			code += new String(digraph);
		}
		return code;
	}
	
	//cleans text according to the requirements of keys and messages
	public String cleanText(String text) {
		return text.replaceAll("\\p{Punct}","").replaceAll(" ", "").replaceAll("\\s","").replaceAll("[\\n\\t ]", "").replaceAll("\\d","").strip().toUpperCase().replaceAll("J", "I");
	}
	
	//adds x seperators between two duplicate letters in the same digraph and to complete digraph
	public String addXSeperators(String text) {
		int lastIndex = text.length()-1;
		for(int i = 0; i < lastIndex; i+=2) {
			if(text.charAt(i)==text.charAt(i+1)) {
				text=text.substring(0,i+1)+"X"+text.substring(i+1);
			}
			lastIndex = text.length()-1;
		}
		if(text.length()%2==1) {
			text+="X";
		}
		return text;
	}
	
	//converts a string into a digraph
	public char[][] convertToDigraphs(String text){
		char[][] digraphs = new char[text.length()/2][2];
		for(int i = 0; i<text.length()-1; i+=2) {
			digraphs[i/2] = text.substring(i, i+2).toCharArray();
		}
		return digraphs;
	}
	
	//cleans text, adds x seperators, and converts the refined text into digraphs
	public char[][] cleanAddXSeperatorsAndConvertToDigraphs(String clearText){
		return convertToDigraphs(addXSeperators(cleanText(clearText)));
	}
	
	//cleans and turns code into digraphs
	public char[][] cleanAndConvertToDigraphs(String code){
		return convertToDigraphs(cleanText(code));
	}
	
	//encrypts all digraphs and returns them in a double char array
	public char[][] encryptDigraphs(char[][] digraphs) {
		for(int i = 0; i < digraphs.length; i++) {
			digraphs[i]=encryptDigraph(digraphs[i]);
		}
		return digraphs;
	}
	
	//encrypts individual digraph and returns char array
	public char[] encryptDigraph(char[] digraph) {
		int[] letterRow= new int[2];
		int[] letterCol=new int[2];
		for(int row = 0; row < keyTable.length; row++) {
			for(int col = 0; col < keyTable[0].length; col++) {
				for(int i = 0; i < digraph.length; i++) {
					if(digraph[i]==keyTable[row][col]) {
						letterRow[i]=row;
						letterCol[i]=col;
					}
				}
			}
		}
		if(letterRow[0]==letterRow[1]) {
			for(int i = 0; i < digraph.length; i++) {
				digraph[i]=keyTable[letterRow[i]][(letterCol[i]+1)%5];
			}
		}
		else if(letterCol[0]==letterCol[1]) {
			for(int i = 0; i < digraph.length; i++) {
				digraph[i]=keyTable[(letterRow[i]+1)%5][letterCol[i]];
			}
		}
		else{
			for(int i = 0; i < digraph.length; i++) {
				digraph[i]=keyTable[letterRow[i]][letterCol[(i+1)%2]];
			}
		}
		return digraph;
	}
	
	//decrypts given code using cypher
	public String decrpyt(String code) {
		char[][] digraphs = cleanAndConvertToDigraphs(code);
		digraphs = decryptDigraphs(digraphs);
		String clearText = "";
		for(char[] digraph : digraphs) {
			clearText += new String(digraph);
		}
		return stripXSeperators(clearText);
	}
	
	//decrypts all individual digraphs and returns them all as a double char array
	public char[][] decryptDigraphs(char[][] digraphs) {
		for(int i = 0; i < digraphs.length; i++) {
			digraphs[i]=decryptDigraph(digraphs[i]);
		}
		return digraphs;
	}
	
	//decrypts an individual digraph and returns char array
	public char[] decryptDigraph(char[] digraph) {
		int[] letterRow= new int[2];
		int[] letterCol=new int[2];
		for(int row = 0; row < keyTable.length; row++) {
			for(int col = 0; col < keyTable[0].length; col++) {
				for(int i = 0; i < digraph.length; i++) {
					if(digraph[i]==keyTable[row][col]) {
						letterRow[i]=row;
						letterCol[i]=col;
					}
				}
			}
		}
		
		if(letterRow[0]==letterRow[1]) {
			
			for(int i = 0; i < digraph.length; i++) {
				
				digraph[i]=keyTable[letterRow[i]][positiveOnlyMod((letterCol[i]-1),5)];
			}
		}
		else if(letterCol[0]==letterCol[1]) {
			
			for(int i = 0; i < digraph.length; i++) {
				
				
				digraph[i]=keyTable[positiveOnlyMod((letterRow[i]-1),5)][letterCol[i]];
			}
		}
		else{
			for(int i = 0; i < digraph.length; i++) {
				digraph[i]=keyTable[letterRow[i]][letterCol[(i+1)%2]];
			}
		}
		return digraph;
	}
	
	//modulus that only returns positive numbers and reflects the modulus operation that google uses which is better for negative numbers in my opinion
	//than Java's default modulus operator
	public int positiveOnlyMod(int number, int numberToModBy) {
		if(number%numberToModBy<0) {
			return number%numberToModBy + numberToModBy;
		}
		else {
			return number%numberToModBy;
		}
	}
	
	//removes x seperators if they were added by the encryption excluding trailing x seperators
	public String stripXSeperators(String clearText) {
		int trueI = 0;
		for(int i = 0; i < clearText.length(); i++) {
			if(i!=0&&!(i>=clearText.length()-1)&&clearText.charAt(i)=='X'&&clearText.charAt(i-1)==clearText.charAt(i+1)&&trueI%2==1) {
				clearText = clearText.substring(0,i)+clearText.substring(i+1);
				trueI++;
			}
			trueI++;
		}
		return clearText;
	}
}
