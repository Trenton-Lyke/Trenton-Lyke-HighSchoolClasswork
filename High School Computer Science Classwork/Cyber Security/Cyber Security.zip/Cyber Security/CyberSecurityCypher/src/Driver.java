import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Driver {



	public static void main(String[] args) {
		//scanner and cypher used to encrypt and decrypt user's messages
		Scanner userScanner = new Scanner(System.in);
		QProject cypher = new QProject("key");
		
		//boolean used to indicate if the user wants to exit the program
		boolean exitChosen = false;
		
		//repeating menu and flow of selections allowing user to encrypt or decrypt messages with cyphers with keys they give
		while(!exitChosen) {
			System.out.print("Would you like to encode, decode, or exit: ");
			String userInput = userScanner.nextLine();
			switch(userInput.strip().toLowerCase()) {
				case "encode":
					cypher.getKey();
					cypher.printKeyTable();
					System.out.print("Please enter a message to encrypt: ");
					userInput = userScanner.nextLine();
					System.out.println(cypher.encrpyt(userInput));
					break;
				case "decode":
					cypher.getKey();
					cypher.printKeyTable();
					System.out.print("Please enter a encrypted message to decrypt: ");
					userInput = userScanner.nextLine();
					System.out.println(cypher.decrpyt(userInput));
					break;
				case "exit":
					exitChosen = true;
					break;
				default:
					System.out.print("Sorry that input was invalid. Please try again.\n");
					break;
					
			}
			
		}

		
	}

}
