import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class SimpleNumberDecrypter {

	

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		final String[] dictionary = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", " ", "_"};
		File file = new File("file_to_decrypt.txt");
		Scanner scanner = new Scanner(file);
		ArrayList<Integer> numbers = new ArrayList<Integer>(); 
		while(scanner.hasNextLine()) {
			String[] line = scanner.nextLine().split(",");
			for(String number : line) {
				number = number.replace('(', ' ');
				number = number.replace(')', ' ');
				number = number.trim();
				numbers.add(Integer.parseInt(number));
			}
		}
		String message = "";
		for(int number : numbers) {
			message += dictionary[number-1];
		}
		System.out.println(message);
	}

}
