  GNU nano 4.5                                                                                                                                                                                                                                                                                         TrentonLykeScript.sh                                                                                                                                                                                                                                                                                          Modified  
#!/bin/bash

echo "argument 1 ($1) is for the countdown, argument 2 ($2) is for the file of usernames, argument 3 ($3) is for the username, and argument 4 ($4) is for the file to be moved to the trash directory"
#Part A
#displays good morning to the user gives the date and who is logged 
#onto the computer
echo ______________________Part A_____________________________________
echo Good Morning $USER
date
who

#Part B
#Displays greeting based on time of day
echo ______________________Part B_____________________________________  
coditionalTimeInHours=$(date +%k)
if [ $coditionalTimeInHours -lt 6 ]; then
  echo You Should Be Asleep
elif [ $coditionalTimeInHours -lt 12 ]; then
  echo Good Morning
elif [ $coditionalTimeInHours -lt 19 ]; then
  echo Good Afternoon
else
  echo Good Evening
fi

#counts down from 10 and then displays go
#Part C
echo ______________________Part C_____________________________________  
countDownNum=10
while [ $countDownNum -ge 0 ];do
  if [ $countDownNum != 0 ];then
    echo $countDownNum
  else
    echo "GO!"
  fi
  (( countDownNum-- ))
done

#Part D
#counts down from the number given by argument 1
echo ______________________Part D______________________________________
if [ $# -ge 1 ];then
countDownNum=$1
while [ $countDownNum -ge 0 ];do
  if [ $countDownNum != 0 ];then
    echo $countDownNum
  else
    echo "GO!"
  fi
  (( countDownNum-- ))
done
else
echo "There was no argument for count down"
fi

#Part E
#prints all the files in the directory
echo ______________________Part E______________________________________
for file in *
do
echo $file
done


if [ $# -ge 3 ];then
#Part F
#checks if user name given by argument 3 is in the file 
#given by argument 2 if it is it will disply the username
#is already in the file otherwise it will add it in the file
echo ______________________Part F______________________________________
if [ ! -f $2 ];then
touch $2
fi
isUserNameInFile=false
while IFS= read -r line; do
if [ "$line" == "$3" ];then
echo "username already exists"
isUserNameInFile=true
fi
done <$2
if [ $isUserNameInFile != true ];then
echo $3 >> $2
fi
else


echo "not enough arguments given for for checking a file for a username"
fi

#Part G
#moves the file given by argument 4 to the trash directory of the
#home directory
echo ______________________Part G_____________________________________
if [ $# -ge 4 ];then
 if [ -f $4 ];then
 if [ -d "$HOME/trash" ];then
mv $4 "$HOME/trash"

 else
mkdir "$HOME/trash"
mv $4 "$HOME/trash"
fi
 else
echo "file not found"
fi
else
echo "not enough arguments for moving afile to the trash directory"
fi

#Part H 
#uses a function to creat a random username with a random number and
#user input
echo ______________________Part H_____________________________________  

function rand () {
  number=$(( ( RANDOM % 100 )  + 1 ))
  read -p "Enter Your Username: "  username
echo "$username$number"
}

result="$(rand)"
echo $result

#Part I
#creates and array of all the files and prints all the elements of 
#the array
echo ______________________Part I_____________________________________  

declare -a filesArray
i=0
while read line
do
    filesArray[ $i ]="$line"        
    (( i++ ))
done < <(ls)

k=0
for fileNameElement in ${filesArray[@]}
do
((k++))
echo "$k. ${fileNameElement}"
done
echo "Number of files: ${#filesArray[@]}"
 
#resources
#https://www.shellhacks.com/
#https://stackoverflow.com/
#https://www.geeksforgeeks.org/
#https://www.tutorialspoint.com/index.htm







